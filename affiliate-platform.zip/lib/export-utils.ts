import jsPDF from "jspdf"
import "jspdf-autotable"

// Extend jsPDF type to include autoTable
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF
  }
}

export interface ExportData {
  headers: string[]
  rows: (string | number)[][]
  title?: string
  filename?: string
}

export interface AnalyticsExportData {
  overview: {
    totalClicks: number
    totalConversions: number
    totalRevenue: number
    conversionRate: number
    averageEPC: number
  }
  chartData: Array<{
    date: string
    clicks: number
    conversions: number
    revenue: number
  }>
  topCountries: Array<{
    country: string
    clicks: number
    percentage: number
  }>
  topDevices: Array<{
    device: string
    clicks: number
    percentage: number
  }>
}

export const exportToCSV = (data: ExportData): void => {
  const { headers, rows, filename = "export" } = data

  // Create CSV content
  const csvContent = [
    headers.join(","),
    ...rows.map((row) =>
      row
        .map((cell) => {
          // Escape quotes and wrap in quotes if contains comma or quote
          const cellStr = String(cell)
          if (cellStr.includes(",") || cellStr.includes('"') || cellStr.includes("\n")) {
            return `"${cellStr.replace(/"/g, '""')}"`
          }
          return cellStr
        })
        .join(","),
    ),
  ].join("\n")

  // Create and download file
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", `${filename}_${new Date().toISOString().split("T")[0]}.csv`)
  link.style.visibility = "hidden"

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export const exportToPDF = (data: ExportData): void => {
  const { headers, rows, title = "Export Report", filename = "export" } = data

  const doc = new jsPDF()

  // Add title
  doc.setFontSize(20)
  doc.text(title, 20, 20)

  // Add generation date
  doc.setFontSize(10)
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30)

  // Add table
  doc.autoTable({
    head: [headers],
    body: rows,
    startY: 40,
    styles: {
      fontSize: 8,
      cellPadding: 3,
    },
    headStyles: {
      fillColor: [59, 130, 246], // Blue color
      textColor: 255,
      fontStyle: "bold",
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252], // Light gray
    },
  })

  // Save the PDF
  doc.save(`${filename}_${new Date().toISOString().split("T")[0]}.pdf`)
}

export const exportAnalyticsToCSV = (data: AnalyticsExportData): void => {
  const headers = ["Metric", "Value"]
  const rows = [
    ["Total Clicks", data.overview.totalClicks.toString()],
    ["Total Conversions", data.overview.totalConversions.toString()],
    ["Total Revenue", `$${data.overview.totalRevenue.toFixed(2)}`],
    ["Conversion Rate", `${data.overview.conversionRate.toFixed(2)}%`],
    ["Average EPC", `$${data.overview.averageEPC.toFixed(2)}`],
    ["", ""], // Empty row
    ["Date", "Clicks", "Conversions", "Revenue"],
    ...data.chartData.map((item) => [
      item.date,
      item.clicks.toString(),
      item.conversions.toString(),
      `$${item.revenue.toFixed(2)}`,
    ]),
    ["", ""], // Empty row
    ["Country", "Clicks", "Percentage"],
    ...data.topCountries.map((item) => [item.country, item.clicks.toString(), `${item.percentage.toFixed(1)}%`]),
    ["", ""], // Empty row
    ["Device", "Clicks", "Percentage"],
    ...data.topDevices.map((item) => [item.device, item.clicks.toString(), `${item.percentage.toFixed(1)}%`]),
  ]

  exportToCSV({
    headers: ["Metric", "Value", "", ""],
    rows,
    filename: "analytics_report",
  })
}

export const exportAnalyticsToPDF = (data: AnalyticsExportData): void => {
  const doc = new jsPDF()

  // Title
  doc.setFontSize(20)
  doc.text("Analytics Report", 20, 20)

  // Generation date
  doc.setFontSize(10)
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30)

  let yPosition = 50

  // Overview section
  doc.setFontSize(14)
  doc.text("Overview", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Metric", "Value"]],
    body: [
      ["Total Clicks", data.overview.totalClicks.toLocaleString()],
      ["Total Conversions", data.overview.totalConversions.toLocaleString()],
      ["Total Revenue", `$${data.overview.totalRevenue.toFixed(2)}`],
      ["Conversion Rate", `${data.overview.conversionRate.toFixed(2)}%`],
      ["Average EPC", `$${data.overview.averageEPC.toFixed(2)}`],
    ],
    startY: yPosition,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  yPosition = (doc as any).lastAutoTable.finalY + 20

  // Performance by Date
  doc.setFontSize(14)
  doc.text("Performance by Date", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Date", "Clicks", "Conversions", "Revenue"]],
    body: data.chartData.map((item) => [
      item.date,
      item.clicks.toLocaleString(),
      item.conversions.toString(),
      `$${item.revenue.toFixed(2)}`,
    ]),
    startY: yPosition,
    styles: { fontSize: 9 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  // Add new page if needed
  if ((doc as any).lastAutoTable.finalY > 250) {
    doc.addPage()
    yPosition = 20
  } else {
    yPosition = (doc as any).lastAutoTable.finalY + 20
  }

  // Top Countries
  doc.setFontSize(14)
  doc.text("Top Countries", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Country", "Clicks", "Percentage"]],
    body: data.topCountries.map((item) => [
      item.country,
      item.clicks.toLocaleString(),
      `${item.percentage.toFixed(1)}%`,
    ]),
    startY: yPosition,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  yPosition = (doc as any).lastAutoTable.finalY + 20

  // Top Devices
  doc.setFontSize(14)
  doc.text("Top Devices", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Device", "Clicks", "Percentage"]],
    body: data.topDevices.map((item) => [item.device, item.clicks.toLocaleString(), `${item.percentage.toFixed(1)}%`]),
    startY: yPosition,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  doc.save(`analytics_report_${new Date().toISOString().split("T")[0]}.pdf`)
}

export const exportLinksToCSV = (links: any[]): void => {
  const headers = [
    "Title",
    "Original URL",
    "Short URL",
    "Category",
    "Network",
    "Clicks",
    "Conversions",
    "Revenue",
    "Conversion Rate",
    "Created Date",
    "Status",
  ]

  const rows = links.map((link) => [
    link.title,
    link.originalUrl,
    link.shortUrl,
    link.category,
    link.network,
    link.clicks.toString(),
    link.conversions.toString(),
    `$${link.revenue.toFixed(2)}`,
    `${link.conversionRate.toFixed(2)}%`,
    new Date(link.createdAt).toLocaleDateString(),
    link.status,
  ])

  exportToCSV({
    headers,
    rows,
    filename: "affiliate_links",
  })
}

export const exportABTestsToCSV = (tests: any[]): void => {
  const headers = [
    "Test Name",
    "Status",
    "Start Date",
    "End Date",
    "Total Clicks",
    "Total Conversions",
    "Total Revenue",
    "Significance",
    "Winner",
    "Hypothesis",
  ]

  const rows = tests.map((test) => [
    test.name,
    test.status,
    test.startDate,
    test.endDate || "N/A",
    test.totalClicks.toString(),
    test.totalConversions.toString(),
    `$${test.totalRevenue.toFixed(2)}`,
    `${test.significance}%`,
    test.winner || "N/A",
    test.hypothesis,
  ])

  exportToCSV({
    headers,
    rows,
    filename: "ab_tests",
  })
}

export const exportABTestDetailsToPDF = (test: any): void => {
  const doc = new jsPDF()

  // Title
  doc.setFontSize(20)
  doc.text("A/B Test Report", 20, 20)

  // Test name
  doc.setFontSize(16)
  doc.text(test.name, 20, 35)

  // Generation date
  doc.setFontSize(10)
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 45)

  let yPosition = 60

  // Test Overview
  doc.setFontSize(14)
  doc.text("Test Overview", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Property", "Value"]],
    body: [
      ["Status", test.status],
      ["Start Date", test.startDate],
      ["End Date", test.endDate || "Ongoing"],
      ["Duration", `${test.duration} days`],
      ["Hypothesis", test.hypothesis],
      ["Total Clicks", test.totalClicks.toLocaleString()],
      ["Total Conversions", test.totalConversions.toString()],
      ["Total Revenue", `$${test.totalRevenue.toFixed(2)}`],
      ["Statistical Significance", `${test.significance}%`],
      ["Winner", test.winner || "TBD"],
    ],
    startY: yPosition,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  yPosition = (doc as any).lastAutoTable.finalY + 20

  // Variant Performance
  doc.setFontSize(14)
  doc.text("Variant Performance", 20, yPosition)
  yPosition += 10

  doc.autoTable({
    head: [["Variant", "Type", "Clicks", "Conversions", "Revenue", "CVR", "Confidence"]],
    body: test.variants.map((variant: any) => [
      variant.name,
      variant.type,
      variant.clicks.toLocaleString(),
      variant.conversions.toString(),
      `$${variant.revenue.toFixed(2)}`,
      `${variant.conversionRate.toFixed(2)}%`,
      `${variant.confidence}%`,
    ]),
    startY: yPosition,
    styles: { fontSize: 9 },
    headStyles: { fillColor: [59, 130, 246] },
  })

  doc.save(`ab_test_${test.name.replace(/\s+/g, "_").toLowerCase()}_${new Date().toISOString().split("T")[0]}.pdf`)
}
