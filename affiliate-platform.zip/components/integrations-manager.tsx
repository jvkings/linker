"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, XCircle, Settings, Zap, Globe, Code } from "lucide-react"

const integrations = [
  {
    id: "shareasale",
    name: "ShareASale",
    description: "Connect to ShareASale affiliate network",
    status: "connected",
    apiKey: "sk_live_***************",
    lastSync: "2024-01-15 10:30 AM",
    linksImported: 1247,
  },
  {
    id: "cj",
    name: "Commission Junction",
    description: "Import links from CJ Affiliate",
    status: "connected",
    apiKey: "cj_api_***************",
    lastSync: "2024-01-15 09:15 AM",
    linksImported: 892,
  },
  {
    id: "rakuten",
    name: "Rakuten Advertising",
    description: "Rakuten affiliate network integration",
    status: "disconnected",
    apiKey: "",
    lastSync: "Never",
    linksImported: 0,
  },
  {
    id: "amazon",
    name: "Amazon Associates",
    description: "Amazon affiliate program integration",
    status: "pending",
    apiKey: "amzn_***************",
    lastSync: "Syncing...",
    linksImported: 0,
  },
]

export function IntegrationsManager() {
  const [activeTab, setActiveTab] = useState("networks")

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="networks">Networks</TabsTrigger>
          <TabsTrigger value="websites">Websites</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="api">API & SDKs</TabsTrigger>
        </TabsList>

        <TabsContent value="networks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Affiliate Network Integrations</CardTitle>
              <CardDescription>
                Connect your affiliate networks to automatically import links and track performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {integrations.map((integration) => (
                  <div key={integration.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                          <Globe className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{integration.name}</h3>
                          <p className="text-sm text-muted-foreground">{integration.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {integration.status === "connected" && (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Connected
                          </Badge>
                        )}
                        {integration.status === "disconnected" && (
                          <Badge variant="secondary">
                            <XCircle className="w-3 h-3 mr-1" />
                            Disconnected
                          </Badge>
                        )}
                        {integration.status === "pending" && <Badge variant="outline">Pending</Badge>}
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">API Key:</span>
                        <div className="font-mono">{integration.apiKey || "Not configured"}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Last Sync:</span>
                        <div>{integration.lastSync}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Links Imported:</span>
                        <div className="font-semibold">{integration.linksImported.toLocaleString()}</div>
                      </div>
                    </div>

                    {integration.status === "disconnected" && (
                      <div className="mt-4 space-y-3">
                        <div className="space-y-2">
                          <Label htmlFor={`api-key-${integration.id}`}>API Key</Label>
                          <Input id={`api-key-${integration.id}`} placeholder="Enter your API key" type="password" />
                        </div>
                        <Button size="sm">Connect</Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="websites" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Website Integrations</CardTitle>
              <CardDescription>Connect your websites and apps for automatic link injection</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold">WordPress Plugin</h3>
                      <p className="text-sm text-muted-foreground">
                        Auto-inject affiliate links in your WordPress content
                      </p>
                    </div>
                    <Button>Install Plugin</Button>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Automatically replace keywords with affiliate links in posts and pages
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold">JavaScript SDK</h3>
                      <p className="text-sm text-muted-foreground">Integrate with any website using our JS library</p>
                    </div>
                    <Button variant="outline">Get Code</Button>
                  </div>
                  <div className="bg-muted p-3 rounded font-mono text-sm">
                    {'<script src="https://cdn.mylinks.io/sdk.js"></script>'}
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold">Browser Extension</h3>
                      <p className="text-sm text-muted-foreground">Chrome extension for easy link management</p>
                    </div>
                    <Button variant="outline">Download</Button>
                  </div>
                  <div className="text-sm text-muted-foreground">Quickly create and manage links while browsing</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automation Rules</CardTitle>
              <CardDescription>Set up automated workflows for link management</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Zap className="h-5 w-5 text-orange-500" />
                      <div>
                        <h3 className="font-semibold">Auto-Prettify New Links</h3>
                        <p className="text-sm text-muted-foreground">Automatically create pretty URLs for new links</p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Zap className="h-5 w-5 text-blue-500" />
                      <div>
                        <h3 className="font-semibold">Auto-Tag by Destination</h3>
                        <p className="text-sm text-muted-foreground">
                          Automatically tag links based on detected destination
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Zap className="h-5 w-5 text-green-500" />
                      <div>
                        <h3 className="font-semibold">Link Health Monitoring</h3>
                        <p className="text-sm text-muted-foreground">Check for broken links and expired offers</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Zap className="h-5 w-5 text-purple-500" />
                      <div>
                        <h3 className="font-semibold">Keyword Auto-Injection</h3>
                        <p className="text-sm text-muted-foreground">
                          Automatically inject links when keywords are detected
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API & Developer Tools</CardTitle>
              <CardDescription>Integrate our platform with your applications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">API Keys</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <div className="font-mono text-sm">pk_live_***************</div>
                        <div className="text-xs text-muted-foreground">Production Key</div>
                      </div>
                      <Button variant="outline" size="sm">
                        Regenerate
                      </Button>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <div className="font-mono text-sm">pk_test_***************</div>
                        <div className="text-xs text-muted-foreground">Test Key</div>
                      </div>
                      <Button variant="outline" size="sm">
                        Regenerate
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">SDKs & Libraries</h3>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="border rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Code className="h-4 w-4" />
                        <span className="font-medium">JavaScript SDK</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Full-featured SDK for web applications</p>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>

                    <div className="border rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Code className="h-4 w-4" />
                        <span className="font-medium">Python SDK</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Python library for server-side integration</p>
                      <Button variant="outline" size="sm">
                        Download
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">API Documentation</h3>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-3">
                      Complete API reference with examples and interactive testing
                    </p>
                    <Button>View Documentation</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
