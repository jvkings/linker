"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { ExportButton } from "./export-button"
import { exportAnalyticsToCSV, exportAnalyticsToPDF, type AnalyticsExportData } from "@/lib/export-utils"

const clicksData = [
  { date: "Jan 1", clicks: 120 },
  { date: "Jan 2", clicks: 145 },
  { date: "Jan 3", clicks: 167 },
  { date: "Jan 4", clicks: 189 },
  { date: "Jan 5", clicks: 203 },
  { date: "Jan 6", clicks: 178 },
  { date: "Jan 7", clicks: 234 },
]

const countryData = [
  { country: "US", clicks: 5678, percentage: 36.8 },
  { country: "UK", clicks: 2341, percentage: 15.2 },
  { country: "CA", clicks: 1876, percentage: 12.2 },
  { country: "AU", clicks: 1234, percentage: 8.0 },
  { country: "DE", clicks: 987, percentage: 6.4 },
]

const deviceData = [
  { device: "Mobile", clicks: 8765, percentage: 56.8 },
  { device: "Desktop", clicks: 4321, percentage: 28.0 },
  { device: "Tablet", clicks: 2334, percentage: 15.2 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

const analyticsData: AnalyticsExportData = {
  overview: {
    totalClicks: 15420,
    totalConversions: 234,
    totalRevenue: 4567.89,
    conversionRate: 1.52,
    averageEPC: 19.52,
  },
  chartData: [
    { date: "2024-01-01", clicks: 120, conversions: 3, revenue: 45.67 },
    { date: "2024-01-02", clicks: 145, conversions: 5, revenue: 78.9 },
    { date: "2024-01-03", clicks: 167, conversions: 4, revenue: 67.34 },
    { date: "2024-01-04", clicks: 189, conversions: 7, revenue: 123.45 },
    { date: "2024-01-05", clicks: 203, conversions: 6, revenue: 98.76 },
    { date: "2024-01-06", clicks: 178, conversions: 8, revenue: 156.78 },
    { date: "2024-01-07", clicks: 234, conversions: 9, revenue: 189.23 },
  ],
  topCountries: [
    { country: "United States", clicks: 5678, percentage: 36.8 },
    { country: "United Kingdom", clicks: 2341, percentage: 15.2 },
    { country: "Canada", clicks: 1876, percentage: 12.2 },
    { country: "Australia", clicks: 1234, percentage: 8.0 },
    { country: "Germany", clicks: 987, percentage: 6.4 },
  ],
  topDevices: [
    { device: "Mobile", clicks: 8765, percentage: 56.8 },
    { device: "Desktop", clicks: 4321, percentage: 28.0 },
    { device: "Tablet", clicks: 2334, percentage: 15.2 },
  ],
}

export function AnalyticsDashboard() {
  const handleExportCSV = () => {
    exportAnalyticsToCSV(analyticsData)
  }

  const handleExportPDF = () => {
    exportAnalyticsToPDF(analyticsData)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Analytics Dashboard</h2>
          <p className="text-muted-foreground">Comprehensive performance insights for your affiliate links</p>
        </div>
        <ExportButton
          onExportCSV={handleExportCSV}
          onExportPDF={handleExportPDF}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
        />
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="geography">Geography</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="referrers">Referrers</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Daily Clicks</CardTitle>
                <CardDescription>Click performance over the last 7 days</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={clicksData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="clicks" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Conversion Funnel</CardTitle>
                <CardDescription>From clicks to conversions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Total Clicks</span>
                    <span className="font-semibold">15,420</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: "100%" }}></div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Engaged Users</span>
                    <span className="font-semibold">3,084 (20%)</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "20%" }}></div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Conversions</span>
                    <span className="font-semibold">234 (1.5%)</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-orange-600 h-2 rounded-full" style={{ width: "1.5%" }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="geography" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top Countries</CardTitle>
                <CardDescription>Traffic by country</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {countryData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-6 bg-gray-200 rounded flex items-center justify-center text-xs font-semibold">
                          {item.country}
                        </div>
                        <span>{item.clicks.toLocaleString()} clicks</span>
                      </div>
                      <span className="text-muted-foreground">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Geographic Distribution</CardTitle>
                <CardDescription>Visual breakdown by region</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={countryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ country, percentage }) => `${country} ${percentage}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="clicks"
                    >
                      {countryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="devices" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Device Breakdown</CardTitle>
              <CardDescription>Traffic by device type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {deviceData.map((item, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{item.device}</span>
                      <span className="text-muted-foreground">
                        {item.clicks.toLocaleString()} ({item.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Referrers</CardTitle>
              <CardDescription>Sources driving traffic to your links</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { source: "Direct", clicks: 6789, percentage: 44.0 },
                  { source: "Google", clicks: 3456, percentage: 22.4 },
                  { source: "Facebook", clicks: 2345, percentage: 15.2 },
                  { source: "Twitter", clicks: 1234, percentage: 8.0 },
                  { source: "YouTube", clicks: 987, percentage: 6.4 },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded">
                    <span className="font-medium">{item.source}</span>
                    <div className="text-right">
                      <div className="font-semibold">{item.clicks.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">{item.percentage}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
