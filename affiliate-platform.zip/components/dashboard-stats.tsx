"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Link, MousePointer, Globe, DollarSign } from "lucide-react"

const stats = [
  {
    title: "Total Links",
    value: "12,847",
    change: "+12%",
    icon: Link,
    color: "text-blue-600",
    bgColor: "bg-blue-50 dark:bg-blue-950",
  },
  {
    title: "Total Clicks",
    value: "2.4M",
    change: "+18%",
    icon: MousePointer,
    color: "text-green-600",
    bgColor: "bg-green-50 dark:bg-green-950",
  },
  {
    title: "Active Websites",
    value: "47",
    change: "+3",
    icon: Globe,
    color: "text-purple-600",
    bgColor: "bg-purple-50 dark:bg-purple-950",
  },
  {
    title: "Revenue",
    value: "$24,567",
    change: "+23%",
    icon: DollarSign,
    color: "text-orange-600",
    bgColor: "bg-orange-50 dark:bg-orange-950",
  },
]

export function DashboardStats() {
  return (
    <>
      {stats.map((stat) => (
        <Card key={stat.title} className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">{stat.change}</span> from last month
            </p>
          </CardContent>
        </Card>
      ))}
    </>
  )
}
