"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ExportButton } from "./export-button"
import { exportABTestsToCSV, exportABTestDetailsToPDF } from "@/lib/export-utils"
import {
  TestTube,
  Plus,
  Play,
  Pause,
  Trophy,
  TrendingUp,
  TrendingDown,
  Target,
  BarChart3,
  DollarSign,
  CheckCircle,
  Clock,
  Eye,
  Zap,
  Lightbulb,
} from "lucide-react"

interface ABTest {
  id: string
  name: string
  status: "draft" | "running" | "completed" | "paused"
  variants: {
    id: string
    name: string
    type: "control" | "variant"
    url: string
    title: string
    description?: string
    traffic: number
    clicks: number
    conversions: number
    revenue: number
    ctr: number
    conversionRate: number
    confidence: number
  }[]
  startDate: string
  endDate?: string
  duration: number
  totalClicks: number
  totalConversions: number
  totalRevenue: number
  winner?: string
  significance: number
  hypothesis: string
  goal: string
  trafficSplit: number[]
}

export function ABTestingDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newTest, setNewTest] = useState({
    name: "",
    hypothesis: "",
    goal: "conversion_rate",
    duration: 14,
    trafficSplit: [50, 50],
    variants: [
      { name: "Control", url: "", title: "", description: "" },
      { name: "Variant A", url: "", title: "", description: "" },
    ],
  })

  const abTests: ABTest[] = [
    {
      id: "test_001",
      name: "Apple AirPods Pro - Title Optimization",
      status: "running",
      variants: [
        {
          id: "control",
          name: "Control",
          type: "control",
          url: "lnkm.pro/airpods-pro",
          title: "Apple AirPods Pro (2nd Generation)",
          description: "Original product title",
          traffic: 50,
          clicks: 1247,
          conversions: 34,
          revenue: 567.89,
          ctr: 2.73,
          conversionRate: 2.73,
          confidence: 0,
        },
        {
          id: "variant_a",
          name: "Variant A",
          type: "variant",
          url: "lnkm.pro/airpods-pro-v2",
          title: "🎧 Apple AirPods Pro 2nd Gen - 50% OFF Limited Time!",
          description: "Emoji + urgency + discount",
          traffic: 50,
          clicks: 1189,
          conversions: 41,
          revenue: 723.45,
          ctr: 3.45,
          conversionRate: 3.45,
          confidence: 87,
        },
      ],
      startDate: "2024-01-10",
      duration: 14,
      totalClicks: 2436,
      totalConversions: 75,
      totalRevenue: 1291.34,
      significance: 87,
      hypothesis: "Adding emojis and urgency to the title will increase click-through rates",
      goal: "conversion_rate",
      trafficSplit: [50, 50],
    },
    {
      id: "test_002",
      name: "Fitness Tracker - Landing Page Test",
      status: "completed",
      variants: [
        {
          id: "control",
          name: "Control",
          type: "control",
          url: "lnkm.pro/fitness-tracker",
          title: "Fitbit Charge 5 Advanced Fitness Tracker",
          description: "Standard product page",
          traffic: 50,
          clicks: 892,
          conversions: 15,
          revenue: 234.5,
          ctr: 1.68,
          conversionRate: 1.68,
          confidence: 0,
        },
        {
          id: "variant_a",
          name: "Variant A",
          type: "variant",
          url: "lnkm.pro/fitness-tracker-review",
          title: "Fitbit Charge 5 Review - Is It Worth It?",
          description: "Review-style landing page",
          traffic: 50,
          clicks: 934,
          conversions: 28,
          revenue: 456.78,
          ctr: 3.0,
          conversionRate: 3.0,
          confidence: 95,
        },
      ],
      startDate: "2023-12-15",
      endDate: "2023-12-29",
      duration: 14,
      totalClicks: 1826,
      totalConversions: 43,
      totalRevenue: 691.28,
      winner: "variant_a",
      significance: 95,
      hypothesis: "Review-style titles will appear more trustworthy and increase conversions",
      goal: "conversion_rate",
      trafficSplit: [50, 50],
    },
    {
      id: "test_003",
      name: "Gaming Headset - Price Display Test",
      status: "draft",
      variants: [
        {
          id: "control",
          name: "Control",
          type: "control",
          url: "lnkm.pro/gaming-headset",
          title: "SteelSeries Arctis 7P Wireless Gaming Headset",
          description: "No price in title",
          traffic: 50,
          clicks: 0,
          conversions: 0,
          revenue: 0,
          ctr: 0,
          conversionRate: 0,
          confidence: 0,
        },
        {
          id: "variant_a",
          name: "Variant A",
          type: "variant",
          url: "lnkm.pro/gaming-headset-price",
          title: "SteelSeries Arctis 7P Gaming Headset - $149.99",
          description: "Price included in title",
          traffic: 50,
          clicks: 0,
          conversions: 0,
          revenue: 0,
          ctr: 0,
          conversionRate: 0,
          confidence: 0,
        },
      ],
      startDate: "",
      duration: 14,
      totalClicks: 0,
      totalConversions: 0,
      totalRevenue: 0,
      significance: 0,
      hypothesis: "Including price in title will set expectations and improve conversion quality",
      goal: "revenue",
      trafficSplit: [50, 50],
    },
  ]

  const testMetrics = [
    {
      title: "Active Tests",
      value: abTests.filter((t) => t.status === "running").length.toString(),
      change: "+2",
      icon: TestTube,
      color: "blue",
    },
    {
      title: "Completed Tests",
      value: abTests.filter((t) => t.status === "completed").length.toString(),
      change: "+1",
      icon: Trophy,
      color: "green",
    },
    {
      title: "Avg. Confidence",
      value: "91%",
      change: "+5%",
      icon: Target,
      color: "purple",
    },
    {
      title: "Revenue Lift",
      value: "+$2,847",
      change: "+23%",
      icon: DollarSign,
      color: "orange",
    },
  ]

  const handleExportAllTests = () => {
    exportABTestsToCSV(abTests)
  }

  const handleExportTestDetails = (test: ABTest) => {
    exportABTestDetailsToPDF(test)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "completed":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "paused":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "draft":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <Play className="h-3 w-3" />
      case "completed":
        return <CheckCircle className="h-3 w-3" />
      case "paused":
        return <Pause className="h-3 w-3" />
      case "draft":
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getWinnerBadge = (test: ABTest) => {
    if (test.status !== "completed" || !test.winner) return null

    const winner = test.variants.find((v) => v.id === test.winner)
    if (!winner) return null

    return (
      <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
        <Trophy className="h-3 w-3 mr-1" />
        {winner.name} Wins
      </Badge>
    )
  }

  const calculateSignificance = (control: any, variant: any) => {
    // Simplified statistical significance calculation
    const controlRate = control.conversionRate / 100
    const variantRate = variant.conversionRate / 100
    const lift = ((variantRate - controlRate) / controlRate) * 100

    if (Math.abs(lift) > 20 && control.clicks > 100 && variant.clicks > 100) {
      return Math.min(95, 70 + Math.abs(lift))
    }
    return Math.max(0, 50 + Math.abs(lift) * 2)
  }

  const handleCreateTest = () => {
    // Handle test creation logic here
    console.log("Creating test:", newTest)
    setIsCreateDialogOpen(false)
  }

  return (
    <div className="space-y-6">
      {/* Header with Export */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">A/B Testing Dashboard</h2>
          <p className="text-muted-foreground">Split test your affiliate links to optimize performance</p>
        </div>
        <div className="flex space-x-2">
          <ExportButton onExportCSV={handleExportAllTests} onExportPDF={handleExportAllTests} size="sm" />
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Plus className="mr-2 h-4 w-4" />
                Create A/B Test
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New A/B Test</DialogTitle>
                <DialogDescription>Set up a split test to optimize your affiliate link performance</DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="test-name">Test Name</Label>
                  <Input
                    id="test-name"
                    placeholder="e.g., Apple AirPods - Title Optimization"
                    value={newTest.name}
                    onChange={(e) => setNewTest({ ...newTest, name: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hypothesis">Hypothesis</Label>
                  <Textarea
                    id="hypothesis"
                    placeholder="What do you expect to happen and why?"
                    value={newTest.hypothesis}
                    onChange={(e) => setNewTest({ ...newTest, hypothesis: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="goal">Primary Goal</Label>
                    <Select value={newTest.goal} onValueChange={(value) => setNewTest({ ...newTest, goal: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clicks">Click-Through Rate</SelectItem>
                        <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
                        <SelectItem value="revenue">Revenue per Click</SelectItem>
                        <SelectItem value="engagement">Engagement Time</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (days)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={newTest.duration}
                      onChange={(e) => setNewTest({ ...newTest, duration: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Test Variants</Label>
                  {newTest.variants.map((variant, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{variant.name}</h4>
                        <Badge variant={index === 0 ? "default" : "secondary"}>
                          {index === 0 ? "Control" : "Variant"}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>URL</Label>
                          <Input
                            placeholder="https://example.com/affiliate-link"
                            value={variant.url}
                            onChange={(e) => {
                              const updatedVariants = [...newTest.variants]
                              updatedVariants[index].url = e.target.value
                              setNewTest({ ...newTest, variants: updatedVariants })
                            }}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Title</Label>
                          <Input
                            placeholder="Link title or description"
                            value={variant.title}
                            onChange={(e) => {
                              const updatedVariants = [...newTest.variants]
                              updatedVariants[index].title = e.target.value
                              setNewTest({ ...newTest, variants: updatedVariants })
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Description (Optional)</Label>
                        <Input
                          placeholder="What makes this variant different?"
                          value={variant.description}
                          onChange={(e) => {
                            const updatedVariants = [...newTest.variants]
                            updatedVariants[index].description = e.target.value
                            setNewTest({ ...newTest, variants: updatedVariants })
                          }}
                        />
                      </div>
                    </div>
                  ))}

                  <Button
                    variant="outline"
                    onClick={() => {
                      setNewTest({
                        ...newTest,
                        variants: [
                          ...newTest.variants,
                          {
                            name: `Variant ${String.fromCharCode(65 + newTest.variants.length - 1)}`,
                            url: "",
                            title: "",
                            description: "",
                          },
                        ],
                      })
                    }}
                    className="w-full"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Another Variant
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Traffic Split</Label>
                  <div className="text-sm text-muted-foreground mb-2">
                    Control: {newTest.trafficSplit[0]}% | Variant A: {newTest.trafficSplit[1]}%
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-sm">Equal Split</span>
                    <Switch
                      checked={newTest.trafficSplit[0] === 50}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setNewTest({ ...newTest, trafficSplit: [50, 50] })
                        }
                      }}
                    />
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTest} className="bg-gradient-to-r from-blue-600 to-purple-600">
                  Create Test
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {testMetrics.map((metric) => (
          <Card
            key={metric.title}
            className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg"
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div
                  className={`p-2 rounded-lg ${
                    metric.color === "blue"
                      ? "bg-blue-100 text-blue-600 dark:bg-blue-900"
                      : metric.color === "green"
                        ? "bg-green-100 text-green-600 dark:bg-green-900"
                        : metric.color === "purple"
                          ? "bg-purple-100 text-purple-600 dark:bg-purple-900"
                          : "bg-orange-100 text-orange-600 dark:bg-orange-900"
                  }`}
                >
                  <metric.icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <Badge
                      variant="outline"
                      className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    >
                      {metric.change}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="active">Active Tests</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            {abTests.slice(0, 4).map((test) => (
              <Card key={test.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{test.name}</CardTitle>
                      <CardDescription className="line-clamp-2">{test.hypothesis}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className={getStatusColor(test.status)}>
                        {getStatusIcon(test.status)}
                        <span className="ml-1 capitalize">{test.status}</span>
                      </Badge>
                      {getWinnerBadge(test)}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Test Progress */}
                  {test.status === "running" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">
                          Day {Math.floor((Date.now() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24))} of{" "}
                          {test.duration}
                        </span>
                      </div>
                      <Progress
                        value={
                          (Math.floor((Date.now() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24)) /
                            test.duration) *
                          100
                        }
                        className="h-2"
                      />
                    </div>
                  )}

                  {/* Variants Comparison */}
                  <div className="space-y-3">
                    {test.variants.map((variant) => (
                      <div
                        key={variant.id}
                        className={`p-3 rounded-lg border ${
                          test.winner === variant.id
                            ? "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950"
                            : "border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-950"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium">{variant.name}</span>
                            {variant.type === "control" && (
                              <Badge variant="outline" className="text-xs">
                                Control
                              </Badge>
                            )}
                            {test.winner === variant.id && (
                              <Badge className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                                Winner
                              </Badge>
                            )}
                          </div>
                          {variant.confidence > 0 && (
                            <Badge
                              variant="outline"
                              className={
                                variant.confidence >= 95
                                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                                  : variant.confidence >= 80
                                    ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                              }
                            >
                              {variant.confidence}% confidence
                            </Badge>
                          )}
                        </div>

                        <div className="grid grid-cols-4 gap-2 text-sm">
                          <div className="text-center">
                            <div className="font-semibold text-blue-600">{variant.clicks.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">Clicks</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold text-green-600">{variant.conversions}</div>
                            <div className="text-xs text-muted-foreground">Conv.</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold text-purple-600">{variant.conversionRate.toFixed(2)}%</div>
                            <div className="text-xs text-muted-foreground">CVR</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold text-orange-600">${variant.revenue.toFixed(0)}</div>
                            <div className="text-xs text-muted-foreground">Revenue</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Statistical Significance */}
                  {test.status === "running" && test.significance > 0 && (
                    <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <BarChart3 className="h-4 w-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                            Statistical Significance
                          </span>
                        </div>
                        <Badge
                          className={
                            test.significance >= 95
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                              : test.significance >= 80
                                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                          }
                        >
                          {test.significance}%
                        </Badge>
                      </div>
                      <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
                        {test.significance >= 95
                          ? "Results are statistically significant"
                          : test.significance >= 80
                            ? "Results are approaching significance"
                            : "More data needed for reliable results"}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="text-xs text-muted-foreground">
                      {test.status === "running" && `Started ${test.startDate}`}
                      {test.status === "completed" && `Completed ${test.endDate}`}
                      {test.status === "draft" && "Ready to launch"}
                    </div>
                    <div className="flex space-x-2">
                      {test.status === "draft" && (
                        <Button size="sm" className="bg-gradient-to-r from-green-600 to-emerald-600">
                          <Play className="mr-2 h-4 w-4" />
                          Start Test
                        </Button>
                      )}
                      {test.status === "running" && (
                        <>
                          <Button variant="outline" size="sm">
                            <Pause className="mr-2 h-4 w-4" />
                            Pause
                          </Button>
                          <Button variant="outline" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </Button>
                        </>
                      )}
                      {test.status === "completed" && (
                        <Button variant="outline" size="sm" onClick={() => handleExportTestDetails(test)}>
                          <BarChart3 className="mr-2 h-4 w-4" />
                          Export Results
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Active A/B Tests</CardTitle>
              <CardDescription>Currently running split tests and their real-time performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {abTests
                  .filter((test) => test.status === "running")
                  .map((test) => (
                    <div key={test.id} className="border rounded-lg p-6 space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-semibold">{test.name}</h3>
                          <p className="text-sm text-muted-foreground">{test.hypothesis}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            <Play className="h-3 w-3 mr-1" />
                            Running
                          </Badge>
                          <Button variant="outline" size="sm" onClick={() => handleExportTestDetails(test)}>
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Real-time Metrics */}
                      <div className="grid grid-cols-4 gap-4">
                        <div className="text-center p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                          <div className="text-2xl font-bold text-blue-600">{test.totalClicks.toLocaleString()}</div>
                          <div className="text-sm text-muted-foreground">Total Clicks</div>
                        </div>
                        <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                          <div className="text-2xl font-bold text-green-600">{test.totalConversions}</div>
                          <div className="text-sm text-muted-foreground">Conversions</div>
                        </div>
                        <div className="text-center p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                          <div className="text-2xl font-bold text-purple-600">
                            {((test.totalConversions / test.totalClicks) * 100).toFixed(2)}%
                          </div>
                          <div className="text-sm text-muted-foreground">Overall CVR</div>
                        </div>
                        <div className="text-center p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                          <div className="text-2xl font-bold text-orange-600">${test.totalRevenue.toFixed(0)}</div>
                          <div className="text-sm text-muted-foreground">Revenue</div>
                        </div>
                      </div>

                      {/* Variant Performance */}
                      <div className="space-y-3">
                        <h4 className="font-medium">Variant Performance</h4>
                        {test.variants.map((variant) => {
                          const control = test.variants.find((v) => v.type === "control")
                          const lift =
                            control && variant.type === "variant"
                              ? ((variant.conversionRate - control.conversionRate) / control.conversionRate) * 100
                              : 0

                          return (
                            <div key={variant.id} className="flex items-center justify-between p-4 border rounded-lg">
                              <div className="flex items-center space-x-4">
                                <div>
                                  <div className="font-medium">{variant.name}</div>
                                  <div className="text-sm text-muted-foreground">{variant.title}</div>
                                </div>
                                {variant.type === "control" && (
                                  <Badge variant="outline" className="text-xs">
                                    Control
                                  </Badge>
                                )}
                              </div>

                              <div className="flex items-center space-x-6">
                                <div className="text-center">
                                  <div className="font-semibold">{variant.clicks.toLocaleString()}</div>
                                  <div className="text-xs text-muted-foreground">Clicks</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold">{variant.conversions}</div>
                                  <div className="text-xs text-muted-foreground">Conv.</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold">{variant.conversionRate.toFixed(2)}%</div>
                                  <div className="text-xs text-muted-foreground">CVR</div>
                                </div>
                                {lift !== 0 && (
                                  <div className="text-center">
                                    <div
                                      className={`font-semibold flex items-center ${
                                        lift > 0 ? "text-green-600" : "text-red-600"
                                      }`}
                                    >
                                      {lift > 0 ? (
                                        <TrendingUp className="h-3 w-3 mr-1" />
                                      ) : (
                                        <TrendingDown className="h-3 w-3 mr-1" />
                                      )}
                                      {Math.abs(lift).toFixed(1)}%
                                    </div>
                                    <div className="text-xs text-muted-foreground">Lift</div>
                                  </div>
                                )}
                                <div className="text-center">
                                  <div className="font-semibold">${variant.revenue.toFixed(0)}</div>
                                  <div className="text-xs text-muted-foreground">Revenue</div>
                                </div>
                              </div>
                            </div>
                          )
                        })}
                      </div>

                      {/* Test Progress and Actions */}
                      <div className="flex items-center justify-between pt-4 border-t">
                        <div className="space-y-1">
                          <div className="text-sm font-medium">
                            Day {Math.floor((Date.now() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24))}{" "}
                            of {test.duration}
                          </div>
                          <Progress
                            value={
                              (Math.floor((Date.now() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24)) /
                                test.duration) *
                              100
                            }
                            className="h-2 w-48"
                          />
                        </div>

                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Pause className="mr-2 h-4 w-4" />
                            Pause Test
                          </Button>
                          <Button variant="outline" size="sm">
                            <Zap className="mr-2 h-4 w-4" />
                            Declare Winner
                          </Button>
                          <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                            <BarChart3 className="mr-2 h-4 w-4" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Results & Insights</CardTitle>
              <CardDescription>Completed A/B tests and their performance insights</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {abTests
                  .filter((test) => test.status === "completed")
                  .map((test) => {
                    const winner = test.variants.find((v) => v.id === test.winner)
                    const control = test.variants.find((v) => v.type === "control")
                    const lift =
                      winner && control && winner.type === "variant"
                        ? ((winner.conversionRate - control.conversionRate) / control.conversionRate) * 100
                        : 0

                    return (
                      <div key={test.id} className="border rounded-lg p-6 space-y-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-lg font-semibold">{test.name}</h3>
                            <p className="text-sm text-muted-foreground">{test.hypothesis}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Completed
                            </Badge>
                            {winner && (
                              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                                <Trophy className="h-3 w-3 mr-1" />
                                {winner.name} Wins
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Results Summary */}
                        <div className="grid grid-cols-4 gap-4">
                          <div className="text-center p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{test.totalClicks.toLocaleString()}</div>
                            <div className="text-sm text-muted-foreground">Total Clicks</div>
                          </div>
                          <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">{test.totalConversions}</div>
                            <div className="text-sm text-muted-foreground">Conversions</div>
                          </div>
                          <div className="text-center p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">{test.significance}%</div>
                            <div className="text-sm text-muted-foreground">Confidence</div>
                          </div>
                          <div className="text-center p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                            <div className="text-2xl font-bold text-orange-600">
                              {lift > 0 ? "+" : ""}
                              {lift.toFixed(1)}%
                            </div>
                            <div className="text-sm text-muted-foreground">Performance Lift</div>
                          </div>
                        </div>

                        {/* Key Insights */}
                        <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                          <div className="flex items-start space-x-3">
                            <Lightbulb className="h-5 w-5 text-green-600 mt-0.5" />
                            <div>
                              <h4 className="font-medium text-green-700 dark:text-green-300">Key Insights</h4>
                              <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                                {winner && winner.name === "Variant A"
                                  ? `${winner.name} outperformed the control by ${lift.toFixed(1)}% with ${test.significance}% confidence. This suggests that ${test.hypothesis.toLowerCase()}.`
                                  : "The control version performed better than the variant, indicating the original approach was more effective."}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Variant Breakdown */}
                        <div className="space-y-3">
                          <h4 className="font-medium">Final Results</h4>
                          {test.variants.map((variant) => (
                            <div
                              key={variant.id}
                              className={`p-4 rounded-lg border ${
                                test.winner === variant.id
                                  ? "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950"
                                  : "border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-950"
                              }`}
                            >
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center space-x-2">
                                  <span className="font-medium">{variant.name}</span>
                                  {variant.type === "control" && (
                                    <Badge variant="outline" className="text-xs">
                                      Control
                                    </Badge>
                                  )}
                                  {test.winner === variant.id && (
                                    <Badge className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                                      <Trophy className="h-3 w-3 mr-1" />
                                      Winner
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-sm text-muted-foreground">{variant.title}</div>
                              </div>

                              <div className="grid grid-cols-5 gap-4 text-sm">
                                <div className="text-center">
                                  <div className="font-semibold text-blue-600">{variant.clicks.toLocaleString()}</div>
                                  <div className="text-xs text-muted-foreground">Clicks</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold text-green-600">{variant.conversions}</div>
                                  <div className="text-xs text-muted-foreground">Conversions</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold text-purple-600">
                                    {variant.conversionRate.toFixed(2)}%
                                  </div>
                                  <div className="text-xs text-muted-foreground">CVR</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold text-orange-600">${variant.revenue.toFixed(0)}</div>
                                  <div className="text-xs text-muted-foreground">Revenue</div>
                                </div>
                                <div className="text-center">
                                  <div className="font-semibold">{variant.confidence}%</div>
                                  <div className="text-xs text-muted-foreground">Confidence</div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-4 border-t">
                          <div className="text-sm text-muted-foreground">
                            Completed on {test.endDate} • Duration: {test.duration} days
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Zap className="mr-2 h-4 w-4" />
                              Apply Winner
                            </Button>
                            <Button variant="outline" size="sm">
                              <TestTube className="mr-2 h-4 w-4" />
                              Run Follow-up Test
                            </Button>
                            <Button
                              size="sm"
                              className="bg-gradient-to-r from-blue-600 to-purple-600"
                              onClick={() => handleExportTestDetails(test)}
                            >
                              <BarChart3 className="mr-2 h-4 w-4" />
                              Export Report
                            </Button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
