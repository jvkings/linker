"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import {
  CheckCircle,
  XCircle,
  Settings,
  Plus,
  RefreshCw,
  Download,
  Users,
  DollarSign,
  Globe,
  Star,
  Clock,
} from "lucide-react"

const affiliateNetworks = [
  {
    id: "shareasale",
    name: "ShareASale",
    description: "One of the largest affiliate networks with 4,500+ merchants",
    logo: "/placeholder.svg?height=48&width=48",
    status: "connected",
    apiKey: "sk_live_***************",
    lastSync: "2024-01-15 10:30 AM",
    linksImported: 1247,
    merchants: 4500,
    avgCommission: "8.5%",
    paymentTerms: "Monthly",
    minPayout: "$50",
    rating: 4.8,
    categories: ["Electronics", "Fashion", "Health", "Home & Garden", "Travel"],
    features: ["Real-time tracking", "Deep linking", "API access", "Mobile tracking"],
    connectionHealth: 98,
  },
  {
    id: "cj",
    name: "Commission Junction (CJ Affiliate)",
    description: "Premium affiliate network with top-tier brands and advertisers",
    logo: "/placeholder.svg?height=48&width=48",
    status: "connected",
    apiKey: "cj_api_***************",
    lastSync: "2024-01-15 09:15 AM",
    linksImported: 892,
    merchants: 3200,
    avgCommission: "12.3%",
    paymentTerms: "Monthly",
    minPayout: "$100",
    rating: 4.9,
    categories: ["Technology", "Finance", "Retail", "Services", "B2B"],
    features: ["Advanced analytics", "Cross-device tracking", "Fraud protection", "Custom reporting"],
    connectionHealth: 95,
  },
  {
    id: "rakuten",
    name: "Rakuten Advertising",
    description: "Global affiliate network with international reach",
    logo: "/placeholder.svg?height=48&width=48",
    status: "connected",
    apiKey: "rak_***************",
    lastSync: "2024-01-15 08:45 AM",
    linksImported: 654,
    merchants: 2800,
    avgCommission: "10.2%",
    paymentTerms: "Monthly",
    minPayout: "$50",
    rating: 4.6,
    categories: ["Shopping", "Travel", "Finance", "Technology", "Lifestyle"],
    features: ["Global reach", "Multi-currency", "Brand safety", "Performance insights"],
    connectionHealth: 92,
  },
  {
    id: "amazon",
    name: "Amazon Associates",
    description: "World's largest e-commerce affiliate program",
    logo: "/placeholder.svg?height=48&width=48",
    status: "pending",
    apiKey: "amzn_***************",
    lastSync: "Syncing...",
    linksImported: 0,
    merchants: 1,
    avgCommission: "4.5%",
    paymentTerms: "Monthly",
    minPayout: "$10",
    rating: 4.7,
    categories: ["Everything", "Electronics", "Books", "Home", "Fashion"],
    features: ["Product API", "Native ads", "OneLink", "Mobile app"],
    connectionHealth: 0,
  },
  {
    id: "clickbank",
    name: "ClickBank",
    description: "Leading affiliate marketplace for digital products",
    logo: "/placeholder.svg?height=48&width=48",
    status: "disconnected",
    apiKey: "",
    lastSync: "Never",
    linksImported: 0,
    merchants: 6000,
    avgCommission: "35%",
    paymentTerms: "Weekly",
    minPayout: "$10",
    rating: 4.3,
    categories: ["Digital Products", "Software", "Education", "Health", "Business"],
    features: ["High commissions", "Digital delivery", "Instant approval", "Global payments"],
    connectionHealth: 0,
  },
  {
    id: "impact",
    name: "Impact",
    description: "Enterprise partnership management platform",
    logo: "/placeholder.svg?height=48&width=48",
    status: "disconnected",
    apiKey: "",
    lastSync: "Never",
    linksImported: 0,
    merchants: 2500,
    avgCommission: "15%",
    paymentTerms: "Monthly",
    minPayout: "$25",
    rating: 4.8,
    categories: ["Enterprise", "SaaS", "Technology", "Finance", "Retail"],
    features: ["Enterprise-grade", "Custom contracts", "Advanced attribution", "Fraud prevention"],
    connectionHealth: 0,
  },
  {
    id: "awin",
    name: "Awin",
    description: "Global affiliate network with 15+ years of experience",
    logo: "/placeholder.svg?height=48&width=48",
    status: "disconnected",
    apiKey: "",
    lastSync: "Never",
    linksImported: 0,
    merchants: 13000,
    avgCommission: "9.8%",
    paymentTerms: "Monthly",
    minPayout: "$20",
    rating: 4.5,
    categories: ["Fashion", "Travel", "Technology", "Finance", "Health"],
    features: ["Global network", "Multi-language", "Mobile tracking", "Voucher codes"],
    connectionHealth: 0,
  },
  {
    id: "partnerstack",
    name: "PartnerStack",
    description: "Modern partner ecosystem platform for SaaS companies",
    logo: "/placeholder.svg?height=48&width=48",
    status: "disconnected",
    apiKey: "",
    lastSync: "Never",
    linksImported: 0,
    merchants: 800,
    avgCommission: "25%",
    paymentTerms: "Monthly",
    minPayout: "$50",
    rating: 4.9,
    categories: ["SaaS", "Technology", "B2B", "Software", "Cloud"],
    features: ["SaaS-focused", "Automated payouts", "Partner portal", "Integration APIs"],
    connectionHealth: 0,
  },
]

export function EnhancedAffiliateNetworkManager() {
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null)
  const [apiKey, setApiKey] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")

  const handleConnect = async (networkId: string) => {
    setIsConnecting(true)
    // Simulate API connection
    setTimeout(() => {
      setIsConnecting(false)
      // Update network status
    }, 3000)
  }

  const connectedNetworks = affiliateNetworks.filter((n) => n.status === "connected")
  const availableNetworks = affiliateNetworks.filter((n) => n.status === "disconnected")

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Globe className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-blue-600">Connected Networks</p>
                <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">{connectedNetworks.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-200 dark:border-green-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                <Users className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-green-600">Total Merchants</p>
                <p className="text-2xl font-bold text-green-700 dark:text-green-300">
                  {connectedNetworks.reduce((sum, n) => sum + n.merchants, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950 border-purple-200 dark:border-purple-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <Download className="h-4 w-4 text-purple-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-purple-600">Links Imported</p>
                <p className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                  {connectedNetworks.reduce((sum, n) => sum + n.linksImported, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950 border-orange-200 dark:border-orange-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
                <DollarSign className="h-4 w-4 text-orange-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-orange-600">Avg Commission</p>
                <p className="text-2xl font-bold text-orange-700 dark:text-orange-300">
                  {(
                    connectedNetworks.reduce((sum, n) => sum + Number.parseFloat(n.avgCommission), 0) /
                      connectedNetworks.length || 0
                  ).toFixed(1)}
                  %
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Network Overview</TabsTrigger>
          <TabsTrigger value="connected">Connected ({connectedNetworks.length})</TabsTrigger>
          <TabsTrigger value="available">Available ({availableNetworks.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {affiliateNetworks.slice(0, 6).map((network) => (
              <Card key={network.id} className="group hover:shadow-lg transition-all duration-200">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={network.logo || "/placeholder.svg"} alt={network.name} />
                        <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
                          {network.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-lg">{network.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">{network.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {network.status === "connected" && (
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Connected
                        </Badge>
                      )}
                      {network.status === "pending" && (
                        <Badge variant="outline" className="border-orange-200 text-orange-800">
                          <Clock className="w-3 h-3 mr-1" />
                          Pending
                        </Badge>
                      )}
                      {network.status === "disconnected" && (
                        <Badge variant="secondary">
                          <XCircle className="w-3 h-3 mr-1" />
                          Disconnected
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Key Metrics */}
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="text-lg font-bold">{network.merchants.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">Merchants</div>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="text-lg font-bold text-green-600">{network.avgCommission}</div>
                      <div className="text-xs text-muted-foreground">Avg Commission</div>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center justify-center space-x-1">
                        <Star className="h-3 w-3 text-yellow-500 fill-current" />
                        <span className="text-lg font-bold">{network.rating}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">Rating</div>
                    </div>
                  </div>

                  {/* Connection Health */}
                  {network.status === "connected" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Connection Health</span>
                        <span className="font-medium">{network.connectionHealth}%</span>
                      </div>
                      <Progress value={network.connectionHealth} className="h-2" />
                    </div>
                  )}

                  {/* Categories */}
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Categories</div>
                    <div className="flex flex-wrap gap-1">
                      {network.categories.slice(0, 3).map((category) => (
                        <Badge key={category} variant="outline" className="text-xs">
                          {category}
                        </Badge>
                      ))}
                      {network.categories.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{network.categories.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="text-xs text-muted-foreground">
                      {network.status === "connected" && `${network.linksImported} links imported`}
                      {network.status === "pending" && "Connection in progress..."}
                      {network.status === "disconnected" && `Min payout: ${network.minPayout}`}
                    </div>
                    <div className="flex space-x-2">
                      {network.status === "connected" && (
                        <>
                          <Button variant="outline" size="sm">
                            <Settings className="h-4 w-4 mr-1" />
                            Settings
                          </Button>
                          <Button variant="outline" size="sm">
                            <RefreshCw className="h-4 w-4 mr-1" />
                            Sync
                          </Button>
                        </>
                      )}
                      {network.status === "disconnected" && (
                        <Button size="sm" onClick={() => handleConnect(network.id)}>
                          <Plus className="h-4 w-4 mr-1" />
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="connected" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connected Networks</CardTitle>
              <CardDescription>Manage your active affiliate network connections</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {connectedNetworks.map((network) => (
                  <div key={network.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={network.logo || "/placeholder.svg"} alt={network.name} />
                          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
                            {network.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{network.name}</h3>
                          <p className="text-sm text-muted-foreground">{network.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked />
                        <Button variant="outline" size="sm">
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">API Status:</span>
                        <div className="flex items-center space-x-1 mt-1">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="font-medium">Active</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Last Sync:</span>
                        <div className="font-medium mt-1">{network.lastSync}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Links Imported:</span>
                        <div className="font-medium mt-1">{network.linksImported.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Health Score:</span>
                        <div className="font-medium mt-1 text-green-600">{network.connectionHealth}%</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex space-x-2">
                        {network.features.slice(0, 3).map((feature) => (
                          <Badge key={feature} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Pull Links
                        </Button>
                        <Button variant="outline" size="sm">
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Sync Now
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="available" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Available Networks</CardTitle>
              <CardDescription>Connect to new affiliate networks to expand your reach</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {availableNetworks.map((network) => (
                  <Card key={network.id} className="group hover:shadow-md transition-all duration-200">
                    <CardHeader className="pb-3">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={network.logo || "/placeholder.svg"} alt={network.name} />
                          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
                            {network.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h3 className="font-semibold">{network.name}</h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium">{network.rating}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">•</span>
                            <span className="text-sm text-green-600 font-medium">{network.avgCommission} avg</span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground line-clamp-2">{network.description}</p>

                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="text-muted-foreground">Merchants:</span>
                          <div className="font-medium">{network.merchants.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Min Payout:</span>
                          <div className="font-medium">{network.minPayout}</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="text-sm font-medium">Key Features</div>
                        <div className="flex flex-wrap gap-1">
                          {network.features.slice(0, 2).map((feature) => (
                            <Badge key={feature} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Button className="w-full" onClick={() => handleConnect(network.id)} disabled={isConnecting}>
                        {isConnecting ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Connecting...
                          </>
                        ) : (
                          <>
                            <Plus className="mr-2 h-4 w-4" />
                            Connect Network
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
