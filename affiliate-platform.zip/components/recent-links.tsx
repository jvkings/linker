import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ExternalLink, Copy, BarChart3, TrendingUp, TrendingDown } from "lucide-react"

const recentLinks = [
  {
    id: "1",
    title: "Apple AirPods Pro (2nd Generation)",
    shortUrl: "lnkm.pro/airpods-pro",
    destination: "Amazon",
    destinationLogo: "/placeholder.svg?height=32&width=32",
    clicks: 1247,
    conversions: 23,
    revenue: 345.67,
    status: "active",
    trending: "up",
    ctr: 3.2,
    createdAt: "2 hours ago",
  },
  {
    id: "2",
    title: "Fitbit Charge 5 Advanced Fitness Tracker",
    shortUrl: "lnkm.pro/fitbit-charge5",
    destination: "ShareASale",
    destinationLogo: "/placeholder.svg?height=32&width=32",
    clicks: 892,
    conversions: 15,
    revenue: 234.5,
    status: "active",
    trending: "up",
    ctr: 2.8,
    createdAt: "4 hours ago",
  },
  {
    id: "3",
    title: "SteelSeries Gaming Headset",
    shortUrl: "lnkm.pro/gaming-headset",
    destination: "Commission Junction",
    destinationLogo: "/placeholder.svg?height=32&width=32",
    clicks: 567,
    conversions: 8,
    revenue: 156.78,
    status: "active",
    trending: "down",
    ctr: 1.9,
    createdAt: "6 hours ago",
  },
]

export function RecentLinks() {
  return (
    <Card className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader>
        <CardTitle>Recent Links</CardTitle>
        <CardDescription>Your most recently created affiliate links</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentLinks.map((link) => (
            <div
              key={link.id}
              className="flex items-center justify-between p-4 border rounded-lg bg-white dark:bg-slate-800 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={link.destinationLogo || "/placeholder.svg"} alt={link.destination} />
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-sm font-semibold">
                    {link.destination.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <p className="text-sm font-medium truncate">{link.title}</p>
                    {link.trending === "up" ? (
                      <TrendingUp className="h-3 w-3 text-green-500 flex-shrink-0" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-red-500 flex-shrink-0" />
                    )}
                  </div>

                  <div className="flex items-center space-x-4 text-xs text-muted-foreground mb-2">
                    <span>{link.destination}</span>
                    <span>•</span>
                    <span>{link.createdAt}</span>
                    <span>•</span>
                    <span className="font-mono">{link.shortUrl}</span>
                  </div>

                  <div className="flex items-center space-x-4 text-xs">
                    <div className="flex items-center space-x-1">
                      <span className="text-muted-foreground">Clicks:</span>
                      <span className="font-semibold text-blue-600">{link.clicks.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-muted-foreground">Conv:</span>
                      <span className="font-semibold text-green-600">{link.conversions}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-muted-foreground">Revenue:</span>
                      <span className="font-semibold text-purple-600">${link.revenue}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-muted-foreground">CTR:</span>
                      <span className="font-semibold">{link.ctr}%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 ml-4">
                <Badge
                  variant={link.status === "active" ? "default" : "secondary"}
                  className={
                    link.status === "active" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" : ""
                  }
                >
                  {link.status}
                </Badge>

                <div className="flex items-center space-x-1">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <BarChart3 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
