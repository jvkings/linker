"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Upload, Link2, BarChart3, Copy, ExternalLink, Edit, Trash2 } from "lucide-react"

const mockLinks = [
  {
    id: "1",
    originalUrl: "https://amazon.com/dp/B08N5WRWNW?tag=affiliate123",
    shortUrl: "https://mylinks.io/amz1",
    prettyUrl: "https://shop.mylinks.io/wireless-earbuds",
    title: "Apple AirPods Pro",
    destination: "Amazon",
    clicks: 1247,
    conversions: 23,
    revenue: 345.67,
    tags: ["electronics", "audio", "apple"],
    createdAt: "2024-01-15T10:30:00Z",
    status: "active",
  },
  {
    id: "2",
    originalUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
    shortUrl: "https://mylinks.io/sas1",
    prettyUrl: "https://deals.mylinks.io/fitness-tracker",
    title: "Fitness Tracker Pro",
    destination: "ShareASale",
    clicks: 892,
    conversions: 15,
    revenue: 234.5,
    tags: ["fitness", "health", "wearables"],
    createdAt: "2024-01-14T15:45:00Z",
    status: "active",
  },
]

export function LinkManager() {
  const [newLink, setNewLink] = useState({
    url: "",
    title: "",
    prettyUrl: "",
    tags: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle link creation
    console.log("Creating link:", newLink)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="manage" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="add">Add Link</TabsTrigger>
          <TabsTrigger value="manage">Manage Links</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Actions</TabsTrigger>
        </TabsList>

        <TabsContent value="add" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Add New Affiliate Link</CardTitle>
              <CardDescription>Create a new shortened and prettified affiliate link</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="url">Original Affiliate URL</Label>
                  <Input
                    id="url"
                    placeholder="https://amazon.com/dp/B08N5WRWNW?tag=affiliate123"
                    value={newLink.url}
                    onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Link Title</Label>
                  <Input
                    id="title"
                    placeholder="Apple AirPods Pro"
                    value={newLink.title}
                    onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="prettyUrl">Pretty URL (optional)</Label>
                  <Input
                    id="prettyUrl"
                    placeholder="https://shop.mylinks.io/wireless-earbuds"
                    value={newLink.prettyUrl}
                    onChange={(e) => setNewLink({ ...newLink, prettyUrl: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma separated)</Label>
                  <Input
                    id="tags"
                    placeholder="electronics, audio, apple"
                    value={newLink.tags}
                    onChange={(e) => setNewLink({ ...newLink, tags: e.target.value })}
                  />
                </div>

                <Button type="submit" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Create Link
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="manage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Affiliate Links</CardTitle>
              <CardDescription>Manage and monitor your affiliate link performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockLinks.map((link) => (
                  <div key={link.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h3 className="font-semibold">{link.title}</h3>
                        <p className="text-sm text-muted-foreground">{link.destination}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs text-muted-foreground">Short URL:</div>
                      <div className="text-sm font-mono bg-muted p-2 rounded">{link.shortUrl}</div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs text-muted-foreground">Pretty URL:</div>
                      <div className="text-sm font-mono bg-muted p-2 rounded">{link.prettyUrl}</div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm">
                        <span>{link.clicks} clicks</span>
                        <span>{link.conversions} conversions</span>
                        <span>${link.revenue} revenue</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        {link.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bulk Actions</CardTitle>
              <CardDescription>Import multiple links or perform bulk operations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Button variant="outline" className="h-24 flex-col bg-transparent">
                  <Upload className="h-8 w-8 mb-2" />
                  Import CSV
                </Button>
                <Button variant="outline" className="h-24 flex-col bg-transparent">
                  <Link2 className="h-8 w-8 mb-2" />
                  Bulk Prettify
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="csv">CSV File Upload</Label>
                <Input id="csv" type="file" accept=".csv" />
                <p className="text-xs text-muted-foreground">Upload a CSV file with columns: url, title, tags</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bulk-urls">Bulk URL Input</Label>
                <Textarea id="bulk-urls" placeholder="Paste multiple URLs, one per line..." rows={6} />
              </div>

              <Button className="w-full">Process Links</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
