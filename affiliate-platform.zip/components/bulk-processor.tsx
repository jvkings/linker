"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Zap, Link2, Tag, CheckCircle, Download, RefreshCw } from "lucide-react"

export function BulkProcessor() {
  const [urls, setUrls] = useState("")
  const [selectedActions, setSelectedActions] = useState<string[]>(["shorten"])
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [processedLinks, setProcessedLinks] = useState<any[]>([])

  const actions = [
    { id: "shorten", label: "Shorten URLs", icon: Link2 },
    { id: "prettify", label: "Prettify URLs", icon: Zap },
    { id: "tag", label: "Auto-tag with keywords", icon: Tag },
  ]

  const handleActionToggle = (actionId: string) => {
    setSelectedActions((prev) => (prev.includes(actionId) ? prev.filter((id) => id !== actionId) : [...prev, actionId]))
  }

  const handleBulkProcess = async () => {
    if (!urls.trim()) return

    setIsProcessing(true)
    setProgress(0)

    const urlList = urls.split("\n").filter((url) => url.trim())

    // Simulate processing with progress updates
    for (let i = 0; i <= 100; i += 10) {
      setProgress(i)
      await new Promise((resolve) => setTimeout(resolve, 200))
    }

    // Mock processed results
    const mockResults = urlList.map((url, index) => ({
      id: `bulk_${Date.now()}_${index}`,
      originalUrl: url.trim(),
      shortUrl: selectedActions.includes("shorten")
        ? `https://mylinks.io/${Math.random().toString(36).substr(2, 6)}`
        : null,
      prettyUrl: selectedActions.includes("prettify")
        ? `https://shop.mylinks.io/deal-${Math.random().toString(36).substr(2, 4)}`
        : null,
      destination: detectDestination(url),
      keywords: selectedActions.includes("tag") ? getKeywords(url) : [],
      status: "processed",
    }))

    setProcessedLinks(mockResults)
    setIsProcessing(false)
  }

  const detectDestination = (url: string) => {
    if (url.includes("youtube.com")) return "YouTube"
    if (url.includes("amazon.com")) return "Amazon"
    if (url.includes("claude.ai")) return "Claude AI"
    return "Website"
  }

  const getKeywords = (url: string) => {
    if (url.includes("youtube.com")) return ["youtube", "video", "entertainment"]
    if (url.includes("amazon.com")) return ["amazon", "shopping", "ecommerce"]
    if (url.includes("claude.ai")) return ["claude", "ai", "chatbot"]
    return ["website", "link"]
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="bulk" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="bulk">Bulk URL Processing</TabsTrigger>
          <TabsTrigger value="csv">CSV Import</TabsTrigger>
        </TabsList>

        <TabsContent value="bulk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bulk URL Processing</CardTitle>
              <CardDescription>
                Process multiple URLs at once with automated shortening, prettification, and tagging
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="urls">URLs (one per line)</Label>
                <Textarea
                  id="urls"
                  placeholder={`https://claude.ai/chat/c570b4c1-385f-4883-bbf1-e4de60018f7f
https://preview--web-alchemy-generator.lovable.app/mobile-app-generator
https://www.youtube.com/watch?v=example
https://amazon.com/dp/B08N5WRWNW?tag=affiliate123`}
                  value={urls}
                  onChange={(e) => setUrls(e.target.value)}
                  rows={8}
                  className="font-mono text-sm"
                />
              </div>

              <div className="space-y-3">
                <Label>Processing Actions</Label>
                <div className="grid gap-3 md:grid-cols-3">
                  {actions.map((action) => (
                    <div key={action.id} className="flex items-center space-x-2 p-3 border rounded-lg">
                      <Checkbox
                        id={action.id}
                        checked={selectedActions.includes(action.id)}
                        onCheckedChange={() => handleActionToggle(action.id)}
                      />
                      <action.icon className="h-4 w-4" />
                      <Label htmlFor={action.id} className="text-sm font-medium">
                        {action.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {isProcessing && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Processing URLs...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="w-full" />
                </div>
              )}

              <Button
                onClick={handleBulkProcess}
                disabled={!urls.trim() || selectedActions.length === 0 || isProcessing}
                className="w-full"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Process {urls.split("\n").filter((url) => url.trim()).length} URLs
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {processedLinks.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Processing Results</CardTitle>
                <CardDescription>{processedLinks.length} URLs processed successfully</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {processedLinks.map((link) => (
                    <div key={link.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="font-medium">{link.destination}</span>
                        </div>
                        <Badge variant="secondary">{link.status}</Badge>
                      </div>

                      <div className="text-sm space-y-1">
                        <div>
                          <span className="text-muted-foreground">Original:</span>
                          <div className="font-mono bg-muted p-1 rounded text-xs break-all">{link.originalUrl}</div>
                        </div>

                        {link.shortUrl && (
                          <div>
                            <span className="text-muted-foreground">Short URL:</span>
                            <div className="font-mono bg-muted p-1 rounded text-xs">{link.shortUrl}</div>
                          </div>
                        )}

                        {link.prettyUrl && (
                          <div>
                            <span className="text-muted-foreground">Pretty URL:</span>
                            <div className="font-mono bg-muted p-1 rounded text-xs">{link.prettyUrl}</div>
                          </div>
                        )}
                      </div>

                      {link.keywords.length > 0 && (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">Keywords:</span>
                          {link.keywords.map((keyword: string) => (
                            <Badge key={keyword} variant="outline" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex justify-end">
                  <Button variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Export Results
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="csv" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CSV Import</CardTitle>
              <CardDescription>Import affiliate links from a CSV file with columns: url, title, tags</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Upload CSV File</h3>
                  <p className="text-sm text-muted-foreground">Drag and drop your CSV file here, or click to browse</p>
                </div>
                <Button variant="outline" className="mt-4 bg-transparent">
                  Choose File
                </Button>
              </div>

              <div className="text-sm text-muted-foreground">
                <p className="font-medium mb-2">CSV Format Requirements:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Column 1: url (required) - The affiliate URL</li>
                  <li>Column 2: title (optional) - Link title/description</li>
                  <li>Column 3: tags (optional) - Comma-separated tags</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
