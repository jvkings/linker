import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, TrendingUp, AlertTriangle, Lightbulb, Target } from "lucide-react"

export function AIInsights() {
  const insights = [
    {
      type: "optimization",
      title: "Link Performance Boost",
      description: "3 links could benefit from keyword optimization",
      impact: "High",
      icon: TrendingUp,
      color: "green",
      action: "Optimize Now",
    },
    {
      type: "warning",
      title: "Declining CTR Detected",
      description: "Amazon links showing 15% CTR decrease",
      impact: "Medium",
      icon: AlertTriangle,
      color: "orange",
      action: "Investigate",
    },
    {
      type: "suggestion",
      title: "New Keyword Opportunity",
      description: "Consider targeting 'wireless earbuds' keyword",
      impact: "Medium",
      icon: Lightbulb,
      color: "blue",
      action: "Add Keywords",
    },
    {
      type: "target",
      title: "Conversion Goal",
      description: "You're 87% towards monthly target",
      impact: "Low",
      icon: Target,
      color: "purple",
      action: "View Progress",
    },
  ]

  const getColorClasses = (color: string) => {
    const colors = {
      green: "text-green-600 bg-green-100 dark:bg-green-900",
      orange: "text-orange-600 bg-orange-100 dark:bg-orange-900",
      blue: "text-blue-600 bg-blue-100 dark:bg-blue-900",
      purple: "text-purple-600 bg-purple-100 dark:bg-purple-900",
    }
    return colors[color as keyof typeof colors] || colors.blue
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "High":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "Low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <Card className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="h-5 w-5 text-purple-600" />
          <span>AI Insights</span>
        </CardTitle>
        <CardDescription>Intelligent recommendations for optimization</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className="flex items-start space-x-3 p-3 rounded-lg border bg-white dark:bg-slate-800 hover:shadow-sm transition-shadow"
          >
            <div className={`p-2 rounded-lg ${getColorClasses(insight.color)}`}>
              <insight.icon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-medium truncate">{insight.title}</h4>
                <Badge variant="outline" className={`text-xs ${getImpactColor(insight.impact)}`}>
                  {insight.impact}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{insight.description}</p>
              <button className="text-xs text-blue-600 hover:text-blue-800 font-medium">{insight.action} →</button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
