"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Globe, Zap, Search, Link2, CheckCircle, Code, Smartphone, Monitor } from "lucide-react"

const connectedWebsites = [
  {
    id: "site_001",
    domain: "myblog.com",
    platform: "WordPress",
    status: "active",
    autoLinkingEnabled: true,
    keywordMatches: 156,
    linksInjected: 89,
    lastSync: "2024-01-15T10:30:00Z",
  },
  {
    id: "site_002",
    domain: "mystore.shopify.com",
    platform: "Shopify",
    status: "active",
    autoLinkingEnabled: true,
    keywordMatches: 234,
    linksInjected: 167,
    lastSync: "2024-01-15T09:45:00Z",
  },
]

const keywordMappings = [
  {
    keyword: "youtube",
    matchedLinks: [
      {
        id: "link_001",
        title: "YouTube Premium Subscription",
        shortUrl: "https://mylinks.io/yt1",
        destination: "YouTube",
        priority: 1,
      },
    ],
  },
  {
    keyword: "claude",
    matchedLinks: [
      {
        id: "link_002",
        title: "Claude AI Assistant",
        shortUrl: "https://mylinks.io/claude1",
        destination: "Claude AI",
        priority: 1,
      },
    ],
  },
]

export function AutoLinkingManager() {
  const [activeTab, setActiveTab] = useState("websites")
  const [testContent, setTestContent] = useState("")
  const [scanResults, setScanResults] = useState<any[]>([])

  const handleContentScan = async () => {
    // Simulate content scanning
    const keywords = keywordMappings.map((m) => m.keyword)
    const foundKeywords = keywords.filter((keyword) => testContent.toLowerCase().includes(keyword.toLowerCase()))

    const results = foundKeywords.map((keyword) => ({
      keyword,
      position: testContent.toLowerCase().indexOf(keyword.toLowerCase()),
      context: testContent.substring(
        Math.max(0, testContent.toLowerCase().indexOf(keyword.toLowerCase()) - 30),
        testContent.toLowerCase().indexOf(keyword.toLowerCase()) + keyword.length + 30,
      ),
      suggestedLink: keywordMappings.find((m) => m.keyword === keyword)?.matchedLinks[0],
    }))

    setScanResults(results)
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="websites">Connected Sites</TabsTrigger>
          <TabsTrigger value="keywords">Keyword Mapping</TabsTrigger>
          <TabsTrigger value="testing">Content Testing</TabsTrigger>
          <TabsTrigger value="integration">Integration Code</TabsTrigger>
        </TabsList>

        <TabsContent value="websites" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connected Websites & Apps</CardTitle>
              <CardDescription>Manage websites and applications with auto-linking integration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {connectedWebsites.map((site) => (
                  <div key={site.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                          <Globe className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{site.domain}</h3>
                          <p className="text-sm text-muted-foreground">{site.platform}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={site.status === "active" ? "default" : "secondary"}>{site.status}</Badge>
                        <Switch checked={site.autoLinkingEnabled} onCheckedChange={() => {}} />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Keywords Found:</span>
                        <div className="font-semibold">{site.keywordMatches}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Links Injected:</span>
                        <div className="font-semibold">{site.linksInjected}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Last Sync:</span>
                        <div>{new Date(site.lastSync).toLocaleDateString()}</div>
                      </div>
                    </div>

                    <div className="mt-3 flex justify-end space-x-2">
                      <Button variant="outline" size="sm">
                        <Code className="mr-2 h-4 w-4" />
                        View Code
                      </Button>
                      <Button variant="outline" size="sm">
                        <Zap className="mr-2 h-4 w-4" />
                        Sync Now
                      </Button>
                    </div>
                  </div>
                ))}

                <Card className="border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-8">
                    <Globe className="h-12 w-12 text-muted-foreground/50 mb-4" />
                    <h3 className="text-lg font-medium mb-2">Add New Website</h3>
                    <p className="text-sm text-muted-foreground mb-4 text-center">
                      Connect a new website or app to enable auto-linking
                    </p>
                    <Button>
                      <Globe className="mr-2 h-4 w-4" />
                      Add Website
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="keywords" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Keyword to Link Mapping</CardTitle>
              <CardDescription>
                Configure which affiliate links to inject when specific keywords are detected
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {keywordMappings.map((mapping, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="font-mono">
                          {mapping.keyword}
                        </Badge>
                        <span className="text-sm text-muted-foreground">→ {mapping.matchedLinks.length} link(s)</span>
                      </div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>

                    <div className="space-y-2">
                      {mapping.matchedLinks.map((link) => (
                        <div key={link.id} className="flex items-center justify-between p-2 bg-muted rounded">
                          <div>
                            <span className="font-medium">{link.title}</span>
                            <span className="text-sm text-muted-foreground ml-2">({link.destination})</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary">Priority {link.priority}</Badge>
                            <span className="text-xs font-mono">{link.shortUrl}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <Card className="border-dashed">
                  <CardContent className="py-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="new-keyword">Keyword</Label>
                        <Input id="new-keyword" placeholder="Enter keyword..." />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="select-link">Select Link</Label>
                        <select className="w-full p-2 border rounded-md">
                          <option>Choose affiliate link...</option>
                          <option>YouTube Premium - mylinks.io/yt1</option>
                          <option>Claude AI - mylinks.io/claude1</option>
                        </select>
                      </div>
                    </div>
                    <Button className="mt-4">
                      <Link2 className="mr-2 h-4 w-4" />
                      Add Mapping
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Content Testing</CardTitle>
              <CardDescription>Test how auto-linking will work with your content before deploying</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="test-content">Test Content</Label>
                <Textarea
                  id="test-content"
                  placeholder="Paste your content here to test keyword detection and link injection..."
                  value={testContent}
                  onChange={(e) => setTestContent(e.target.value)}
                  rows={6}
                />
              </div>

              <Button onClick={handleContentScan} disabled={!testContent.trim()}>
                <Search className="mr-2 h-4 w-4" />
                Scan for Keywords
              </Button>

              {scanResults.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-semibold">Scan Results</h3>
                  {scanResults.map((result, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <Badge variant="outline">{result.keyword}</Badge>
                          <span className="text-sm text-muted-foreground">Position: {result.position}</span>
                        </div>
                        <Badge variant="secondary">{result.suggestedLink?.destination}</Badge>
                      </div>

                      <div className="text-sm mb-2">
                        <span className="text-muted-foreground">Context:</span>
                        <div className="font-mono bg-muted p-2 rounded text-xs">...{result.context}...</div>
                      </div>

                      <div className="text-sm">
                        <span className="text-muted-foreground">Suggested Link:</span>
                        <div className="font-medium">
                          {result.suggestedLink?.title} ({result.suggestedLink?.shortUrl})
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Integration Code</CardTitle>
              <CardDescription>
                Copy and paste these code snippets to integrate auto-linking into your websites
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Monitor className="h-4 w-4" />
                    <h3 className="font-semibold">JavaScript SDK</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">Add this script to your website's head section</p>
                  <div className="bg-muted p-4 rounded-lg font-mono text-sm">
                    {`<script src="https://cdn.affiliatehub.com/auto-link.js"></script>
<script>
  AffiliateHub.init({
    apiKey: 'your-api-key-here',
    autoLink: true,
    maxLinksPerPage: 3,
    keywords: ['youtube', 'claude', 'amazon']
  });
</script>`}
                  </div>
                </div>

                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Code className="h-4 w-4" />
                    <h3 className="font-semibold">WordPress Plugin</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Install our WordPress plugin for seamless integration
                  </p>
                  <div className="flex space-x-2">
                    <Button variant="outline">Download Plugin</Button>
                    <Button variant="outline">View Documentation</Button>
                  </div>
                </div>

                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Smartphone className="h-4 w-4" />
                    <h3 className="font-semibold">React/Next.js Component</h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Use our React component for modern web applications
                  </p>
                  <div className="bg-muted p-4 rounded-lg font-mono text-sm">
                    {`import { AutoLinker } from '@affiliatehub/react';

function MyComponent() {
  return (
    <AutoLinker 
      apiKey="your-api-key"
      keywords={['youtube', 'claude', 'amazon']}
    >
      <p>Your content with keywords like YouTube and Claude AI</p>
    </AutoLinker>
  );
}`}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
