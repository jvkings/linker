"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { RefreshCw, ExternalLink, Activity } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ActivityItem {
  id: number
  type: string
  description: string
  url: string | null
  shortUrl: string | null
  timestamp: string
  status: "success" | "warning" | "error"
  integration: string
  clicks: number
}

interface ActivityResponse {
  activities: ActivityItem[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export function RecentActivity() {
  const [activities, setActivities] = useState<ActivityItem[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const { toast } = useToast()

  const fetchActivities = async (showRefreshToast = false) => {
    try {
      if (showRefreshToast) setRefreshing(true)

      const response = await fetch("/api/activity?limit=5")
      if (!response.ok) throw new Error("Failed to fetch activities")

      const data: ActivityResponse = await response.json()
      setActivities(data.activities)

      if (showRefreshToast) {
        toast({
          title: "Activities refreshed",
          description: "Latest activity data has been loaded.",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load activities. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    fetchActivities()
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800"
      case "warning":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "link_created":
        return "🔗"
      case "link_updated":
        return "✏️"
      case "dead_link_detected":
        return "⚠️"
      case "bulk_operation":
        return "📦"
      case "automation_triggered":
        return "🤖"
      default:
        return "📝"
    }
  }

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date()
    const time = new Date(timestamp)
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="mr-2 h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-3 animate-pulse">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest actions and updates across your links</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => fetchActivities(true)} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px]">
          <div className="space-y-4">
            {activities.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="text-lg">{getTypeIcon(activity.type)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">{activity.description}</p>
                    <Badge className={getStatusColor(activity.status)}>{activity.status}</Badge>
                  </div>
                  <div className="mt-1 flex items-center space-x-2 text-xs text-gray-500">
                    <span>{activity.integration}</span>
                    <span>•</span>
                    <span>{formatTimeAgo(activity.timestamp)}</span>
                    {activity.clicks > 0 && (
                      <>
                        <span>•</span>
                        <span>{activity.clicks} clicks</span>
                      </>
                    )}
                  </div>
                  {activity.shortUrl && (
                    <div className="mt-2 flex items-center space-x-2">
                      <code className="text-xs bg-gray-100 px-2 py-1 rounded">{activity.shortUrl}</code>
                      {activity.url && (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={activity.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="mt-4 text-center">
          <Button variant="outline" size="sm">
            View All Activity
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
