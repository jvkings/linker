import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, DollarSign, Target, MousePointer } from "lucide-react"

const topPerformers = [
  {
    name: "Apple AirPods Pro",
    revenue: 1245.67,
    percentage: 100,
    clicks: 3421,
    conversions: 89,
    ctr: 2.6,
    network: "Amazon",
    trend: "up",
  },
  {
    name: "Fitbit Charge 5",
    revenue: 934.5,
    percentage: 75,
    clicks: 2876,
    conversions: 67,
    ctr: 2.3,
    network: "ShareASale",
    trend: "up",
  },
  {
    name: "Gaming Headset Pro",
    revenue: 689.23,
    percentage: 55,
    clicks: 2134,
    conversions: 45,
    ctr: 2.1,
    network: "CJ Affiliate",
    trend: "down",
  },
  {
    name: "Wireless Charger",
    revenue: 456.78,
    percentage: 37,
    clicks: 1567,
    conversions: 32,
    ctr: 2.0,
    network: "Rakuten",
    trend: "up",
  },
  {
    name: "Bluetooth Speaker",
    revenue: 323.45,
    percentage: 26,
    clicks: 1234,
    conversions: 23,
    ctr: 1.9,
    network: "Impact",
    trend: "up",
  },
]

export function TopPerformers() {
  return (
    <Card className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <TrendingUp className="h-5 w-5 text-green-600" />
          <span>Top Performers</span>
        </CardTitle>
        <CardDescription>Highest revenue generating links this month</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {topPerformers.map((item, index) => (
            <div key={index} className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center justify-center w-6 h-6 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <span className="font-medium text-sm">{item.name}</span>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {item.network}
                      </Badge>
                      <div className="flex items-center space-x-1">
                        {item.trend === "up" ? (
                          <TrendingUp className="h-3 w-3 text-green-500" />
                        ) : (
                          <TrendingUp className="h-3 w-3 text-red-500 rotate-180" />
                        )}
                        <span className="text-xs text-muted-foreground">{item.ctr}% CTR</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-1">
                    <DollarSign className="h-4 w-4 text-green-600" />
                    <span className="font-bold text-green-600">${item.revenue.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-muted-foreground mt-1">
                    <div className="flex items-center space-x-1">
                      <MousePointer className="h-3 w-3" />
                      <span>{item.clicks.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Target className="h-3 w-3" />
                      <span>{item.conversions}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <Progress value={item.percentage} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Performance Score</span>
                  <span>{item.percentage}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
