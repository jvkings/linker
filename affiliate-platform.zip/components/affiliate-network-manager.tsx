"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Globe,
  ImageIcon,
  Code,
  FileText,
  Download,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Copy,
  ExternalLink,
} from "lucide-react"

const mockNetworkData = {
  text: [
    {
      id: "txt_001",
      network: "ShareASale",
      advertiser: "TechGear Pro",
      linkUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
      linkText: "Best Wireless Headphones - 50% Off",
      category: "Electronics",
      commission: "8%",
      keywords: ["headphones", "wireless", "audio", "electronics"],
    },
  ],
  image: [
    {
      id: "img_001",
      network: "ShareASale",
      advertiser: "TechGear Pro",
      linkUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
      imageUrl: "/placeholder.svg?height=250&width=300",
      altText: "Wireless Headphones Banner",
      dimensions: "300x250",
      category: "Electronics",
      commission: "8%",
      keywords: ["headphones", "banner", "electronics"],
    },
  ],
  html: [
    {
      id: "html_001",
      network: "ShareASale",
      advertiser: "HealthSupplements",
      linkUrl: "https://shareasale.com/r.cfm?b=345678&u=123&m=45678",
      htmlCode: `<div style="border:1px solid #ccc; padding:10px; text-align:center;">
        <h3>Premium Health Supplements</h3>
        <p>Get 25% off your first order!</p>
        <a href="#" style="background:#007cba; color:white; padding:10px 20px; text-decoration:none;">Shop Now</a>
      </div>`,
      category: "Health",
      commission: "20%",
      keywords: ["health", "supplements", "wellness", "nutrition"],
    },
  ],
  javascript: [
    {
      id: "js_001",
      network: "Commission Junction",
      advertiser: "BookStore Plus",
      linkUrl: "https://cj.com/click-789012-345",
      jsCode: `<script type="text/javascript">
        (function() {
          var script = document.createElement('script');
          script.src = 'https://cj.com/widgets/bookstore-widget.js';
          script.async = true;
          document.head.appendChild(script);
        })();
      </script>`,
      category: "Education",
      commission: "10%",
      keywords: ["books", "education", "reading", "widget"],
    },
  ],
}

export function AffiliateNetworkManager() {
  const [activeTab, setActiveTab] = useState("text")
  const [selectedNetwork, setSelectedNetwork] = useState("shareasale")
  const [apiKey, setApiKey] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)

  const handleConnect = async () => {
    setIsConnecting(true)
    // Simulate API connection
    setTimeout(() => {
      setIsConnecting(false)
    }, 2000)
  }

  const handlePullLinks = async (type: string) => {
    // Simulate pulling links from network
    console.log(`Pulling ${type} links from ${selectedNetwork}`)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Affiliate Network API Configuration</CardTitle>
          <CardDescription>Connect to affiliate networks to pull links automatically</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="network">Select Network</Label>
              <select
                id="network"
                className="w-full p-2 border rounded-md"
                value={selectedNetwork}
                onChange={(e) => setSelectedNetwork(e.target.value)}
              >
                <option value="shareasale">ShareASale</option>
                <option value="cj">Commission Junction</option>
                <option value="rakuten">Rakuten Advertising</option>
                <option value="amazon">Amazon Associates</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="apiKey">API Key</Label>
              <Input
                id="apiKey"
                type="password"
                placeholder="Enter your API key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
              />
            </div>

            <div className="flex items-end">
              <Button onClick={handleConnect} disabled={!apiKey || isConnecting} className="w-full">
                {isConnecting ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Connect
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pull Affiliate Links by Type</CardTitle>
          <CardDescription>Import different types of affiliate content from connected networks</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="text" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Text Links
              </TabsTrigger>
              <TabsTrigger value="image" className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                Image Links
              </TabsTrigger>
              <TabsTrigger value="html" className="flex items-center gap-2">
                <Code className="h-4 w-4" />
                HTML Blocks
              </TabsTrigger>
              <TabsTrigger value="javascript" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                JS Scripts
              </TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Text-based Affiliate Links</h3>
                <Button onClick={() => handlePullLinks("text")}>
                  <Download className="mr-2 h-4 w-4" />
                  Pull Text Links
                </Button>
              </div>

              <div className="space-y-3">
                {mockNetworkData.text.map((link) => (
                  <div key={link.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-medium">{link.linkText}</h4>
                        <p className="text-sm text-muted-foreground">
                          {link.advertiser} • {link.network}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{link.commission}</Badge>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="text-sm font-mono bg-muted p-2 rounded mb-2">{link.linkUrl}</div>

                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{link.category}</Badge>
                      {link.keywords.map((keyword) => (
                        <Badge key={keyword} variant="secondary" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="image" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Image-based Affiliate Links</h3>
                <Button onClick={() => handlePullLinks("image")}>
                  <Download className="mr-2 h-4 w-4" />
                  Pull Image Links
                </Button>
              </div>

              <div className="space-y-3">
                {mockNetworkData.image.map((link) => (
                  <div key={link.id} className="border rounded-lg p-4">
                    <div className="flex gap-4">
                      <img
                        src={link.imageUrl || "/placeholder.svg"}
                        alt={link.altText}
                        className="w-24 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-medium">{link.altText}</h4>
                            <p className="text-sm text-muted-foreground">
                              {link.advertiser} • {link.dimensions} • {link.network}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary">{link.commission}</Badge>
                            <Button variant="ghost" size="sm">
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="text-sm font-mono bg-muted p-2 rounded mb-2">{link.linkUrl}</div>

                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{link.category}</Badge>
                          {link.keywords.map((keyword) => (
                            <Badge key={keyword} variant="secondary" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="html" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">HTML Block Affiliate Links</h3>
                <Button onClick={() => handlePullLinks("html")}>
                  <Download className="mr-2 h-4 w-4" />
                  Pull HTML Blocks
                </Button>
              </div>

              <div className="space-y-3">
                {mockNetworkData.html.map((link) => (
                  <div key={link.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-medium">{link.advertiser} HTML Block</h4>
                        <p className="text-sm text-muted-foreground">{link.network}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{link.commission}</Badge>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="mb-3">
                      <Label className="text-sm font-medium">Preview:</Label>
                      <div
                        className="border rounded p-3 bg-white"
                        dangerouslySetInnerHTML={{ __html: link.htmlCode }}
                      />
                    </div>

                    <div className="mb-3">
                      <Label className="text-sm font-medium">HTML Code:</Label>
                      <Textarea value={link.htmlCode} readOnly className="font-mono text-sm" rows={4} />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{link.category}</Badge>
                      {link.keywords.map((keyword) => (
                        <Badge key={keyword} variant="secondary" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="javascript" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">JavaScript-based Affiliate Links</h3>
                <Button onClick={() => handlePullLinks("javascript")}>
                  <Download className="mr-2 h-4 w-4" />
                  Pull JS Scripts
                </Button>
              </div>

              <div className="space-y-3">
                {mockNetworkData.javascript.map((link) => (
                  <div key={link.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-medium">{link.advertiser} Widget</h4>
                        <p className="text-sm text-muted-foreground">{link.network}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{link.commission}</Badge>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="mb-3">
                      <Label className="text-sm font-medium">JavaScript Code:</Label>
                      <Textarea value={link.jsCode} readOnly className="font-mono text-sm" rows={6} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{link.category}</Badge>
                        {link.keywords.map((keyword) => (
                          <Badge key={keyword} variant="secondary" className="text-xs">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <AlertCircle className="h-4 w-4" />
                        <span>Test in staging first</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
