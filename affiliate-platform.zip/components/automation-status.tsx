"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Zap, Settings, TrendingUp } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface AutomationRule {
  id: number
  name: string
  type: string
  status: "active" | "paused"
  website: string
  keywords?: string[]
  actionsToday: number
  totalActions: number
  lastTriggered: string
}

interface AutomationData {
  summary: {
    totalRules: number
    activeRules: number
    pausedRules: number
    totalActions: number
    actionsToday: number
  }
  rules: AutomationRule[]
}

export function AutomationStatus() {
  const [automationData, setAutomationData] = useState<AutomationData | null>(null)
  const [loading, setLoading] = useState(true)
  const [toggling, setToggling] = useState<number | null>(null)
  const { toast } = useToast()

  const fetchAutomationData = async () => {
    try {
      const response = await fetch("/api/automation")
      if (!response.ok) throw new Error("Failed to fetch automation data")

      const data: AutomationData = await response.json()
      setAutomationData(data)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load automation data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const toggleRule = async (ruleId: number, currentStatus: string) => {
    try {
      setToggling(ruleId)

      const response = await fetch("/api/automation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "toggle-rule",
          ruleId,
          status: currentStatus,
        }),
      })

      if (!response.ok) throw new Error("Failed to toggle rule")

      const result = await response.json()

      toast({
        title: "Rule updated",
        description: result.message,
      })

      // Update local state
      if (automationData) {
        const updatedRules = automationData.rules.map((rule) =>
          rule.id === ruleId ? { ...rule, status: result.newStatus } : rule,
        )
        setAutomationData({
          ...automationData,
          rules: updatedRules,
          summary: {
            ...automationData.summary,
            activeRules: updatedRules.filter((r) => r.status === "active").length,
            pausedRules: updatedRules.filter((r) => r.status === "paused").length,
          },
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to toggle rule. Please try again.",
        variant: "destructive",
      })
    } finally {
      setToggling(null)
    }
  }

  useEffect(() => {
    fetchAutomationData()
  }, [])

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date()
    const time = new Date(timestamp)
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "keyword_linking":
        return "🔗"
      case "dead_link_replacement":
        return "🔄"
      case "social_sync":
        return "📱"
      case "link_prettification":
        return "✨"
      default:
        return "⚙️"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "keyword_linking":
        return "bg-blue-100 text-blue-800"
      case "dead_link_replacement":
        return "bg-red-100 text-red-800"
      case "social_sync":
        return "bg-purple-100 text-purple-800"
      case "link_prettification":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Automation Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="grid grid-cols-2 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!automationData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Automation Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Failed to load automation data</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Zap className="mr-2 h-5 w-5" />
              Automation Status
            </CardTitle>
            <CardDescription>
              {automationData.summary.activeRules} of {automationData.summary.totalRules} rules active •{" "}
              {automationData.summary.actionsToday} actions today
            </CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Manage
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{automationData.summary.actionsToday}</div>
            <div className="text-xs text-blue-600">Actions Today</div>
          </div>
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {automationData.summary.totalActions.toLocaleString()}
            </div>
            <div className="text-xs text-green-600">Total Actions</div>
          </div>
        </div>

        {/* Active Rules */}
        <div>
          <h4 className="text-sm font-medium mb-3">Automation Rules</h4>
          <ScrollArea className="h-[250px]">
            <div className="space-y-3">
              {automationData.rules.map((rule) => (
                <div key={rule.id} className="p-3 border rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{getTypeIcon(rule.type)}</span>
                      <div>
                        <div className="font-medium text-sm">{rule.name}</div>
                        <div className="text-xs text-gray-500">{rule.website}</div>
                      </div>
                    </div>
                    <Switch
                      checked={rule.status === "active"}
                      onCheckedChange={() => toggleRule(rule.id, rule.status)}
                      disabled={toggling === rule.id}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge className={getTypeColor(rule.type)}>{rule.type.replace("_", " ")}</Badge>
                    <div className="flex items-center space-x-2 text-xs text-gray-500">
                      <TrendingUp className="h-3 w-3" />
                      <span>{rule.actionsToday} today</span>
                    </div>
                  </div>

                  {rule.keywords && rule.keywords.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {rule.keywords.slice(0, 3).map((keyword, index) => (
                        <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                          {keyword}
                        </span>
                      ))}
                      {rule.keywords.length > 3 && (
                        <span className="text-xs text-gray-500">+{rule.keywords.length - 3} more</span>
                      )}
                    </div>
                  )}

                  <div className="text-xs text-gray-500">Last triggered: {formatTimeAgo(rule.lastTriggered)}</div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  )
}
