"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ExportButton } from "./export-button"
import { exportLinksToCSV, exportToCSV } from "@/lib/export-utils"
import {
  Search,
  Filter,
  Plus,
  ExternalLink,
  Copy,
  Edit,
  BarChart3,
  Eye,
  Globe,
  Smartphone,
  Monitor,
  Tablet,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Link {
  id: string
  title: string
  originalUrl: string
  shortUrl: string
  category: string
  network: string
  clicks: number
  conversions: number
  revenue: number
  conversionRate: number
  createdAt: string
  status: "active" | "paused" | "expired"
  tags: string[]
  lastClicked?: string
  topCountries: Array<{ country: string; clicks: number }>
  topDevices: Array<{ device: string; clicks: number }>
}

const mockLinks: Link[] = [
  {
    id: "1",
    title: "Apple AirPods Pro (2nd Generation) - Premium Wireless Earbuds",
    originalUrl: "https://amazon.com/apple-airpods-pro-2nd-generation",
    shortUrl: "lnkm.pro/airpods-pro-v2",
    category: "Electronics",
    network: "Amazon Associates",
    clicks: 2847,
    conversions: 89,
    revenue: 1247.83,
    conversionRate: 3.13,
    createdAt: "2024-01-15",
    status: "active",
    tags: ["tech", "audio", "premium"],
    lastClicked: "2024-01-20T14:30:00Z",
    topCountries: [
      { country: "US", clicks: 1423 },
      { country: "CA", clicks: 567 },
      { country: "UK", clicks: 445 },
    ],
    topDevices: [
      { device: "Mobile", clicks: 1708 },
      { device: "Desktop", clicks: 854 },
      { device: "Tablet", clicks: 285 },
    ],
  },
  {
    id: "2",
    title: "Fitbit Charge 5 Advanced Fitness Tracker - Health Monitoring",
    originalUrl: "https://amazon.com/fitbit-charge-5-fitness-tracker",
    shortUrl: "lnkm.pro/fitbit-charge-5",
    category: "Health & Fitness",
    network: "Amazon Associates",
    clicks: 1923,
    conversions: 67,
    revenue: 892.45,
    conversionRate: 3.48,
    createdAt: "2024-01-12",
    status: "active",
    tags: ["fitness", "health", "wearable"],
    lastClicked: "2024-01-20T16:45:00Z",
    topCountries: [
      { country: "US", clicks: 962 },
      { country: "UK", clicks: 384 },
      { country: "AU", clicks: 289 },
    ],
    topDevices: [
      { device: "Mobile", clicks: 1154 },
      { device: "Desktop", clicks: 577 },
      { device: "Tablet", clicks: 192 },
    ],
  },
  {
    id: "3",
    title: "SteelSeries Arctis 7P Wireless Gaming Headset - PS5 Compatible",
    originalUrl: "https://amazon.com/steelseries-arctis-7p-wireless-headset",
    shortUrl: "lnkm.pro/gaming-headset-pro",
    category: "Gaming",
    network: "Amazon Associates",
    clicks: 1456,
    conversions: 34,
    revenue: 567.89,
    conversionRate: 2.34,
    createdAt: "2024-01-10",
    status: "active",
    tags: ["gaming", "audio", "wireless"],
    lastClicked: "2024-01-20T12:15:00Z",
    topCountries: [
      { country: "US", clicks: 728 },
      { country: "CA", clicks: 291 },
      { country: "UK", clicks: 218 },
    ],
    topDevices: [
      { device: "Desktop", clicks: 728 },
      { device: "Mobile", clicks: 582 },
      { device: "Tablet", clicks: 146 },
    ],
  },
  {
    id: "4",
    title: "Anker PowerCore 10000 Portable Charger - Fast Charging Power Bank",
    originalUrl: "https://amazon.com/anker-powercore-10000-portable-charger",
    shortUrl: "lnkm.pro/anker-powerbank",
    category: "Electronics",
    network: "Amazon Associates",
    clicks: 3241,
    conversions: 156,
    revenue: 1834.67,
    conversionRate: 4.81,
    createdAt: "2024-01-08",
    status: "active",
    tags: ["tech", "charging", "portable"],
    lastClicked: "2024-01-20T18:22:00Z",
    topCountries: [
      { country: "US", clicks: 1620 },
      { country: "UK", clicks: 648 },
      { country: "CA", clicks: 486 },
    ],
    topDevices: [
      { device: "Mobile", clicks: 1944 },
      { device: "Desktop", clicks: 972 },
      { device: "Tablet", clicks: 325 },
    ],
  },
  {
    id: "5",
    title: "Blue Yeti USB Microphone - Professional Podcasting & Streaming",
    originalUrl: "https://amazon.com/blue-yeti-usb-microphone-professional",
    shortUrl: "lnkm.pro/blue-yeti-mic",
    category: "Audio Equipment",
    network: "Amazon Associates",
    clicks: 987,
    conversions: 23,
    revenue: 345.67,
    conversionRate: 2.33,
    createdAt: "2024-01-05",
    status: "paused",
    tags: ["audio", "streaming", "professional"],
    lastClicked: "2024-01-18T09:30:00Z",
    topCountries: [
      { country: "US", clicks: 493 },
      { country: "CA", clicks: 197 },
      { country: "UK", clicks: 148 },
    ],
    topDevices: [
      { device: "Desktop", clicks: 493 },
      { device: "Mobile", clicks: 395 },
      { device: "Tablet", clicks: 99 },
    ],
  },
]

export function EnhancedLinkManager() {
  const [links, setLinks] = useState<Link[]>(mockLinks)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedNetwork, setSelectedNetwork] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [sortBy, setSortBy] = useState("createdAt")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc")
  const { toast } = useToast()

  const categories = Array.from(new Set(links.map((link) => link.category)))
  const networks = Array.from(new Set(links.map((link) => link.network)))

  const filteredLinks = links
    .filter((link) => {
      const matchesSearch =
        link.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        link.shortUrl.toLowerCase().includes(searchTerm.toLowerCase()) ||
        link.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

      const matchesCategory = selectedCategory === "all" || link.category === selectedCategory
      const matchesNetwork = selectedNetwork === "all" || link.network === selectedNetwork
      const matchesStatus = selectedStatus === "all" || link.status === selectedStatus

      return matchesSearch && matchesCategory && matchesNetwork && matchesStatus
    })
    .sort((a, b) => {
      const aValue = a[sortBy as keyof Link]
      const bValue = b[sortBy as keyof Link]

      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortOrder === "asc" ? aValue - bValue : bValue - aValue
      }

      const aStr = String(aValue).toLowerCase()
      const bStr = String(bValue).toLowerCase()

      if (sortOrder === "asc") {
        return aStr < bStr ? -1 : aStr > bStr ? 1 : 0
      } else {
        return aStr > bStr ? -1 : aStr < bStr ? 1 : 0
      }
    })

  const handleExportCSV = () => {
    exportLinksToCSV(filteredLinks)
  }

  const handleExportFilteredCSV = () => {
    const headers = [
      "Title",
      "Short URL",
      "Category",
      "Network",
      "Clicks",
      "Conversions",
      "Revenue",
      "Conversion Rate",
      "Status",
    ]

    const rows = filteredLinks.map((link) => [
      link.title,
      link.shortUrl,
      link.category,
      link.network,
      link.clicks.toString(),
      link.conversions.toString(),
      `$${link.revenue.toFixed(2)}`,
      `${link.conversionRate.toFixed(2)}%`,
      link.status,
    ])

    exportToCSV({
      headers,
      rows,
      filename: "filtered_links",
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Link has been copied to your clipboard.",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "paused":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "expired":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getDeviceIcon = (device: string) => {
    switch (device.toLowerCase()) {
      case "mobile":
        return <Smartphone className="h-3 w-3" />
      case "desktop":
        return <Monitor className="h-3 w-3" />
      case "tablet":
        return <Tablet className="h-3 w-3" />
      default:
        return <Globe className="h-3 w-3" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Header with Export */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Link Manager</h2>
          <p className="text-muted-foreground">Manage and analyze your affiliate links performance</p>
        </div>
        <div className="flex space-x-2">
          <ExportButton onExportCSV={handleExportFilteredCSV} onExportPDF={handleExportCSV} size="sm" />
          <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            <Plus className="mr-2 h-4 w-4" />
            Add Link
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filters & Search</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search links, URLs, or tags..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
              <SelectTrigger>
                <SelectValue placeholder="Network" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Networks</SelectItem>
                {networks.map((network) => (
                  <SelectItem key={network} value={network}>
                    {network}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={`${sortBy}-${sortOrder}`}
              onValueChange={(value) => {
                const [field, order] = value.split("-")
                setSortBy(field)
                setSortOrder(order as "asc" | "desc")
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="createdAt-desc">Newest First</SelectItem>
                <SelectItem value="createdAt-asc">Oldest First</SelectItem>
                <SelectItem value="clicks-desc">Most Clicks</SelectItem>
                <SelectItem value="clicks-asc">Least Clicks</SelectItem>
                <SelectItem value="revenue-desc">Highest Revenue</SelectItem>
                <SelectItem value="revenue-asc">Lowest Revenue</SelectItem>
                <SelectItem value="conversionRate-desc">Best CVR</SelectItem>
                <SelectItem value="conversionRate-asc">Worst CVR</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>
          Showing {filteredLinks.length} of {links.length} links
        </span>
        <div className="flex items-center space-x-4">
          <span>Total Clicks: {filteredLinks.reduce((sum, link) => sum + link.clicks, 0).toLocaleString()}</span>
          <span>Total Revenue: ${filteredLinks.reduce((sum, link) => sum + link.revenue, 0).toFixed(2)}</span>
        </div>
      </div>

      {/* Links Grid */}
      <div className="grid gap-6">
        {filteredLinks.map((link) => (
          <Card key={link.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center space-x-2">
                    <CardTitle className="text-lg line-clamp-1">{link.title}</CardTitle>
                    <Badge variant="outline" className={getStatusColor(link.status)}>
                      {link.status}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span className="flex items-center space-x-1">
                      <ExternalLink className="h-3 w-3" />
                      <span>{link.shortUrl}</span>
                    </span>
                    <span>•</span>
                    <span>{link.category}</span>
                    <span>•</span>
                    <span>{link.network}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {link.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => copyToClipboard(link.shortUrl)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <BarChart3 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Performance Metrics */}
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{link.clicks.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">Clicks</div>
                </div>
                <div className="text-center p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{link.conversions}</div>
                  <div className="text-xs text-muted-foreground">Conversions</div>
                </div>
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{link.conversionRate.toFixed(2)}%</div>
                  <div className="text-xs text-muted-foreground">CVR</div>
                </div>
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">${link.revenue.toFixed(0)}</div>
                  <div className="text-xs text-muted-foreground">Revenue</div>
                </div>
              </div>

              {/* Geographic & Device Breakdown */}
              <Tabs defaultValue="countries" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="countries">Top Countries</TabsTrigger>
                  <TabsTrigger value="devices">Top Devices</TabsTrigger>
                </TabsList>

                <TabsContent value="countries" className="space-y-2">
                  {link.topCountries.slice(0, 3).map((country, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-4 bg-gray-200 rounded flex items-center justify-center text-xs font-semibold">
                          {country.country}
                        </div>
                        <span>
                          {country.country === "US"
                            ? "United States"
                            : country.country === "UK"
                              ? "United Kingdom"
                              : country.country === "CA"
                                ? "Canada"
                                : country.country}
                        </span>
                      </div>
                      <span className="font-medium">{country.clicks.toLocaleString()}</span>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="devices" className="space-y-2">
                  {link.topDevices.map((device, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-2">
                        {getDeviceIcon(device.device)}
                        <span>{device.device}</span>
                      </div>
                      <span className="font-medium">{device.clicks.toLocaleString()}</span>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>

              {/* Actions */}
              <div className="flex items-center justify-between pt-3 border-t">
                <div className="text-xs text-muted-foreground">
                  Created {new Date(link.createdAt).toLocaleDateString()}
                  {link.lastClicked && <span> • Last clicked {new Date(link.lastClicked).toLocaleDateString()}</span>}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Eye className="mr-2 h-4 w-4" />
                    View Details
                  </Button>
                  <Button variant="outline" size="sm">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Visit Link
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredLinks.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No links found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search criteria or filters</p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setSelectedCategory("all")
                setSelectedNetwork("all")
                setSelectedStatus("all")
              }}
            >
              Clear Filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
