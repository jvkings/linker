"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  Zap,
  TrendingUp,
  Target,
  Lightbulb,
  Settings,
  Play,
  Pause,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react"

export function AIOptimizationDashboard() {
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [optimizationProgress, setOptimizationProgress] = useState(0)

  const optimizationSuggestions = [
    {
      id: "1",
      type: "keyword",
      title: "Keyword Optimization",
      description: "Add 'wireless earbuds' keyword to Apple AirPods link",
      impact: "High",
      estimatedIncrease: "+23%",
      confidence: 92,
      status: "pending",
      linkTitle: "Apple AirPods Pro",
    },
    {
      id: "2",
      type: "timing",
      title: "Optimal Posting Time",
      description: "Post fitness tracker links between 6-8 AM for better CTR",
      impact: "Medium",
      estimatedIncrease: "+15%",
      confidence: 87,
      status: "pending",
      linkTitle: "Fitbit Charge 5",
    },
    {
      id: "3",
      type: "placement",
      title: "Link Placement",
      description: "Move gaming headset link higher in content for better visibility",
      impact: "Medium",
      estimatedIncrease: "+12%",
      confidence: 78,
      status: "applied",
      linkTitle: "Gaming Headset Pro",
    },
    {
      id: "4",
      type: "audience",
      title: "Audience Targeting",
      description: "Target mobile users for wireless charger links",
      impact: "High",
      estimatedIncrease: "+28%",
      confidence: 94,
      status: "pending",
      linkTitle: "Wireless Charger",
    },
  ]

  const aiMetrics = [
    {
      title: "AI Optimization Score",
      value: "87%",
      change: "+12%",
      icon: Brain,
      color: "purple",
    },
    {
      title: "Predicted Revenue Increase",
      value: "+$2,341",
      change: "+18%",
      icon: TrendingUp,
      color: "green",
    },
    {
      title: "Optimized Links",
      value: "156",
      change: "+23",
      icon: Zap,
      color: "blue",
    },
    {
      title: "Success Rate",
      value: "94.2%",
      change: "+2.1%",
      icon: Target,
      color: "orange",
    },
  ]

  const handleStartOptimization = () => {
    setIsOptimizing(true)
    setOptimizationProgress(0)

    const interval = setInterval(() => {
      setOptimizationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsOptimizing(false)
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "High":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "Low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "applied":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      default:
        return <AlertTriangle className="h-4 w-4 text-red-600" />
    }
  }

  return (
    <div className="space-y-6">
      {/* AI Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {aiMetrics.map((metric) => (
          <Card
            key={metric.title}
            className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg"
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div
                  className={`p-2 rounded-lg ${
                    metric.color === "purple"
                      ? "bg-purple-100 text-purple-600 dark:bg-purple-900"
                      : metric.color === "green"
                        ? "bg-green-100 text-green-600 dark:bg-green-900"
                        : metric.color === "blue"
                          ? "bg-blue-100 text-blue-600 dark:bg-blue-900"
                          : "bg-orange-100 text-orange-600 dark:bg-orange-900"
                  }`}
                >
                  <metric.icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <Badge
                      variant="outline"
                      className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    >
                      {metric.change}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="suggestions" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="suggestions">AI Suggestions</TabsTrigger>
          <TabsTrigger value="automation">Automation Rules</TabsTrigger>
          <TabsTrigger value="analytics">AI Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="suggestions" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5 text-purple-600" />
                    <span>AI Optimization Suggestions</span>
                  </CardTitle>
                  <CardDescription>
                    Machine learning-powered recommendations to improve your link performance
                  </CardDescription>
                </div>
                <Button
                  onClick={handleStartOptimization}
                  disabled={isOptimizing}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {isOptimizing ? (
                    <>
                      <Pause className="mr-2 h-4 w-4" />
                      Optimizing...
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 h-4 w-4" />
                      Start AI Optimization
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isOptimizing && (
                <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                      AI Optimization in Progress
                    </span>
                    <span className="text-sm text-blue-600 dark:text-blue-400">{optimizationProgress}%</span>
                  </div>
                  <Progress value={optimizationProgress} className="h-2" />
                </div>
              )}

              <div className="space-y-4">
                {optimizationSuggestions.map((suggestion) => (
                  <div
                    key={suggestion.id}
                    className="border rounded-lg p-4 bg-white dark:bg-slate-800 hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                          <Lightbulb className="h-4 w-4 text-purple-600" />
                        </div>
                        <div>
                          <h4 className="font-semibold">{suggestion.title}</h4>
                          <p className="text-sm text-muted-foreground">{suggestion.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(suggestion.status)}
                        <Badge variant="outline" className={getImpactColor(suggestion.impact)}>
                          {suggestion.impact} Impact
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="text-center p-2 bg-green-50 dark:bg-green-950 rounded">
                        <div className="text-lg font-bold text-green-600">{suggestion.estimatedIncrease}</div>
                        <div className="text-xs text-muted-foreground">Est. Increase</div>
                      </div>
                      <div className="text-center p-2 bg-blue-50 dark:bg-blue-950 rounded">
                        <div className="text-lg font-bold text-blue-600">{suggestion.confidence}%</div>
                        <div className="text-xs text-muted-foreground">Confidence</div>
                      </div>
                      <div className="text-center p-2 bg-purple-50 dark:bg-purple-950 rounded">
                        <div className="text-sm font-medium text-purple-600">{suggestion.linkTitle}</div>
                        <div className="text-xs text-muted-foreground">Target Link</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">Based on analysis of 10,000+ similar links</div>
                      <div className="flex space-x-2">
                        {suggestion.status === "pending" && (
                          <>
                            <Button variant="outline" size="sm">
                              Dismiss
                            </Button>
                            <Button size="sm" className="bg-gradient-to-r from-green-600 to-emerald-600">
                              Apply Suggestion
                            </Button>
                          </>
                        )}
                        {suggestion.status === "applied" && (
                          <Button variant="outline" size="sm">
                            <BarChart3 className="mr-2 h-4 w-4" />
                            View Results
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Automation Rules</CardTitle>
              <CardDescription>Configure automatic optimizations based on AI recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Auto-apply High Confidence Suggestions</h4>
                    <p className="text-sm text-muted-foreground">
                      Automatically apply suggestions with 90%+ confidence
                    </p>
                  </div>
                  <Button variant="outline">
                    <Settings className="mr-2 h-4 w-4" />
                    Configure
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Smart Keyword Optimization</h4>
                    <p className="text-sm text-muted-foreground">
                      Automatically optimize keywords based on performance data
                    </p>
                  </div>
                  <Button variant="outline">
                    <Settings className="mr-2 h-4 w-4" />
                    Configure
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Performance-based Link Rotation</h4>
                    <p className="text-sm text-muted-foreground">
                      Rotate underperforming links with better alternatives
                    </p>
                  </div>
                  <Button variant="outline">
                    <Settings className="mr-2 h-4 w-4" />
                    Configure
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Performance Analytics</CardTitle>
              <CardDescription>Track the impact of AI optimizations on your affiliate performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Brain className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Advanced AI Analytics</h3>
                <p className="text-muted-foreground mb-4">
                  Detailed performance tracking and predictive analytics coming soon
                </p>
                <Button variant="outline">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  View Basic Analytics
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
