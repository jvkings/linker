"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MousePointer, DollarSign, Target, Globe, Clock } from "lucide-react"

interface Activity {
  id: string
  type: "click" | "conversion" | "signup" | "revenue"
  description: string
  location: string
  amount?: number
  timestamp: Date
  linkTitle: string
  source: string
}

export function RealtimeActivity() {
  const [activities, setActivities] = useState<Activity[]>([
    {
      id: "1",
      type: "conversion",
      description: "New conversion from Apple AirPods Pro link",
      location: "United States",
      amount: 23.45,
      timestamp: new Date(Date.now() - 30000),
      linkTitle: "Apple AirPods Pro",
      source: "Google",
    },
    {
      id: "2",
      type: "click",
      description: "Click on Fitness Tracker link",
      location: "Canada",
      timestamp: new Date(Date.now() - 45000),
      linkTitle: "Fitness Tracker Pro",
      source: "Facebook",
    },
    {
      id: "3",
      type: "revenue",
      description: "Commission earned from Amazon",
      location: "United Kingdom",
      amount: 156.78,
      timestamp: new Date(Date.now() - 120000),
      linkTitle: "Gaming Headset",
      source: "Direct",
    },
    {
      id: "4",
      type: "click",
      description: "Click on Designer Watch link",
      location: "Australia",
      timestamp: new Date(Date.now() - 180000),
      linkTitle: "Luxury Watch Collection",
      source: "Instagram",
    },
  ])

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newActivity: Activity = {
        id: Date.now().toString(),
        type: Math.random() > 0.7 ? "conversion" : "click",
        description: Math.random() > 0.7 ? "New conversion from trending link" : "New click detected",
        location: ["United States", "Canada", "United Kingdom", "Australia", "Germany"][Math.floor(Math.random() * 5)],
        amount: Math.random() > 0.7 ? Math.random() * 100 + 10 : undefined,
        timestamp: new Date(),
        linkTitle: ["Apple AirPods Pro", "Fitness Tracker", "Gaming Headset", "Designer Watch"][
          Math.floor(Math.random() * 4)
        ],
        source: ["Google", "Facebook", "Instagram", "Direct", "Twitter"][Math.floor(Math.random() * 5)],
      }

      setActivities((prev) => [newActivity, ...prev.slice(0, 9)])
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "click":
        return MousePointer
      case "conversion":
        return Target
      case "revenue":
        return DollarSign
      default:
        return Globe
    }
  }

  const getActivityColor = (type: string) => {
    switch (type) {
      case "click":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900"
      case "conversion":
        return "text-green-600 bg-green-100 dark:bg-green-900"
      case "revenue":
        return "text-purple-600 bg-purple-100 dark:bg-purple-900"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900"
    }
  }

  const getActivityBadge = (type: string) => {
    switch (type) {
      case "click":
        return { text: "Click", color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" }
      case "conversion":
        return { text: "Conversion", color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" }
      case "revenue":
        return { text: "Revenue", color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" }
      default:
        return { text: "Activity", color: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200" }
    }
  }

  const formatTimeAgo = (timestamp: Date) => {
    const seconds = Math.floor((Date.now() - timestamp.getTime()) / 1000)
    if (seconds < 60) return `${seconds}s ago`
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    return `${hours}h ago`
  }

  return (
    <Card className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Real-time Activity</span>
          </div>
        </CardTitle>
        <CardDescription>Live feed of clicks, conversions, and revenue</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {activities.map((activity) => {
            const Icon = getActivityIcon(activity.type)
            const badge = getActivityBadge(activity.type)

            return (
              <div
                key={activity.id}
                className="flex items-start space-x-3 p-3 rounded-lg border bg-white dark:bg-slate-800 hover:shadow-sm transition-all duration-200"
              >
                <div className={`p-2 rounded-lg ${getActivityColor(activity.type)}`}>
                  <Icon className="h-4 w-4" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className={`text-xs ${badge.color}`}>
                        {badge.text}
                      </Badge>
                      {activity.amount && (
                        <span className="text-sm font-semibold text-green-600">+${activity.amount.toFixed(2)}</span>
                      )}
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{formatTimeAgo(activity.timestamp)}</span>
                    </div>
                  </div>

                  <p className="text-sm font-medium mb-1">{activity.description}</p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center space-x-1">
                        <Globe className="h-3 w-3" />
                        <span>{activity.location}</span>
                      </span>
                      <span>via {activity.source}</span>
                    </div>
                    <span className="font-medium">{activity.linkTitle}</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
