"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, Wand2, Scan, Users, Settings } from "lucide-react"
import NextLink from "next/link"

export function QuickActions() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
          <Plus className="mr-2 h-4 w-4" />
          Quick Actions
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Create & Manage</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <NextLink href="/bulk-shortener" className="flex items-center">
            <span className="mr-2 h-4 w-4" />
            Bulk Shorten Links
          </NextLink>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <NextLink href="/bulk-prettifier" className="flex items-center">
            <Wand2 className="mr-2 h-4 w-4" />
            Bulk Prettify Links
          </NextLink>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <NextLink href="/website-scanner" className="flex items-center">
            <Scan className="mr-2 h-4 w-4" />
            Scan Website Links
          </NextLink>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <NextLink href="/link-in-bio" className="flex items-center">
            <Users className="mr-2 h-4 w-4" />
            Create Link in Bio
          </NextLink>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <NextLink href="/integrations" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            Manage Integrations
          </NextLink>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
