"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from "recharts"

const clicksData = [
  { date: "Jan 1", clicks: 1240, conversions: 34, revenue: 456.78, ctr: 2.74 },
  { date: "Jan 2", clicks: 1456, conversions: 42, revenue: 578.9, ctr: 2.88 },
  { date: "Jan 3", clicks: 1678, conversions: 38, revenue: 467.34, ctr: 2.26 },
  { date: "Jan 4", clicks: 1890, conversions: 56, revenue: 723.45, ctr: 2.96 },
  { date: "Jan 5", clicks: 2034, conversions: 61, revenue: 898.76, ctr: 3.0 },
  { date: "Jan 6", clicks: 1789, conversions: 48, revenue: 656.78, ctr: 2.68 },
  { date: "Jan 7", clicks: 2341, conversions: 73, revenue: 1089.23, ctr: 3.12 },
]

const revenueData = [
  { date: "Jan 1", revenue: 456.78, profit: 365.42 },
  { date: "Jan 2", revenue: 578.9, profit: 463.12 },
  { date: "Jan 3", revenue: 467.34, profit: 373.87 },
  { date: "Jan 4", revenue: 723.45, profit: 578.76 },
  { date: "Jan 5", revenue: 898.76, profit: 719.01 },
  { date: "Jan 6", revenue: 656.78, profit: 525.42 },
  { date: "Jan 7", revenue: 1089.23, profit: 871.38 },
]

const conversionData = [
  { date: "Jan 1", rate: 2.74, target: 3.0 },
  { date: "Jan 2", rate: 2.88, target: 3.0 },
  { date: "Jan 3", rate: 2.26, target: 3.0 },
  { date: "Jan 4", rate: 2.96, target: 3.0 },
  { date: "Jan 5", rate: 3.0, target: 3.0 },
  { date: "Jan 6", rate: 2.68, target: 3.0 },
  { date: "Jan 7", rate: 3.12, target: 3.0 },
]

export function AnalyticsChart() {
  return (
    <Card className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <span>Performance Analytics</span>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-muted-foreground">Live</span>
          </div>
        </CardTitle>
        <CardDescription>Real-time performance metrics and trends</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="clicks" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="clicks">Clicks & Traffic</TabsTrigger>
            <TabsTrigger value="revenue">Revenue & Profit</TabsTrigger>
            <TabsTrigger value="conversion">Conversion Rate</TabsTrigger>
          </TabsList>

          <TabsContent value="clicks" className="space-y-4">
            <ResponsiveContainer width="100%" height={350}>
              <AreaChart data={clicksData}>
                <defs>
                  <linearGradient id="clicksGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="conversionsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="clicks"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  fill="url(#clicksGradient)"
                  name="Clicks"
                />
                <Area
                  type="monotone"
                  dataKey="conversions"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#conversionsGradient)"
                  name="Conversions"
                />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-4">
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                  }}
                />
                <Bar dataKey="revenue" fill="#8b5cf6" name="Revenue ($)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="profit" fill="#06b6d4" name="Profit ($)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="conversion" className="space-y-4">
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={conversionData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 4]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="rate"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  name="Conversion Rate (%)"
                  dot={{ fill: "#f59e0b", strokeWidth: 2, r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke="#ef4444"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Target (%)"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
