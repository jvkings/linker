"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Activity, Plus, AlertCircle, CheckCircle, Clock } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Integration {
  id: number
  name: string
  type: string
  status: "connected" | "pending" | "error"
  url: string
  linksManaged: number
  lastSync: string | null
  features: string[]
  error?: string
}

interface IntegrationData {
  summary: {
    totalIntegrations: number
    activeIntegrations: number
    pendingIntegrations: number
    failedIntegrations: number
  }
  integrations: Integration[]
}

export function IntegrationOverview() {
  const [integrationData, setIntegrationData] = useState<IntegrationData | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const fetchIntegrationData = async () => {
    try {
      const response = await fetch("/api/integrations")
      if (!response.ok) throw new Error("Failed to fetch integration data")

      const data: IntegrationData = await response.json()
      setIntegrationData(data)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load integration data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchIntegrationData()
  }, [])

  const formatTimeAgo = (timestamp: string | null) => {
    if (!timestamp) return "Never"

    const now = new Date()
    const time = new Date(timestamp)
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "wordpress":
        return "📝"
      case "shopify":
        return "🛍️"
      case "instagram":
        return "📷"
      case "youtube":
        return "📺"
      case "custom":
        return "🔧"
      default:
        return "🌐"
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="mr-2 h-5 w-5" />
            Integrations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="grid grid-cols-2 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!integrationData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="mr-2 h-5 w-5" />
            Integrations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Failed to load integration data</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Integrations
            </CardTitle>
            <CardDescription>
              {integrationData.summary.activeIntegrations} active • {integrationData.summary.totalIntegrations} total
            </CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{integrationData.summary.activeIntegrations}</div>
            <div className="text-xs text-green-600">Active</div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {integrationData.integrations.reduce((sum, int) => sum + int.linksManaged, 0).toLocaleString()}
            </div>
            <div className="text-xs text-blue-600">Links Managed</div>
          </div>
        </div>

        {/* Integrations List */}
        <div>
          <h4 className="text-sm font-medium mb-3">Connected Services</h4>
          <ScrollArea className="h-[250px]">
            <div className="space-y-3">
              {integrationData.integrations.map((integration) => (
                <div key={integration.id} className="p-3 border rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{getTypeIcon(integration.type)}</span>
                      <div>
                        <div className="font-medium text-sm">{integration.name}</div>
                        <div className="text-xs text-gray-500">{integration.url}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(integration.status)}
                      <Badge className={getStatusColor(integration.status)}>{integration.status}</Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{integration.linksManaged.toLocaleString()} links</span>
                    <span>Last sync: {formatTimeAgo(integration.lastSync)}</span>
                  </div>

                  {integration.error && (
                    <div className="text-xs text-red-600 bg-red-50 p-2 rounded">Error: {integration.error}</div>
                  )}

                  <div className="flex flex-wrap gap-1">
                    {integration.features.slice(0, 2).map((feature, index) => (
                      <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                        {feature}
                      </span>
                    ))}
                    {integration.features.length > 2 && (
                      <span className="text-xs text-gray-500">+{integration.features.length - 2} more</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  )
}
