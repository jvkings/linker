"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Brain,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  Target,
  Zap,
  BarChart3,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Eye,
  RefreshCw,
  Download,
  Share,
  Calendar,
  Users,
  DollarSign,
  MousePointer,
  Activity,
  Award,
  Rocket,
  Shield,
  AlertCircle,
} from "lucide-react"

interface TestInsight {
  id: string
  testId: string
  testName: string
  type: "performance" | "statistical" | "behavioral" | "predictive" | "recommendation"
  priority: "high" | "medium" | "low"
  category: "optimization" | "warning" | "opportunity" | "success" | "trend"
  title: string
  description: string
  impact: string
  confidence: number
  actionable: boolean
  recommendations: string[]
  metrics: {
    current: number
    predicted: number
    improvement: number
    significance: number
  }
  timestamp: string
  status: "new" | "reviewed" | "implemented" | "dismissed"
}

interface TestPattern {
  id: string
  pattern: string
  frequency: number
  impact: string
  examples: string[]
  recommendation: string
}

export function AIInsightsDashboard() {
  const [activeTab, setActiveTab] = useState("insights")
  const [selectedTimeframe, setSelectedTimeframe] = useState("30d")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [isGenerating, setIsGenerating] = useState(false)

  const insights: TestInsight[] = [
    {
      id: "insight_001",
      testId: "test_001",
      testName: "Apple AirPods Pro - Title Optimization",
      type: "performance",
      priority: "high",
      category: "success",
      title: "Emoji Strategy Drives 26% Conversion Lift",
      description:
        "The addition of emojis and urgency language in variant A has resulted in a statistically significant 26.4% improvement in conversion rates with 87% confidence.",
      impact: "High - Potential $2,847 monthly revenue increase",
      confidence: 87,
      actionable: true,
      recommendations: [
        "Apply emoji strategy to similar tech product links",
        "Test urgency language on other high-traffic affiliate links",
        "Create emoji library for consistent brand application",
        "A/B test different emoji combinations for optimization",
      ],
      metrics: {
        current: 2.73,
        predicted: 3.45,
        improvement: 26.4,
        significance: 87,
      },
      timestamp: "2024-01-15T10:30:00Z",
      status: "new",
    },
    {
      id: "insight_002",
      testId: "test_002",
      testName: "Fitness Tracker - Landing Page Test",
      type: "behavioral",
      priority: "high",
      category: "opportunity",
      title: "Review-Style Content Increases Trust Signals",
      description:
        "Users spend 34% more time on review-style landing pages, indicating higher engagement and trust. This correlates with the 78% improvement in conversion rates.",
      impact: "High - Review format shows consistent performance across categories",
      confidence: 95,
      actionable: true,
      recommendations: [
        "Implement review-style format for health & fitness category",
        "Create review templates for different product types",
        "Test user-generated content integration",
        "Develop trust signal optimization strategy",
      ],
      metrics: {
        current: 1.68,
        predicted: 3.0,
        improvement: 78.6,
        significance: 95,
      },
      timestamp: "2024-01-14T15:45:00Z",
      status: "reviewed",
    },
    {
      id: "insight_003",
      testId: "test_001",
      testName: "Apple AirPods Pro - Title Optimization",
      type: "statistical",
      priority: "medium",
      category: "warning",
      title: "Sample Size Approaching Minimum Threshold",
      description:
        "While current results show promise, the test is approaching the minimum sample size for reliable statistical inference. Consider extending test duration.",
      impact: "Medium - Risk of false positive results",
      confidence: 72,
      actionable: true,
      recommendations: [
        "Extend test duration by 7 days to reach 95% confidence",
        "Increase traffic allocation to accelerate data collection",
        "Monitor daily for significance threshold achievement",
        "Prepare winner declaration criteria in advance",
      ],
      metrics: {
        current: 87,
        predicted: 95,
        improvement: 9.2,
        significance: 87,
      },
      timestamp: "2024-01-15T08:15:00Z",
      status: "new",
    },
    {
      id: "insight_004",
      testId: "cross_analysis",
      testName: "Cross-Test Pattern Analysis",
      type: "predictive",
      priority: "high",
      category: "trend",
      title: "Emotional Triggers Show 23% Higher Performance",
      description:
        "Analysis across 12 tests reveals that links incorporating emotional triggers (urgency, scarcity, social proof) consistently outperform neutral language by an average of 23%.",
      impact: "High - Pattern applicable to 67% of current link portfolio",
      confidence: 91,
      actionable: true,
      recommendations: [
        "Audit existing links for emotional trigger opportunities",
        "Create emotional trigger testing framework",
        "Develop category-specific trigger strategies",
        "Implement automated emotional trigger suggestions",
      ],
      metrics: {
        current: 2.1,
        predicted: 2.58,
        improvement: 23.0,
        significance: 91,
      },
      timestamp: "2024-01-13T12:00:00Z",
      status: "implemented",
    },
    {
      id: "insight_005",
      testId: "seasonal_analysis",
      testName: "Seasonal Performance Analysis",
      type: "behavioral",
      priority: "medium",
      category: "opportunity",
      title: "Holiday Season Shows 45% CTR Increase for Gift-Focused Copy",
      description:
        "Links with gift-oriented language during Q4 show significantly higher performance. Current non-seasonal copy is missing conversion opportunities.",
      impact: "Medium - Seasonal optimization potential",
      confidence: 88,
      actionable: true,
      recommendations: [
        "Implement seasonal copy variations",
        "Create holiday-specific link versions",
        "Schedule automatic seasonal optimizations",
        "Test gift-focused language year-round for evergreen products",
      ],
      metrics: {
        current: 3.2,
        predicted: 4.64,
        improvement: 45.0,
        significance: 88,
      },
      timestamp: "2024-01-12T16:20:00Z",
      status: "new",
    },
    {
      id: "insight_006",
      testId: "mobile_analysis",
      testName: "Mobile vs Desktop Performance",
      type: "behavioral",
      priority: "high",
      category: "warning",
      title: "Mobile Conversion Rates 31% Lower Than Desktop",
      description:
        "Significant performance gap detected between mobile and desktop users. Mobile-specific optimizations needed to capture lost revenue.",
      impact: "High - 58% of traffic is mobile with suboptimal performance",
      confidence: 94,
      actionable: true,
      recommendations: [
        "Create mobile-optimized link variations",
        "Test shorter, more concise titles for mobile",
        "Implement mobile-specific landing page experiences",
        "Analyze mobile user behavior patterns for insights",
      ],
      metrics: {
        current: 1.89,
        predicted: 2.74,
        improvement: 45.0,
        significance: 94,
      },
      timestamp: "2024-01-11T09:30:00Z",
      status: "reviewed",
    },
  ]

  const patterns: TestPattern[] = [
    {
      id: "pattern_001",
      pattern: "Emoji + Urgency Language",
      frequency: 8,
      impact: "+26% average conversion lift",
      examples: ["🎧 Limited Time 50% OFF", "⚡ Flash Sale - Today Only", "🔥 Hot Deal Alert"],
      recommendation: "Apply to tech and consumer electronics categories",
    },
    {
      id: "pattern_002",
      pattern: "Review-Style Titles",
      frequency: 6,
      impact: "+34% engagement increase",
      examples: ["Is Product X Worth It? (Review)", "Product Y Review - Pros & Cons", "Honest Review: Product Z"],
      recommendation: "Implement for health, fitness, and lifestyle products",
    },
    {
      id: "pattern_003",
      pattern: "Price Transparency",
      frequency: 4,
      impact: "+18% qualified traffic",
      examples: ["Product Name - $99.99", "Best Price: $149 (Save 30%)", "Compare Prices: Starting at $79"],
      recommendation: "Test across all price-sensitive categories",
    },
    {
      id: "pattern_004",
      pattern: "Social Proof Integration",
      frequency: 5,
      impact: "+22% trust signals",
      examples: ["#1 Rated Product", "10,000+ Happy Customers", "Editor's Choice Award"],
      recommendation: "Leverage for products with strong review scores",
    },
  ]

  const aiMetrics = [
    {
      title: "Insights Generated",
      value: "47",
      change: "+12",
      icon: Brain,
      color: "purple",
    },
    {
      title: "Avg. Confidence",
      value: "89%",
      change: "+3%",
      icon: Target,
      color: "blue",
    },
    {
      title: "Implemented Recommendations",
      value: "23",
      change: "+8",
      icon: CheckCircle,
      color: "green",
    },
    {
      title: "Revenue Impact",
      value: "$12,847",
      change: "+34%",
      icon: DollarSign,
      color: "orange",
    },
  ]

  const getInsightIcon = (type: string, category: string) => {
    if (category === "success") return CheckCircle
    if (category === "warning") return AlertTriangle
    if (category === "opportunity") return Lightbulb
    if (category === "trend") return TrendingUp

    switch (type) {
      case "performance":
        return BarChart3
      case "statistical":
        return Target
      case "behavioral":
        return Users
      case "predictive":
        return Brain
      case "recommendation":
        return Rocket
      default:
        return Lightbulb
    }
  }

  const getInsightColor = (category: string, priority: string) => {
    if (category === "success") return "text-green-600 bg-green-100 dark:bg-green-900"
    if (category === "warning") return "text-orange-600 bg-orange-100 dark:bg-orange-900"
    if (category === "opportunity") return "text-blue-600 bg-blue-100 dark:bg-blue-900"
    if (category === "trend") return "text-purple-600 bg-purple-100 dark:bg-purple-900"

    if (priority === "high") return "text-red-600 bg-red-100 dark:bg-red-900"
    if (priority === "medium") return "text-yellow-600 bg-yellow-100 dark:bg-yellow-900"
    return "text-gray-600 bg-gray-100 dark:bg-gray-900"
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "reviewed":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "implemented":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "dismissed":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const filteredInsights = insights.filter((insight) => {
    if (selectedCategory === "all") return true
    return insight.category === selectedCategory
  })

  const handleGenerateInsights = async () => {
    setIsGenerating(true)
    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsGenerating(false)
  }

  return (
    <div className="space-y-6">
      {/* AI Metrics Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {aiMetrics.map((metric) => (
          <Card
            key={metric.title}
            className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 border-0 shadow-lg"
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div
                  className={`p-2 rounded-lg ${
                    metric.color === "purple"
                      ? "bg-purple-100 text-purple-600 dark:bg-purple-900"
                      : metric.color === "blue"
                        ? "bg-blue-100 text-blue-600 dark:bg-blue-900"
                        : metric.color === "green"
                          ? "bg-green-100 text-green-600 dark:bg-green-900"
                          : "bg-orange-100 text-orange-600 dark:bg-orange-900"
                  }`}
                >
                  <metric.icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <Badge
                      variant="outline"
                      className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                    >
                      {metric.change}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex items-center justify-between">
          <TabsList className="grid w-full max-w-lg grid-cols-4">
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
            <TabsTrigger value="patterns">Patterns</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="recommendations">Actions</TabsTrigger>
          </TabsList>

          <div className="flex items-center space-x-2">
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="opportunity">Opportunity</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="trend">Trend</SelectItem>
              </SelectContent>
            </Select>

            <Button
              onClick={handleGenerateInsights}
              disabled={isGenerating}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate Insights
                </>
              )}
            </Button>
          </div>
        </div>

        <TabsContent value="insights" className="space-y-4">
          <div className="space-y-4">
            {filteredInsights.map((insight) => {
              const IconComponent = getInsightIcon(insight.type, insight.category)

              return (
                <Card key={insight.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${getInsightColor(insight.category, insight.priority)}`}>
                          <IconComponent className="h-4 w-4" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <CardTitle className="text-lg">{insight.title}</CardTitle>
                            <Badge variant="outline" className={getPriorityColor(insight.priority)}>
                              {insight.priority} priority
                            </Badge>
                          </div>
                          <CardDescription className="text-sm text-muted-foreground">
                            {insight.testName}
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className={getStatusColor(insight.status)}>
                          {insight.status}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {insight.confidence}% confidence
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{insight.description}</p>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-4 gap-4 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-blue-600">{insight.metrics.current.toFixed(2)}%</div>
                        <div className="text-xs text-muted-foreground">Current</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-green-600">
                          {insight.metrics.predicted.toFixed(2)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Predicted</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-purple-600">
                          +{insight.metrics.improvement.toFixed(1)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Improvement</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-orange-600">{insight.metrics.significance}%</div>
                        <div className="text-xs text-muted-foreground">Significance</div>
                      </div>
                    </div>

                    {/* Impact Assessment */}
                    <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                      <div className="flex items-start space-x-2">
                        <Target className="h-4 w-4 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-700 dark:text-blue-300">Impact Assessment</h4>
                          <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">{insight.impact}</p>
                        </div>
                      </div>
                    </div>

                    {/* AI Recommendations */}
                    {insight.actionable && (
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium flex items-center">
                          <Lightbulb className="h-4 w-4 mr-2 text-yellow-600" />
                          AI Recommendations
                        </h4>
                        <div className="space-y-2">
                          {insight.recommendations.map((rec, index) => (
                            <div key={index} className="flex items-start space-x-2 text-sm">
                              <ArrowRight className="h-3 w-3 text-muted-foreground mt-1 flex-shrink-0" />
                              <span className="text-muted-foreground">{rec}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="text-xs text-muted-foreground">
                        Generated {new Date(insight.timestamp).toLocaleDateString()}
                      </div>
                      <div className="flex space-x-2">
                        {insight.status === "new" && (
                          <>
                            <Button variant="outline" size="sm">
                              <Eye className="mr-2 h-4 w-4" />
                              Mark Reviewed
                            </Button>
                            <Button size="sm" className="bg-gradient-to-r from-green-600 to-emerald-600">
                              <Zap className="mr-2 h-4 w-4" />
                              Implement
                            </Button>
                          </>
                        )}
                        {insight.status === "reviewed" && (
                          <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                            <Rocket className="mr-2 h-4 w-4" />
                            Apply Recommendations
                          </Button>
                        )}
                        {insight.status === "implemented" && (
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Implemented
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Winning Patterns Analysis</CardTitle>
              <CardDescription>AI-identified patterns that consistently drive performance improvements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {patterns.map((pattern) => (
                  <div key={pattern.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">{pattern.pattern}</h3>
                        <p className="text-sm text-muted-foreground">
                          Found in {pattern.frequency} tests • {pattern.impact}
                        </p>
                      </div>
                      <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white">
                        <Award className="h-3 w-3 mr-1" />
                        Proven Pattern
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Examples:</h4>
                        <div className="flex flex-wrap gap-2">
                          {pattern.examples.map((example, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {example}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                        <div className="flex items-start space-x-2">
                          <Lightbulb className="h-4 w-4 text-blue-600 mt-0.5" />
                          <div>
                            <h4 className="text-sm font-medium text-blue-700 dark:text-blue-300">AI Recommendation</h4>
                            <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">{pattern.recommendation}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="text-xs text-muted-foreground">
                        Pattern confidence: {85 + pattern.frequency * 2}%
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="mr-2 h-4 w-4" />
                          View Tests
                        </Button>
                        <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                          <Zap className="mr-2 h-4 w-4" />
                          Apply Pattern
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5 text-purple-600" />
                  <span>Performance Predictions</span>
                </CardTitle>
                <CardDescription>AI forecasts for your upcoming tests and optimizations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Gaming Headset Price Test</h4>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        92% confidence
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Predicted to increase conversions by 15-22% based on similar product patterns
                    </p>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center">
                        <div className="font-semibold text-blue-600">18.5%</div>
                        <div className="text-xs text-muted-foreground">Expected Lift</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-green-600">14 days</div>
                        <div className="text-xs text-muted-foreground">To Significance</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-purple-600">$1,247</div>
                        <div className="text-xs text-muted-foreground">Revenue Impact</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Seasonal Holiday Optimization</h4>
                      <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
                        78% confidence
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Holiday-themed copy predicted to boost performance by 35-45% during Q4
                    </p>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center">
                        <div className="font-semibold text-blue-600">40%</div>
                        <div className="text-xs text-muted-foreground">Expected Lift</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-green-600">Nov-Dec</div>
                        <div className="text-xs text-muted-foreground">Peak Period</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-purple-600">$4,892</div>
                        <div className="text-xs text-muted-foreground">Revenue Impact</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Mobile Optimization Initiative</h4>
                      <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                        85% confidence
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Mobile-specific optimizations could recover 25-30% of lost mobile conversions
                    </p>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center">
                        <div className="font-semibold text-blue-600">27.5%</div>
                        <div className="text-xs text-muted-foreground">Recovery Rate</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-green-600">21 days</div>
                        <div className="text-xs text-muted-foreground">Implementation</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold text-purple-600">$3,156</div>
                        <div className="text-xs text-muted-foreground">Monthly Impact</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-green-600" />
                  <span>Risk Assessment</span>
                </CardTitle>
                <CardDescription>Potential risks and mitigation strategies for your tests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg border-red-200 bg-red-50 dark:bg-red-950 dark:border-red-800">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="h-4 w-4 text-red-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-red-700 dark:text-red-300">High Risk</h4>
                        <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                          Testing aggressive discount language may devalue brand perception
                        </p>
                        <div className="mt-2 text-xs text-red-500">
                          Mitigation: Test with limited traffic allocation (20/80 split)
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg border-yellow-200 bg-yellow-50 dark:bg-yellow-950 dark:border-yellow-800">
                    <div className="flex items-start space-x-2">
                      <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-yellow-700 dark:text-yellow-300">Medium Risk</h4>
                        <p className="text-sm text-yellow-600 dark:text-yellow-400 mt-1">
                          Seasonal tests may not provide reliable year-round insights
                        </p>
                        <div className="mt-2 text-xs text-yellow-500">
                          Mitigation: Plan follow-up tests for different seasons
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg border-green-200 bg-green-50 dark:bg-green-950 dark:border-green-800">
                    <div className="flex items-start space-x-2">
                      <Shield className="h-4 w-4 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-green-700 dark:text-green-300">Low Risk</h4>
                        <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                          Emoji and formatting tests have minimal downside risk
                        </p>
                        <div className="mt-2 text-xs text-green-500">
                          Recommendation: Proceed with standard 50/50 traffic split
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">Risk Mitigation Strategies</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start space-x-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground mt-1 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Implement automatic rollback triggers for performance drops &gt;10%
                      </span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground mt-1 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Use progressive traffic allocation for high-risk tests
                      </span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground mt-1 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Monitor brand sentiment during aggressive promotional tests
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Rocket className="h-5 w-5 text-blue-600" />
                <span>Actionable Recommendations</span>
              </CardTitle>
              <CardDescription>Prioritized action items based on AI analysis of your test results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-200 dark:border-green-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-green-700 dark:text-green-300">
                          Immediate Action: Apply Emoji Strategy
                        </h3>
                        <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                          Roll out emoji + urgency pattern to 23 similar tech product links
                        </p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      High Impact
                    </Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-600">$2,847</div>
                      <div className="text-xs text-muted-foreground">Est. Monthly Revenue</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-600">23</div>
                      <div className="text-xs text-muted-foreground">Applicable Links</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-600">2 hours</div>
                      <div className="text-xs text-muted-foreground">Implementation Time</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-green-600">Based on 87% confidence from AirPods Pro test</div>
                    <Button size="sm" className="bg-gradient-to-r from-green-600 to-emerald-600">
                      <Zap className="mr-2 h-4 w-4" />
                      Implement Now
                    </Button>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 border-blue-200 dark:border-blue-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                        <Users className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-blue-700 dark:text-blue-300">
                          Priority: Mobile Optimization
                        </h3>
                        <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">
                          Create mobile-specific versions for top 15 performing links
                        </p>
                      </div>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">High Impact</Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-blue-600">$3,156</div>
                      <div className="text-xs text-muted-foreground">Est. Monthly Recovery</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-blue-600">58%</div>
                      <div className="text-xs text-muted-foreground">Mobile Traffic</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-blue-600">1 week</div>
                      <div className="text-xs text-muted-foreground">Implementation Time</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-blue-600">
                      31% performance gap identified between mobile and desktop
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-cyan-600">
                      <MousePointer className="mr-2 h-4 w-4" />
                      Start Mobile Tests
                    </Button>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-200 dark:border-purple-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                        <Calendar className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-purple-700 dark:text-purple-300">
                          Seasonal: Holiday Preparation
                        </h3>
                        <p className="text-sm text-purple-600 dark:text-purple-400 mt-1">
                          Prepare holiday-themed variations for Q4 performance boost
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline">Medium Impact</Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-purple-600">$4,892</div>
                      <div className="text-xs text-muted-foreground">Q4 Revenue Potential</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-purple-600">45%</div>
                      <div className="text-xs text-muted-foreground">Expected Lift</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-purple-600">Oct 15</div>
                      <div className="text-xs text-muted-foreground">Start Date</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-purple-600">
                      Historical data shows 45% CTR increase for gift-focused copy
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-purple-600 to-pink-600">
                      <Calendar className="mr-2 h-4 w-4" />
                      Schedule Campaign
                    </Button>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
                        <BarChart3 className="h-4 w-4 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Long-term: Review Format Expansion</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          Apply review-style format to health & fitness category links
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline">Medium Impact</Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-orange-600">$1,923</div>
                      <div className="text-xs text-muted-foreground">Est. Monthly Revenue</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-orange-600">34%</div>
                      <div className="text-xs text-muted-foreground">Engagement Increase</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold text-orange-600">3 weeks</div>
                      <div className="text-xs text-muted-foreground">Implementation Time</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      Based on 95% confidence from fitness tracker test
                    </div>
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" />
                      Plan Implementation
                    </Button>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-gradient-to-r from-gray-50 to-slate-50 dark:from-gray-900 dark:to-slate-900 rounded-lg border">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Total Potential Impact</h4>
                    <p className="text-sm text-muted-foreground">Implementing all high-impact recommendations</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">$12,818</div>
                    <div className="text-sm text-muted-foreground">Monthly Revenue Increase</div>
                  </div>
                </div>

                <div className="mt-4 flex space-x-2">
                  <Button className="bg-gradient-to-r from-green-600 to-emerald-600 flex-1">
                    <Rocket className="mr-2 h-4 w-4" />
                    Implement All High-Impact Actions
                  </Button>
                  <Button variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Export Report
                  </Button>
                  <Button variant="outline">
                    <Share className="mr-2 h-4 w-4" />
                    Share Insights
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
