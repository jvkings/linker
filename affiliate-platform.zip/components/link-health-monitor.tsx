"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Shield, RefreshCw, AlertTriangle, CheckCircle, Clock, ExternalLink } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface LinkIssue {
  id: number
  url: string
  shortUrl: string
  status: "broken" | "warning"
  statusCode?: number
  responseTime?: number
  redirectUrl?: string
  lastChecked: string
  clicks: number
  suggestedFix?: string | null
}

interface HealthData {
  summary: {
    totalLinks: number
    healthyLinks: number
    brokenLinks: number
    warningLinks: number
    healthScore: number
    lastChecked: string
  }
  issues: LinkIssue[]
}

export function LinkHealthMonitor() {
  const [healthData, setHealthData] = useState<HealthData | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [fixing, setFixing] = useState(false)
  const { toast } = useToast()

  const fetchHealthData = async (showRefreshToast = false) => {
    try {
      if (showRefreshToast) setRefreshing(true)

      const response = await fetch("/api/link-health")
      if (!response.ok) throw new Error("Failed to fetch health data")

      const data: HealthData = await response.json()
      setHealthData(data)

      if (showRefreshToast) {
        toast({
          title: "Health check completed",
          description: "Link health data has been refreshed.",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load health data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const fixBrokenLinks = async () => {
    try {
      setFixing(true)

      const response = await fetch("/api/link-health", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "fix-broken-links" }),
      })

      if (!response.ok) throw new Error("Failed to fix links")

      const result = await response.json()

      toast({
        title: "Links fixed successfully",
        description: `Fixed ${result.fixedCount} broken links.`,
      })

      // Refresh data after fixing
      await fetchHealthData()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fix broken links. Please try again.",
        variant: "destructive",
      })
    } finally {
      setFixing(false)
    }
  }

  useEffect(() => {
    fetchHealthData()
  }, [])

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date()
    const time = new Date(timestamp)
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "broken":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "warning":
        return <Clock className="h-4 w-4 text-yellow-500" />
      default:
        return <CheckCircle className="h-4 w-4 text-green-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "broken":
        return "bg-red-100 text-red-800"
      case "warning":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-green-100 text-green-800"
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="mr-2 h-5 w-5" />
            Link Health Monitor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-2 bg-gray-200 rounded"></div>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!healthData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="mr-2 h-5 w-5" />
            Link Health Monitor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Failed to load health data</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Shield className="mr-2 h-5 w-5" />
              Link Health Monitor
            </CardTitle>
            <CardDescription>
              Overall health: {healthData.summary.healthScore}% • Last checked{" "}
              {formatTimeAgo(healthData.summary.lastChecked)}
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => fetchHealthData(true)} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Health Score */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Health Score</span>
            <span className="font-medium">{healthData.summary.healthScore}%</span>
          </div>
          <Progress value={healthData.summary.healthScore} className="h-2" />
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Total Links</span>
            <span className="font-medium">{healthData.summary.totalLinks.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Healthy</span>
            <span className="font-medium text-green-600">{healthData.summary.healthyLinks.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Broken</span>
            <span className="font-medium text-red-600">{healthData.summary.brokenLinks}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Warnings</span>
            <span className="font-medium text-yellow-600">{healthData.summary.warningLinks}</span>
          </div>
        </div>

        {/* Issues List */}
        {healthData.issues.length > 0 && (
          <>
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Recent Issues</h4>
              {healthData.summary.brokenLinks > 0 && (
                <Button size="sm" onClick={fixBrokenLinks} disabled={fixing}>
                  {fixing ? "Fixing..." : "Fix All"}
                </Button>
              )}
            </div>

            <ScrollArea className="h-[200px]">
              <div className="space-y-3">
                {healthData.issues.map((issue) => (
                  <div key={issue.id} className="p-3 border rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(issue.status)}
                        <Badge className={getStatusColor(issue.status)}>{issue.status}</Badge>
                        {issue.statusCode && <span className="text-xs text-gray-500">{issue.statusCode}</span>}
                      </div>
                      <span className="text-xs text-gray-500">{issue.clicks} clicks</span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{issue.shortUrl}</code>
                        <Button variant="ghost" size="sm" asChild>
                          <a href={issue.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      </div>

                      {issue.suggestedFix && (
                        <div className="text-xs text-green-600">Suggested fix: {issue.suggestedFix}</div>
                      )}

                      {issue.responseTime && (
                        <div className="text-xs text-gray-500">Response time: {issue.responseTime}ms</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </>
        )}

        {healthData.issues.length === 0 && (
          <div className="text-center py-4">
            <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">All links are healthy!</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
