"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Scan,
  Globe,
  Download,
  Copy,
  ExternalLink,
  Settings,
  Search,
  LinkIcon,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ScannedLink {
  id: string
  url: string
  text: string
  type: "internal" | "external" | "affiliate" | "image" | "email"
  status: "active" | "broken" | "redirect" | "slow"
  statusCode?: number
  responseTime?: number
  keywords: string[]
  context: string
  page: string
  position: number
}

interface ScanResults {
  summary: {
    totalLinks: number
    internalLinks: number
    externalLinks: number
    affiliateLinks: number
    brokenLinks: number
    slowLinks: number
    pagesScanned: number
    scanTime: number
  }
  links: ScannedLink[]
}

export default function WebsiteScannerPage() {
  const [websiteUrl, setWebsiteUrl] = useState("")
  const [scanDepth, setScanDepth] = useState("2")
  const [includeImages, setIncludeImages] = useState(true)
  const [includeExternal, setIncludeExternal] = useState(true)
  const [checkStatus, setCheckStatus] = useState(true)
  const [extractKeywords, setExtractKeywords] = useState(true)
  const [scanning, setScanning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [currentPage, setCurrentPage] = useState("")
  const [results, setResults] = useState<ScanResults | null>(null)
  const [filter, setFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const { toast } = useToast()

  const generateMockResults = (url: string): ScanResults => {
    const mockLinks: ScannedLink[] = [
      {
        id: "1",
        url: "https://example.com/about",
        text: "About Us",
        type: "internal",
        status: "active",
        statusCode: 200,
        responseTime: 245,
        keywords: ["about", "company", "team"],
        context: "Learn more about our company and team",
        page: "/index.html",
        position: 1,
      },
      {
        id: "2",
        url: "https://amazon.com/dp/B08N5WRWNW",
        text: "Best Wireless Headphones",
        type: "affiliate",
        status: "active",
        statusCode: 200,
        responseTime: 1200,
        keywords: ["wireless", "headphones", "best", "audio"],
        context: "Check out these amazing wireless headphones",
        page: "/blog/headphones-review",
        position: 3,
      },
      {
        id: "3",
        url: "https://oldsite.com/broken-page",
        text: "Broken Link",
        type: "external",
        status: "broken",
        statusCode: 404,
        keywords: ["broken", "error"],
        context: "This link no longer works",
        page: "/resources",
        position: 5,
      },
      {
        id: "4",
        url: "https://example.com/products",
        text: "Our Products",
        type: "internal",
        status: "active",
        statusCode: 200,
        responseTime: 180,
        keywords: ["products", "catalog", "shop"],
        context: "Browse our complete product catalog",
        page: "/index.html",
        position: 2,
      },
      {
        id: "5",
        url: "https://slowsite.com/page",
        text: "Slow Loading Page",
        type: "external",
        status: "slow",
        statusCode: 200,
        responseTime: 8500,
        keywords: ["slow", "performance"],
        context: "This page takes too long to load",
        page: "/blog/performance",
        position: 4,
      },
      {
        id: "6",
        url: "https://example.com/contact",
        text: "Contact Us",
        type: "internal",
        status: "active",
        statusCode: 200,
        responseTime: 156,
        keywords: ["contact", "support", "help"],
        context: "Get in touch with our support team",
        page: "/index.html",
        position: 6,
      },
      {
        id: "7",
        url: "https://affiliate-network.com/product/xyz",
        text: "Special Offer - 50% Off",
        type: "affiliate",
        status: "redirect",
        statusCode: 301,
        responseTime: 450,
        keywords: ["special", "offer", "discount", "sale"],
        context: "Limited time offer with huge savings",
        page: "/deals",
        position: 1,
      },
      {
        id: "8",
        url: "mailto:support@example.com",
        text: "Email Support",
        type: "email",
        status: "active",
        keywords: ["email", "support", "contact"],
        context: "Send us an email for support",
        page: "/contact",
        position: 2,
      },
    ]

    return {
      summary: {
        totalLinks: mockLinks.length,
        internalLinks: mockLinks.filter((l) => l.type === "internal").length,
        externalLinks: mockLinks.filter((l) => l.type === "external").length,
        affiliateLinks: mockLinks.filter((l) => l.type === "affiliate").length,
        brokenLinks: mockLinks.filter((l) => l.status === "broken").length,
        slowLinks: mockLinks.filter((l) => l.status === "slow").length,
        pagesScanned: 5,
        scanTime: 12.5,
      },
      links: mockLinks,
    }
  }

  const startScan = async () => {
    if (!websiteUrl.trim()) {
      toast({
        title: "Website URL required",
        description: "Please enter a website URL to scan.",
        variant: "destructive",
      })
      return
    }

    try {
      new URL(websiteUrl)
    } catch {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid website URL.",
        variant: "destructive",
      })
      return
    }

    setScanning(true)
    setProgress(0)
    setCurrentPage("")
    setResults(null)

    // Simulate scanning process
    const pages = ["Homepage", "About Page", "Products Page", "Blog Posts", "Contact Page"]

    for (let i = 0; i < pages.length; i++) {
      setCurrentPage(pages[i])
      setProgress(((i + 1) / pages.length) * 100)
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }

    const scanResults = generateMockResults(websiteUrl)
    setResults(scanResults)
    setScanning(false)

    toast({
      title: "Scan completed",
      description: `Found ${scanResults.summary.totalLinks} links across ${scanResults.summary.pagesScanned} pages.`,
    })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "broken":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "redirect":
        return <ExternalLink className="h-4 w-4 text-yellow-500" />
      case "slow":
        return <Clock className="h-4 w-4 text-orange-500" />
      default:
        return <LinkIcon className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "broken":
        return "bg-red-100 text-red-800"
      case "redirect":
        return "bg-yellow-100 text-yellow-800"
      case "slow":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "internal":
        return "bg-blue-100 text-blue-800"
      case "external":
        return "bg-purple-100 text-purple-800"
      case "affiliate":
        return "bg-green-100 text-green-800"
      case "image":
        return "bg-pink-100 text-pink-800"
      case "email":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredLinks =
    results?.links.filter((link) => {
      const matchesFilter = filter === "all" || link.type === filter || link.status === filter
      const matchesSearch =
        searchTerm === "" ||
        link.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
        link.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
        link.keywords.some((k) => k.toLowerCase().includes(searchTerm.toLowerCase()))

      return matchesFilter && matchesSearch
    }) || []

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "URL has been copied to your clipboard.",
    })
  }

  const exportResults = () => {
    if (!results) return

    const csv = [
      "URL,Text,Type,Status,Status Code,Response Time,Keywords,Context,Page,Position",
      ...results.links.map(
        (l) =>
          `"${l.url}","${l.text}","${l.type}","${l.status}","${l.statusCode || ""}","${l.responseTime || ""}","${l.keywords.join(", ")}","${l.context}","${l.page}","${l.position}"`,
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "website-scan-results.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Website Scanner</h1>
        <p className="text-gray-600">Comprehensive website analysis and link discovery</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Scan Configuration */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2 h-5 w-5" />
                Scan Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="website-url">Website URL</Label>
                <Input
                  id="website-url"
                  placeholder="https://example.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="scan-depth">Scan Depth</Label>
                <Select value={scanDepth} onValueChange={setScanDepth}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 level (Homepage only)</SelectItem>
                    <SelectItem value="2">2 levels (+ Direct links)</SelectItem>
                    <SelectItem value="3">3 levels (Deep scan)</SelectItem>
                    <SelectItem value="unlimited">Unlimited (Full site)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="include-images">Include Images</Label>
                  <Switch id="include-images" checked={includeImages} onCheckedChange={setIncludeImages} />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="include-external">External Links</Label>
                  <Switch id="include-external" checked={includeExternal} onCheckedChange={setIncludeExternal} />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="check-status">Check Status</Label>
                  <Switch id="check-status" checked={checkStatus} onCheckedChange={setCheckStatus} />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="extract-keywords">Extract Keywords</Label>
                  <Switch id="extract-keywords" checked={extractKeywords} onCheckedChange={setExtractKeywords} />
                </div>
              </div>

              <Button onClick={startScan} disabled={scanning || !websiteUrl.trim()} className="w-full">
                <Scan className="h-4 w-4 mr-2" />
                {scanning ? "Scanning..." : "Start Scan"}
              </Button>
            </CardContent>
          </Card>

          {/* Scan Progress */}
          {scanning && (
            <Card>
              <CardHeader>
                <CardTitle>Scan Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Progress</span>
                    <span className="text-sm text-gray-600">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  {currentPage && <div className="text-sm text-gray-600">Scanning: {currentPage}</div>}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Results Section */}
        <div className="lg:col-span-3 space-y-6">
          {results && (
            <>
              {/* Summary Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">{results.summary.totalLinks}</div>
                    <div className="text-xs text-gray-600">Total Links</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{results.summary.internalLinks}</div>
                    <div className="text-xs text-gray-600">Internal</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">{results.summary.brokenLinks}</div>
                    <div className="text-xs text-gray-600">Broken</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">{results.summary.affiliateLinks}</div>
                    <div className="text-xs text-gray-600">Affiliate</div>
                  </CardContent>
                </Card>
              </div>

              {/* Filters and Search */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Discovered Links</CardTitle>
                    <Button variant="outline" size="sm" onClick={exportResults}>
                      <Download className="h-4 w-4 mr-2" />
                      Export CSV
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-4 mb-4">
                    <div className="flex-1">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search links, text, or keywords..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <Select value={filter} onValueChange={setFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Links</SelectItem>
                        <SelectItem value="internal">Internal</SelectItem>
                        <SelectItem value="external">External</SelectItem>
                        <SelectItem value="affiliate">Affiliate</SelectItem>
                        <SelectItem value="broken">Broken</SelectItem>
                        <SelectItem value="slow">Slow</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="text-sm text-gray-600 mb-4">
                    Showing {filteredLinks.length} of {results.summary.totalLinks} links
                  </div>

                  <ScrollArea className="h-[600px]">
                    <div className="space-y-3">
                      {filteredLinks.map((link) => (
                        <div key={link.id} className="p-4 border rounded-lg space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(link.status)}
                              <Badge className={getStatusColor(link.status)}>{link.status}</Badge>
                              <Badge className={getTypeColor(link.type)}>{link.type}</Badge>
                              {link.statusCode && <span className="text-xs text-gray-500">{link.statusCode}</span>}
                              {link.responseTime && (
                                <span className="text-xs text-gray-500">{link.responseTime}ms</span>
                              )}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(link.url)}>
                                <Copy className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" asChild>
                                <a href={link.url} target="_blank" rel="noopener noreferrer">
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </Button>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div>
                              <div className="text-sm font-medium text-gray-900">{link.text}</div>
                              <div className="text-xs text-gray-500 font-mono">{link.url}</div>
                            </div>

                            <div className="text-sm text-gray-600">{link.context}</div>

                            <div className="flex items-center justify-between text-xs text-gray-500">
                              <span>Found on: {link.page}</span>
                              <span>Position: {link.position}</span>
                            </div>

                            {link.keywords.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {link.keywords.map((keyword, index) => (
                                  <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                                    {keyword}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </>
          )}

          {!results && !scanning && (
            <Card>
              <CardContent className="p-12 text-center">
                <Globe className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Scan</h3>
                <p className="text-gray-600">Enter a website URL and configure your scan settings to get started.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
