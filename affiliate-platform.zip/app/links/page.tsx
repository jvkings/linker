import { EnhancedLinkManager } from "@/components/enhanced-link-manager"
import { BulkProcessor } from "@/components/bulk-processor"
import { AutoLinkingManager } from "@/components/auto-linking-manager"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LinksPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Link Management</h2>
          <p className="text-muted-foreground">Create, manage, and optimize your affiliate links</p>
        </div>
      </div>

      <Tabs defaultValue="manage" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="manage">Manage Links</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Processing</TabsTrigger>
          <TabsTrigger value="auto-linking">Auto-Linking</TabsTrigger>
          <TabsTrigger value="prettify">Prettification</TabsTrigger>
        </TabsList>

        <TabsContent value="manage">
          <EnhancedLinkManager />
        </TabsContent>

        <TabsContent value="bulk">
          <BulkProcessor />
        </TabsContent>

        <TabsContent value="auto-linking">
          <AutoLinkingManager />
        </TabsContent>

        <TabsContent value="prettify">
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold mb-2">Link Prettification</h3>
            <p className="text-muted-foreground">Advanced prettification features coming soon...</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
