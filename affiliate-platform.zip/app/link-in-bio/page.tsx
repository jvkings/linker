"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Users,
  Plus,
  Edit,
  Trash2,
  Copy,
  ExternalLink,
  Eye,
  BarChart3,
  Palette,
  Settings,
  Instagram,
  Twitter,
  Youtube,
  Facebook,
  Linkedin,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface BioLink {
  id: string
  title: string
  url: string
  description?: string
  clicks: number
  isActive: boolean
  icon?: string
}

interface BioPage {
  id: string
  username: string
  title: string
  description: string
  avatar: string
  theme: string
  customDomain?: string
  links: BioLink[]
  socialLinks: Record<string, string>
  analytics: {
    totalClicks: number
    uniqueVisitors: number
    topLink: string
  }
}

export default function LinkInBioPage() {
  const [bioPages, setBioPages] = useState<BioPage[]>([
    {
      id: "1",
      username: "johndoe",
      title: "John Doe",
      description: "Digital Creator & Entrepreneur",
      avatar: "/placeholder.svg?height=100&width=100",
      theme: "modern",
      customDomain: "john.bio",
      links: [
        {
          id: "1",
          title: "My Latest Blog Post",
          url: "https://blog.johndoe.com/latest",
          description: "Check out my thoughts on digital marketing",
          clicks: 245,
          isActive: true,
          icon: "📝",
        },
        {
          id: "2",
          title: "YouTube Channel",
          url: "https://youtube.com/johndoe",
          description: "Subscribe for weekly content",
          clicks: 189,
          isActive: true,
          icon: "📺",
        },
        {
          id: "3",
          title: "Free Course",
          url: "https://course.johndoe.com",
          description: "Learn digital marketing for free",
          clicks: 156,
          isActive: true,
          icon: "🎓",
        },
      ],
      socialLinks: {
        instagram: "https://instagram.com/johndoe",
        twitter: "https://twitter.com/johndoe",
        youtube: "https://youtube.com/johndoe",
      },
      analytics: {
        totalClicks: 590,
        uniqueVisitors: 423,
        topLink: "My Latest Blog Post",
      },
    },
  ])

  const [selectedPage, setSelectedPage] = useState<string>("1")
  const [editingLink, setEditingLink] = useState<BioLink | null>(null)
  const [newLink, setNewLink] = useState({
    title: "",
    url: "",
    description: "",
    icon: "",
  })
  const { toast } = useToast()

  const themes = [
    { id: "modern", name: "Modern", preview: "bg-gradient-to-br from-blue-500 to-purple-600" },
    { id: "minimal", name: "Minimal", preview: "bg-white border-2 border-gray-200" },
    { id: "dark", name: "Dark", preview: "bg-gray-900" },
    { id: "colorful", name: "Colorful", preview: "bg-gradient-to-br from-pink-500 to-yellow-500" },
    { id: "nature", name: "Nature", preview: "bg-gradient-to-br from-green-500 to-blue-500" },
  ]

  const socialPlatforms = [
    { id: "instagram", name: "Instagram", icon: Instagram, color: "text-pink-600" },
    { id: "twitter", name: "Twitter", icon: Twitter, color: "text-blue-500" },
    { id: "youtube", name: "YouTube", icon: Youtube, color: "text-red-600" },
    { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-700" },
    { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "text-blue-800" },
  ]

  const currentPage = bioPages.find((page) => page.id === selectedPage)

  const addLink = () => {
    if (!newLink.title || !newLink.url) {
      toast({
        title: "Missing information",
        description: "Please provide both title and URL for the link.",
        variant: "destructive",
      })
      return
    }

    const link: BioLink = {
      id: Date.now().toString(),
      title: newLink.title,
      url: newLink.url,
      description: newLink.description,
      clicks: 0,
      isActive: true,
      icon: newLink.icon,
    }

    setBioPages((pages) =>
      pages.map((page) => (page.id === selectedPage ? { ...page, links: [...page.links, link] } : page)),
    )

    setNewLink({ title: "", url: "", description: "", icon: "" })

    toast({
      title: "Link added",
      description: "New link has been added to your bio page.",
    })
  }

  const updateLink = (linkId: string, updates: Partial<BioLink>) => {
    setBioPages((pages) =>
      pages.map((page) =>
        page.id === selectedPage
          ? {
              ...page,
              links: page.links.map((link) => (link.id === linkId ? { ...link, ...updates } : link)),
            }
          : page,
      ),
    )
  }

  const deleteLink = (linkId: string) => {
    setBioPages((pages) =>
      pages.map((page) =>
        page.id === selectedPage
          ? {
              ...page,
              links: page.links.filter((link) => link.id !== linkId),
            }
          : page,
      ),
    )

    toast({
      title: "Link deleted",
      description: "Link has been removed from your bio page.",
    })
  }

  const copyBioUrl = () => {
    const url = currentPage?.customDomain
      ? `https://${currentPage.customDomain}`
      : `https://linkmaster.bio/${currentPage?.username}`

    navigator.clipboard.writeText(url)
    toast({
      title: "URL copied",
      description: "Bio page URL has been copied to your clipboard.",
    })
  }

  const updatePageSettings = (updates: Partial<BioPage>) => {
    setBioPages((pages) => pages.map((page) => (page.id === selectedPage ? { ...page, ...updates } : page)))
  }

  if (!currentPage) {
    return <div>Page not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Link in Bio</h1>
        <p className="text-gray-600">Create beautiful landing pages for your social media</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor Section */}
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="links" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="links">Links</TabsTrigger>
              <TabsTrigger value="design">Design</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="links" className="space-y-6">
              {/* Add New Link */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="mr-2 h-5 w-5" />
                    Add New Link
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="link-title">Title</Label>
                      <Input
                        id="link-title"
                        placeholder="Link title"
                        value={newLink.title}
                        onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="link-url">URL</Label>
                      <Input
                        id="link-url"
                        placeholder="https://example.com"
                        value={newLink.url}
                        onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="link-description">Description (optional)</Label>
                    <Input
                      id="link-description"
                      placeholder="Brief description"
                      value={newLink.description}
                      onChange={(e) => setNewLink({ ...newLink, description: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="link-icon">Icon (emoji)</Label>
                    <Input
                      id="link-icon"
                      placeholder="📝"
                      value={newLink.icon}
                      onChange={(e) => setNewLink({ ...newLink, icon: e.target.value })}
                      className="w-20"
                    />
                  </div>
                  <Button onClick={addLink}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Link
                  </Button>
                </CardContent>
              </Card>

              {/* Existing Links */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Links</CardTitle>
                  <CardDescription>
                    {currentPage.links.length} links • {currentPage.analytics.totalClicks} total clicks
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-3">
                      {currentPage.links.map((link) => (
                        <div key={link.id} className="p-4 border rounded-lg space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              {link.icon && <span className="text-lg">{link.icon}</span>}
                              <div>
                                <div className="font-medium">{link.title}</div>
                                <div className="text-sm text-gray-500">{link.url}</div>
                                {link.description && <div className="text-sm text-gray-600">{link.description}</div>}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline">{link.clicks} clicks</Badge>
                              <Switch
                                checked={link.isActive}
                                onCheckedChange={(checked) => updateLink(link.id, { isActive: checked })}
                              />
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => deleteLink(link.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="design" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Palette className="mr-2 h-5 w-5" />
                    Theme Selection
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {themes.map((theme) => (
                      <div
                        key={theme.id}
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                          currentPage.theme === theme.id ? "border-blue-500" : "border-gray-200"
                        }`}
                        onClick={() => updatePageSettings({ theme: theme.id })}
                      >
                        <div className={`w-full h-20 rounded-lg mb-2 ${theme.preview}`}></div>
                        <div className="text-sm font-medium text-center">{theme.name}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {socialPlatforms.map((platform) => (
                    <div key={platform.id} className="flex items-center space-x-3">
                      <platform.icon className={`h-5 w-5 ${platform.color}`} />
                      <Label className="w-20">{platform.name}</Label>
                      <Input
                        placeholder={`Your ${platform.name} URL`}
                        value={currentPage.socialLinks[platform.id] || ""}
                        onChange={(e) =>
                          updatePageSettings({
                            socialLinks: {
                              ...currentPage.socialLinks,
                              [platform.id]: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="mr-2 h-5 w-5" />
                    Page Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="page-title">Page Title</Label>
                    <Input
                      id="page-title"
                      value={currentPage.title}
                      onChange={(e) => updatePageSettings({ title: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="page-description">Description</Label>
                    <Textarea
                      id="page-description"
                      value={currentPage.description}
                      onChange={(e) => updatePageSettings({ description: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      value={currentPage.username}
                      onChange={(e) => updatePageSettings({ username: e.target.value })}
                    />
                    <div className="text-xs text-gray-500 mt-1">
                      Your page will be available at: linkmaster.bio/{currentPage.username}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="custom-domain">Custom Domain (optional)</Label>
                    <Input
                      id="custom-domain"
                      placeholder="yourdomain.com"
                      value={currentPage.customDomain || ""}
                      onChange={(e) => updatePageSettings({ customDomain: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">{currentPage.analytics.totalClicks}</div>
                    <div className="text-xs text-gray-600">Total Clicks</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{currentPage.analytics.uniqueVisitors}</div>
                    <div className="text-xs text-gray-600">Unique Visitors</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-lg font-bold text-purple-600">{currentPage.analytics.topLink}</div>
                    <div className="text-xs text-gray-600">Top Performing Link</div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="mr-2 h-5 w-5" />
                    Link Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {currentPage.links
                      .sort((a, b) => b.clicks - a.clicks)
                      .map((link) => (
                        <div key={link.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            {link.icon && <span>{link.icon}</span>}
                            <div>
                              <div className="font-medium">{link.title}</div>
                              <div className="text-sm text-gray-500">{link.url}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">{link.clicks}</div>
                            <div className="text-xs text-gray-500">clicks</div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Preview Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Eye className="mr-2 h-5 w-5" />
                  Preview
                </CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={copyBioUrl}>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy URL
                  </Button>
                  <Button variant="outline" size="sm" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Visit
                    </a>
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Mobile Preview */}
              <div className="mx-auto max-w-sm">
                <div className="bg-white border-8 border-gray-800 rounded-[2.5rem] p-4 shadow-xl">
                  <div className="text-center space-y-4">
                    {/* Avatar */}
                    <div className="w-20 h-20 bg-gray-300 rounded-full mx-auto"></div>

                    {/* Title & Description */}
                    <div>
                      <h2 className="text-lg font-bold">{currentPage.title}</h2>
                      <p className="text-sm text-gray-600">{currentPage.description}</p>
                    </div>

                    {/* Social Links */}
                    <div className="flex justify-center space-x-4">
                      {Object.entries(currentPage.socialLinks).map(([platform, url]) => {
                        const platformData = socialPlatforms.find((p) => p.id === platform)
                        if (!url || !platformData) return null
                        return <platformData.icon key={platform} className={`h-5 w-5 ${platformData.color}`} />
                      })}
                    </div>

                    {/* Links */}
                    <div className="space-y-3">
                      {currentPage.links
                        .filter((link) => link.isActive)
                        .map((link) => (
                          <div key={link.id} className="p-3 bg-gray-100 rounded-lg">
                            <div className="flex items-center space-x-2">
                              {link.icon && <span>{link.icon}</span>}
                              <div className="text-left">
                                <div className="font-medium text-sm">{link.title}</div>
                                {link.description && <div className="text-xs text-gray-600">{link.description}</div>}
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="mr-2 h-5 w-5" />
                Quick Stats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Active Links:</span>
                <span className="font-medium">{currentPage.links.filter((l) => l.isActive).length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Total Clicks:</span>
                <span className="font-medium">{currentPage.analytics.totalClicks}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Unique Visitors:</span>
                <span className="font-medium">{currentPage.analytics.uniqueVisitors}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Social Links:</span>
                <span className="font-medium">{Object.values(currentPage.socialLinks).filter(Boolean).length}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
