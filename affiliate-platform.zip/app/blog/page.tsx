import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Calendar, User, ArrowRight, Search } from "lucide-react"

const featuredPost = {
  id: 1,
  title: "The Complete Guide to AI-Powered Affiliate Marketing in 2024",
  excerpt:
    "Discover how artificial intelligence is revolutionizing affiliate marketing and learn practical strategies to implement AI in your campaigns for maximum ROI.",
  author: "Sarah Johnson",
  date: "2024-01-15",
  readTime: "12 min read",
  category: "AI & Automation",
  image: "/placeholder.svg?height=400&width=800",
  featured: true,
}

const blogPosts = [
  {
    id: 2,
    title: "10 A/B Testing Strategies That Increased Our Conversion Rate by 40%",
    excerpt:
      "Learn the exact A/B testing methodologies we used to dramatically improve our affiliate link performance.",
    author: "Michael Chen",
    date: "2024-01-12",
    readTime: "8 min read",
    category: "Optimization",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 3,
    title: "How to Choose the Right Affiliate Networks for Your Niche",
    excerpt:
      "A comprehensive guide to evaluating and selecting affiliate networks that align with your business goals.",
    author: "Emily Rodriguez",
    date: "2024-01-10",
    readTime: "6 min read",
    category: "Strategy",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 4,
    title: "Link Cloaking Best Practices: Security and SEO Considerations",
    excerpt: "Everything you need to know about link cloaking, from security benefits to SEO implications.",
    author: "David Kim",
    date: "2024-01-08",
    readTime: "10 min read",
    category: "Technical",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 5,
    title: "The Psychology of High-Converting Affiliate Links",
    excerpt: "Understand the psychological triggers that make affiliate links irresistible to your audience.",
    author: "Sarah Johnson",
    date: "2024-01-05",
    readTime: "7 min read",
    category: "Psychology",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 6,
    title: "Mobile Optimization: Why 60% of Your Clicks Come from Mobile",
    excerpt: "Mobile traffic dominates affiliate marketing. Learn how to optimize your links for mobile users.",
    author: "Michael Chen",
    date: "2024-01-03",
    readTime: "9 min read",
    category: "Mobile",
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 7,
    title: "Building Trust: How Transparency Increases Affiliate Conversions",
    excerpt: "Discover why transparency in affiliate marketing builds trust and drives higher conversion rates.",
    author: "Emily Rodriguez",
    date: "2024-01-01",
    readTime: "5 min read",
    category: "Trust & Ethics",
    image: "/placeholder.svg?height=300&width=400",
  },
]

const categories = [
  "All Posts",
  "AI & Automation",
  "Optimization",
  "Strategy",
  "Technical",
  "Psychology",
  "Mobile",
  "Trust & Ethics",
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold sm:text-5xl mb-4">LinkMaster Pro Blog</h1>
            <p className="text-xl max-w-2xl mx-auto mb-8">
              Insights, strategies, and best practices for affiliate marketing success
            </p>

            {/* Search Bar */}
            <div className="max-w-md mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search articles..."
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-12 justify-center">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={category === "All Posts" ? "default" : "outline"}
              className="cursor-pointer hover:bg-blue-100"
            >
              {category}
            </Badge>
          ))}
        </div>

        {/* Featured Post */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Article</h2>
          <Card className="overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src={featuredPost.image || "/placeholder.svg"}
                  alt={featuredPost.title}
                  className="w-full h-64 md:h-full object-cover"
                />
              </div>
              <div className="md:w-1/2 p-8">
                <Badge className="mb-4">{featuredPost.category}</Badge>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{featuredPost.title}</h3>
                <p className="text-gray-600 mb-6">{featuredPost.excerpt}</p>
                <div className="flex items-center text-sm text-gray-500 mb-6">
                  <User className="h-4 w-4 mr-2" />
                  <span className="mr-4">{featuredPost.author}</span>
                  <Calendar className="h-4 w-4 mr-2" />
                  <span className="mr-4">{featuredPost.date}</span>
                  <span>{featuredPost.readTime}</span>
                </div>
                <Button asChild>
                  <Link href={`/blog/${featuredPost.id}`}>
                    Read Article
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Blog Posts Grid */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Latest Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video">
                  <img src={post.image || "/placeholder.svg"} alt={post.title} className="w-full h-full object-cover" />
                </div>
                <CardHeader>
                  <Badge variant="outline" className="w-fit mb-2">
                    {post.category}
                  </Badge>
                  <CardTitle className="line-clamp-2">
                    <Link href={`/blog/${post.id}`} className="hover:text-blue-600">
                      {post.title}
                    </Link>
                  </CardTitle>
                  <CardDescription className="line-clamp-3">{post.excerpt}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <User className="h-4 w-4 mr-2" />
                    <span className="mr-4">{post.author}</span>
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{post.readTime}</span>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/blog/${post.id}`}>
                        Read More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Load More */}
        <div className="text-center">
          <Button variant="outline" size="lg">
            Load More Articles
          </Button>
        </div>
      </div>

      {/* Newsletter Signup */}
      <div className="bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
          <p className="text-xl text-blue-100 mb-8">
            Get the latest affiliate marketing insights delivered to your inbox
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <Input
              placeholder="Enter your email"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/70"
            />
            <Button variant="secondary">Subscribe</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
