import { Suspense } from "react"
import { DashboardStats } from "@/components/dashboard-stats"
import { QuickActions } from "@/components/quick-actions"
import { RecentActivity } from "@/components/recent-activity"
import { LinkHealthMonitor } from "@/components/link-health-monitor"
import { AutomationStatus } from "@/components/automation-status"
import { IntegrationOverview } from "@/components/integration-overview"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's what's happening with your links.</p>
      </div>

      {/* Stats Overview */}
      <Suspense fallback={<div className="h-32 bg-gray-100 rounded-lg animate-pulse" />}>
        <DashboardStats />
      </Suspense>

      {/* Quick Actions */}
      <Suspense fallback={<div className="h-48 bg-gray-100 rounded-lg animate-pulse" />}>
        <QuickActions />
      </Suspense>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Suspense fallback={<div className="h-96 bg-gray-100 rounded-lg animate-pulse" />}>
          <RecentActivity />
        </Suspense>

        <Suspense fallback={<div className="h-96 bg-gray-100 rounded-lg animate-pulse" />}>
          <LinkHealthMonitor />
        </Suspense>

        <Suspense fallback={<div className="h-96 bg-gray-100 rounded-lg animate-pulse" />}>
          <AutomationStatus />
        </Suspense>

        <Suspense fallback={<div className="h-96 bg-gray-100 rounded-lg animate-pulse" />}>
          <IntegrationOverview />
        </Suspense>
      </div>
    </div>
  )
}
