"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  Search,
  ChevronDown,
  BookOpen,
  Video,
  MessageCircle,
  FileText,
  Zap,
  BarChart3,
  LinkIcon,
  Settings,
  CreditCard,
} from "lucide-react"

const categories = [
  {
    icon: BookOpen,
    title: "Getting Started",
    description: "Learn the basics of LinkMaster Pro",
    articles: 12,
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: LinkIcon,
    title: "Link Management",
    description: "Create, organize, and optimize your links",
    articles: 18,
    color: "bg-green-100 text-green-600",
  },
  {
    icon: BarChart3,
    title: "Analytics & Reporting",
    description: "Understand your performance data",
    articles: 15,
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: Zap,
    title: "AI & Automation",
    description: "Leverage AI for optimization",
    articles: 10,
    color: "bg-yellow-100 text-yellow-600",
  },
  {
    icon: Settings,
    title: "Account Settings",
    description: "Manage your account and preferences",
    articles: 8,
    color: "bg-gray-100 text-gray-600",
  },
  {
    icon: CreditCard,
    title: "Billing & Plans",
    description: "Subscription and payment information",
    articles: 6,
    color: "bg-indigo-100 text-indigo-600",
  },
]

const faqs = [
  {
    category: "General",
    question: "What is LinkMaster Pro?",
    answer:
      "LinkMaster Pro is an intelligent affiliate link management platform that helps marketers create, optimize, and track their affiliate links using AI-powered insights and automation.",
  },
  {
    category: "Getting Started",
    question: "How do I create my first affiliate link?",
    answer:
      'To create your first link, go to the Links page, click "Add Link", enter your destination URL, customize your short link, and click "Create". You can then track its performance in real-time.',
  },
  {
    category: "Features",
    question: "What makes LinkMaster Pro different from other link shorteners?",
    answer:
      "LinkMaster Pro goes beyond simple link shortening. We offer AI-powered optimization, advanced analytics, A/B testing, fraud protection, and integration with 50+ affiliate networks.",
  },
  {
    category: "Analytics",
    question: "How accurate is the analytics data?",
    answer:
      "Our analytics are highly accurate, tracking clicks, conversions, and revenue in real-time. We use advanced filtering to eliminate bot traffic and provide clean, actionable data.",
  },
  {
    category: "AI Features",
    question: "How does the AI optimization work?",
    answer:
      "Our AI analyzes your link performance, audience behavior, and market trends to automatically optimize your links for better conversion rates. It can adjust targeting, timing, and presentation.",
  },
  {
    category: "Billing",
    question: "Can I change my plan at any time?",
    answer:
      "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, and we'll prorate any billing differences.",
  },
  {
    category: "Support",
    question: "What support options are available?",
    answer:
      "We offer email support (24/7), live chat (business hours), phone support for Pro+ plans, and comprehensive documentation. Enterprise customers get dedicated support.",
  },
  {
    category: "Security",
    question: "How secure is my data?",
    answer:
      "We use enterprise-grade security including SSL encryption, SOC 2 compliance, regular security audits, and secure data centers. Your data is protected with the highest standards.",
  },
]

const quickLinks = [
  { title: "Getting Started Guide", icon: BookOpen, href: "/help/getting-started" },
  { title: "Video Tutorials", icon: Video, href: "/help/videos" },
  { title: "API Documentation", icon: FileText, href: "/help/api" },
  { title: "Contact Support", icon: MessageCircle, href: "/contact" },
]

export default function HelpPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold sm:text-5xl mb-4">Help Center</h1>
            <p className="text-xl max-w-2xl mx-auto mb-8">
              Find answers to your questions and learn how to get the most out of LinkMaster Pro
            </p>

            {/* Search Bar */}
            <div className="max-w-md mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search help articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Quick Links */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Links</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickLinks.map((link) => (
              <Card key={link.title} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <link.icon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-900">{link.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Help Categories */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Browse by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Card key={category.title} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${category.color}`}>
                      <category.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{category.title}</CardTitle>
                      <CardDescription>{category.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Badge variant="outline">{category.articles} articles</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <Card key={index}>
                <Collapsible open={openFaq === index} onOpenChange={() => setOpenFaq(openFaq === index ? null : index)}>
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Badge variant="outline">{faq.category}</Badge>
                          <CardTitle className="text-left">{faq.question}</CardTitle>
                        </div>
                        <ChevronDown
                          className={`h-5 w-5 transition-transform ${openFaq === index ? "rotate-180" : ""}`}
                        />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent>
                      <p className="text-gray-600">{faq.answer}</p>
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Still Need Help?</CardTitle>
              <CardDescription>Can't find what you're looking for? Our support team is here to help.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button>
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Start Live Chat
                </Button>
                <Button variant="outline">Contact Support</Button>
              </div>
              <p className="text-sm text-gray-500 mt-4">Average response time: 2 hours</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
