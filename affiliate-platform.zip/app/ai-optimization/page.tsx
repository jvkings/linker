import { AIOptimizationDashboard } from "@/components/ai-optimization-dashboard"

export default function AIOptimizationPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            AI Optimization
          </h2>
          <p className="text-muted-foreground">
            Let artificial intelligence optimize your affiliate links for maximum performance
          </p>
        </div>
      </div>
      <AIOptimizationDashboard />
    </div>
  )
}
