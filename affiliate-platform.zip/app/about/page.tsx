import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Target, Zap, Shield, Award, TrendingUp } from "lucide-react"

const team = [
  {
    name: "Sarah Johnson",
    role: "CEO & Co-Founder",
    bio: "Former VP of Marketing at TechCorp with 15+ years in affiliate marketing.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Michael Chen",
    role: "CTO & Co-Founder",
    bio: "Ex-Google engineer specializing in AI and machine learning systems.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Emily Rodriguez",
    role: "Head of Product",
    bio: "Product leader with expertise in SaaS platforms and user experience.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "David Kim",
    role: "Head of Engineering",
    bio: "Full-stack architect with experience building scalable platforms.",
    image: "/placeholder.svg?height=300&width=300",
  },
]

const values = [
  {
    icon: Target,
    title: "Customer-Centric",
    description: "Every decision we make is driven by what's best for our customers and their success.",
  },
  {
    icon: Zap,
    title: "Innovation First",
    description: "We constantly push the boundaries of what's possible in affiliate marketing technology.",
  },
  {
    icon: Shield,
    title: "Trust & Security",
    description: "We protect our customers' data and links with enterprise-grade security measures.",
  },
  {
    icon: Users,
    title: "Collaboration",
    description: "We believe in the power of teamwork, both internally and with our customers.",
  },
]

const milestones = [
  {
    year: "2020",
    title: "Company Founded",
    description: "Started with a vision to revolutionize affiliate link management.",
  },
  {
    year: "2021",
    title: "First 1,000 Users",
    description: "Reached our first major milestone with early adopters.",
  },
  {
    year: "2022",
    title: "AI Integration",
    description: "Launched our groundbreaking AI optimization engine.",
  },
  {
    year: "2023",
    title: "50,000+ Users",
    description: "Became the leading platform for affiliate link management.",
  },
  {
    year: "2024",
    title: "Enterprise Launch",
    description: "Expanded to serve large enterprises and marketing agencies.",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl font-bold sm:text-6xl mb-6">About LinkMaster Pro</h1>
            <p className="text-xl max-w-3xl mx-auto mb-8">
              We're on a mission to empower marketers with intelligent tools that transform how affiliate links are
              managed, optimized, and scaled.
            </p>
            <div className="flex justify-center space-x-8 text-center">
              <div>
                <div className="text-3xl font-bold">50K+</div>
                <div className="text-blue-100">Active Users</div>
              </div>
              <div>
                <div className="text-3xl font-bold">10M+</div>
                <div className="text-blue-100">Links Managed</div>
              </div>
              <div>
                <div className="text-3xl font-bold">$2.5B+</div>
                <div className="text-blue-100">Revenue Tracked</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Our Story */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
            <div className="space-y-4 text-gray-600">
              <p>
                LinkMaster Pro was born from frustration. Our founders, Sarah and Michael, were running successful
                affiliate marketing campaigns but struggling with the complexity of managing thousands of links across
                multiple networks.
              </p>
              <p>
                Traditional tools were either too basic or overly complicated. There was no solution that combined
                powerful analytics, AI-driven optimization, and an intuitive user experience.
              </p>
              <p>
                So we built one. Starting in 2020, we've grown from a small team with a big vision to the leading
                platform trusted by over 50,000 marketers worldwide.
              </p>
              <p>
                Today, LinkMaster Pro processes millions of clicks daily, helping our customers optimize their campaigns
                and maximize their revenue through intelligent automation and data-driven insights.
              </p>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Award className="h-12 w-12 text-blue-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">Industry Recognition</h3>
                  <p className="text-gray-600">Winner of MarTech Breakthrough Award 2023</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <TrendingUp className="h-12 w-12 text-green-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">Proven Results</h3>
                  <p className="text-gray-600">Average 40% increase in conversion rates</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Shield className="h-12 w-12 text-purple-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">Enterprise Security</h3>
                  <p className="text-gray-600">SOC 2 Type II certified platform</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Our Values */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Our Values</h2>
            <p className="mt-4 text-lg text-gray-600">The principles that guide everything we do</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value) => (
              <Card key={value.title}>
                <CardContent className="p-6 text-center">
                  <value.icon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Our Journey</h2>
          <p className="mt-4 text-lg text-gray-600">Key milestones in our company's growth</p>
        </div>
        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gray-200"></div>
          <div className="space-y-12">
            {milestones.map((milestone, index) => (
              <div
                key={milestone.year}
                className={`relative flex items-center ${index % 2 === 0 ? "justify-start" : "justify-end"}`}
              >
                <div className={`w-5/12 ${index % 2 === 0 ? "pr-8 text-right" : "pl-8 text-left"}`}>
                  <Badge variant="outline" className="mb-2">
                    {milestone.year}
                  </Badge>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{milestone.title}</h3>
                  <p className="text-gray-600">{milestone.description}</p>
                </div>
                <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-600 rounded-full border-4 border-white"></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Meet Our Team</h2>
            <p className="mt-4 text-lg text-gray-600">The people behind LinkMaster Pro</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member) => (
              <Card key={member.name}>
                <CardContent className="p-6 text-center">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-blue-600 font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Join Our Success Story?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Discover how LinkMaster Pro can transform your affiliate marketing
          </p>
          <div className="space-x-4">
            <Button size="lg" variant="secondary">
              Start Free Trial
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
