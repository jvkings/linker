import React from "react"
import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const plans = [
  {
    name: "Starter",
    price: "$29",
    period: "/month",
    description: "Perfect for individual marketers and small businesses",
    features: [
      "Up to 1,000 links",
      "Basic analytics",
      "5 affiliate networks",
      "Link shortening",
      "Email support",
      "Basic A/B testing",
    ],
    limitations: ["No AI optimization", "No advanced analytics", "No team collaboration", "No API access"],
    popular: false,
    cta: "Start Free Trial",
  },
  {
    name: "Professional",
    price: "$79",
    period: "/month",
    description: "Ideal for growing businesses and marketing teams",
    features: [
      "Up to 10,000 links",
      "Advanced analytics",
      "20 affiliate networks",
      "AI optimization",
      "Priority support",
      "Advanced A/B testing",
      "Team collaboration (5 users)",
      "Custom domains",
      "Fraud protection",
    ],
    limitations: ["No white-label solution", "Limited API calls"],
    popular: true,
    cta: "Start Free Trial",
  },
  {
    name: "Enterprise",
    price: "$199",
    period: "/month",
    description: "For large organizations with advanced needs",
    features: [
      "Unlimited links",
      "Enterprise analytics",
      "All affiliate networks",
      "Advanced AI optimization",
      "Dedicated support",
      "Unlimited A/B testing",
      "Unlimited team members",
      "White-label solution",
      "Full API access",
      "Custom integrations",
      "SLA guarantee",
      "Advanced security",
    ],
    limitations: [],
    popular: false,
    cta: "Contact Sales",
  },
]

const features = [
  {
    category: "Link Management",
    items: [
      { name: "Link Creation & Shortening", starter: true, pro: true, enterprise: true },
      { name: "Bulk Link Processing", starter: false, pro: true, enterprise: true },
      { name: "Custom Domains", starter: false, pro: true, enterprise: true },
      { name: "Link Expiration", starter: false, pro: true, enterprise: true },
      { name: "Link Cloaking", starter: false, pro: true, enterprise: true },
    ],
  },
  {
    category: "Analytics & Reporting",
    items: [
      { name: "Basic Analytics", starter: true, pro: true, enterprise: true },
      { name: "Advanced Analytics", starter: false, pro: true, enterprise: true },
      { name: "Real-time Reporting", starter: false, pro: true, enterprise: true },
      { name: "Custom Reports", starter: false, pro: false, enterprise: true },
      { name: "Data Export", starter: false, pro: true, enterprise: true },
    ],
  },
  {
    category: "AI & Optimization",
    items: [
      { name: "AI Insights", starter: false, pro: true, enterprise: true },
      { name: "AI Optimization", starter: false, pro: true, enterprise: true },
      { name: "Predictive Analytics", starter: false, pro: false, enterprise: true },
      { name: "Auto-optimization", starter: false, pro: false, enterprise: true },
    ],
  },
  {
    category: "Testing & Experimentation",
    items: [
      { name: "Basic A/B Testing", starter: true, pro: true, enterprise: true },
      { name: "Advanced A/B Testing", starter: false, pro: true, enterprise: true },
      { name: "Multivariate Testing", starter: false, pro: false, enterprise: true },
      { name: "Statistical Significance", starter: false, pro: true, enterprise: true },
    ],
  },
  {
    category: "Team & Collaboration",
    items: [
      { name: "Team Members", starter: "1", pro: "5", enterprise: "Unlimited" },
      { name: "Role-based Access", starter: false, pro: true, enterprise: true },
      { name: "Team Analytics", starter: false, pro: true, enterprise: true },
      { name: "Audit Logs", starter: false, pro: false, enterprise: true },
    ],
  },
  {
    category: "Support & Security",
    items: [
      { name: "Email Support", starter: true, pro: true, enterprise: true },
      { name: "Priority Support", starter: false, pro: true, enterprise: true },
      { name: "Dedicated Support", starter: false, pro: false, enterprise: true },
      { name: "SLA Guarantee", starter: false, pro: false, enterprise: true },
      { name: "Advanced Security", starter: false, pro: true, enterprise: true },
    ],
  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl">Simple, Transparent Pricing</h1>
            <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
              Choose the perfect plan for your affiliate marketing needs. All plans include a 14-day free trial.
            </p>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <Card key={plan.name} className={`relative ${plan.popular ? "border-blue-500 shadow-lg scale-105" : ""}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">Most Popular</Badge>
              )}
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="flex items-baseline">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-500 ml-1">{plan.period}</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-3" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                  {plan.limitations.map((limitation) => (
                    <li key={limitation} className="flex items-center">
                      <X className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-sm text-gray-500">{limitation}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  className={`w-full ${plan.popular ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Feature Comparison */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Feature Comparison</h2>
          <p className="mt-4 text-lg text-gray-600">Compare all features across our plans</p>
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Features
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Starter
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Professional
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Enterprise
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {features.map((category) => (
                  <React.Fragment key={category.category}>
                    <tr className="bg-gray-50">
                      <td colSpan={4} className="px-6 py-3 text-sm font-medium text-gray-900">
                        {category.category}
                      </td>
                    </tr>
                    {category.items.map((item) => (
                      <tr key={item.name}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {typeof item.starter === "boolean" ? (
                            item.starter ? (
                              <Check className="h-5 w-5 text-green-500 mx-auto" />
                            ) : (
                              <X className="h-5 w-5 text-gray-400 mx-auto" />
                            )
                          ) : (
                            <span className="text-sm text-gray-900">{item.starter}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {typeof item.pro === "boolean" ? (
                            item.pro ? (
                              <Check className="h-5 w-5 text-green-500 mx-auto" />
                            ) : (
                              <X className="h-5 w-5 text-gray-400 mx-auto" />
                            )
                          ) : (
                            <span className="text-sm text-gray-900">{item.pro}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          {typeof item.enterprise === "boolean" ? (
                            item.enterprise ? (
                              <Check className="h-5 w-5 text-green-500 mx-auto" />
                            ) : (
                              <X className="h-5 w-5 text-gray-400 mx-auto" />
                            )
                          ) : (
                            <span className="text-sm text-gray-900">{item.enterprise}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-8">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Can I change my plan at any time?</h3>
            <p className="text-gray-600">
              Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, and we'll
              prorate any billing differences.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">What happens during the free trial?</h3>
            <p className="text-gray-600">
              You get full access to all features of your chosen plan for 14 days. No credit card required to start, and
              you can cancel anytime during the trial.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Do you offer refunds?</h3>
            <p className="text-gray-600">
              Yes, we offer a 30-day money-back guarantee. If you're not satisfied with LinkMaster Pro, we'll refund
              your payment in full.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Is there a setup fee?</h3>
            <p className="text-gray-600">
              No, there are no setup fees or hidden costs. You only pay the monthly subscription fee for your chosen
              plan.
            </p>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8">Join thousands of marketers who trust LinkMaster Pro</p>
          <div className="space-x-4">
            <Button size="lg" variant="secondary">
              Start Free Trial
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Schedule Demo
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
