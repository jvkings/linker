"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LinkIcon,
  Upload,
  Download,
  Copy,
  ExternalLink,
  Settings,
  Zap,
  FileText,
  Hash,
  Shuffle,
  DotIcon as Counter,
  Key,
  Wand2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ShortenedLink {
  id: string
  originalUrl: string
  shortUrl: string
  customSlug?: string
  method: string
  clicks: number
  created: string
  status: "success" | "error"
  error?: string
}

export default function BulkShortenerPage() {
  const [urls, setUrls] = useState("")
  const [shorteningMethod, setShorteningMethod] = useState("base62")
  const [customDomain, setCustomDomain] = useState("lmp.co")
  const [enableTracking, setEnableTracking] = useState(true)
  const [enableExpiration, setEnableExpiration] = useState(false)
  const [expirationDays, setExpirationDays] = useState("30")
  const [processing, setProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<ShortenedLink[]>([])
  const { toast } = useToast()

  const shorteningMethods = [
    {
      id: "base62",
      name: "Base62 Encoding",
      description: "Compact alphanumeric encoding (a-z, A-Z, 0-9)",
      icon: Hash,
      example: "lmp.co/aB3xY9",
    },
    {
      id: "hash",
      name: "URL Hashing",
      description: "MD5 hash-based shortening for consistency",
      icon: Key,
      example: "lmp.co/a1b2c3d4",
    },
    {
      id: "random",
      name: "Random String",
      description: "Cryptographically secure random strings",
      icon: Shuffle,
      example: "lmp.co/xK9mP2nQ",
    },
    {
      id: "incremental",
      name: "Incremental IDs",
      description: "Sequential numeric identifiers",
      icon: Counter,
      example: "lmp.co/12345",
    },
    {
      id: "salted",
      name: "Salted Hash",
      description: "Enhanced security with salt-based hashing",
      icon: Key,
      example: "lmp.co/s4lt3d9x",
    },
    {
      id: "custom",
      name: "Custom Slugs",
      description: "User-defined meaningful URLs",
      icon: Wand2,
      example: "lmp.co/my-product",
    },
  ]

  const generateShortUrl = (url: string, method: string, index: number): ShortenedLink => {
    let shortCode = ""

    switch (method) {
      case "base62":
        shortCode = Math.random().toString(36).substring(2, 8)
        break
      case "hash":
        shortCode = btoa(url).substring(0, 8).toLowerCase()
        break
      case "random":
        shortCode = Array.from(
          { length: 8 },
          () => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[Math.floor(Math.random() * 62)],
        ).join("")
        break
      case "incremental":
        shortCode = (1000 + index).toString()
        break
      case "salted":
        shortCode = "s" + Math.random().toString(36).substring(2, 8)
        break
      case "custom":
        shortCode =
          url
            .split("/")
            .pop()
            ?.replace(/[^a-zA-Z0-9-]/g, "-")
            .substring(0, 20) || "custom"
        break
      default:
        shortCode = Math.random().toString(36).substring(2, 8)
    }

    return {
      id: Math.random().toString(36).substring(2),
      originalUrl: url,
      shortUrl: `${customDomain}/${shortCode}`,
      method,
      clicks: 0,
      created: new Date().toISOString(),
      status: "success",
    }
  }

  const processUrls = async () => {
    const urlList = urls.split("\n").filter((url) => url.trim())

    if (urlList.length === 0) {
      toast({
        title: "No URLs provided",
        description: "Please enter at least one URL to shorten.",
        variant: "destructive",
      })
      return
    }

    setProcessing(true)
    setProgress(0)
    setResults([])

    const newResults: ShortenedLink[] = []

    for (let i = 0; i < urlList.length; i++) {
      const url = urlList[i].trim()

      // Simulate processing delay
      await new Promise((resolve) => setTimeout(resolve, 100))

      try {
        // Validate URL
        new URL(url)
        const shortened = generateShortUrl(url, shorteningMethod, i)
        newResults.push(shortened)
      } catch (error) {
        newResults.push({
          id: Math.random().toString(36).substring(2),
          originalUrl: url,
          shortUrl: "",
          method: shorteningMethod,
          clicks: 0,
          created: new Date().toISOString(),
          status: "error",
          error: "Invalid URL format",
        })
      }

      setProgress(((i + 1) / urlList.length) * 100)
      setResults([...newResults])
    }

    setProcessing(false)

    const successCount = newResults.filter((r) => r.status === "success").length
    const errorCount = newResults.filter((r) => r.status === "error").length

    toast({
      title: "Bulk shortening completed",
      description: `Successfully shortened ${successCount} URLs. ${errorCount} errors.`,
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Short URL has been copied to your clipboard.",
    })
  }

  const exportResults = () => {
    const csv = [
      "Original URL,Short URL,Method,Status,Created",
      ...results.map((r) => `"${r.originalUrl}","${r.shortUrl}","${r.method}","${r.status}","${r.created}"`),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "shortened-links.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const selectedMethod = shorteningMethods.find((m) => m.id === shorteningMethod)

  return (
    <div className="container mx-auto px-4 py-8 bg-white dark:bg-gray-950 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Bulk Link Shortener</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Shorten multiple URLs at once with advanced customization options
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center text-gray-900 dark:text-white">
                <LinkIcon className="mr-2 h-5 w-5" />
                URLs to Shorten
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-400">
                Enter one URL per line. Supports up to 1000 URLs at once.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="urls" className="text-gray-900 dark:text-white">
                  URLs (one per line)
                </Label>
                <Textarea
                  id="urls"
                  placeholder="https://example.com/page1&#10;https://example.com/page2&#10;https://example.com/page3"
                  value={urls}
                  onChange={(e) => setUrls(e.target.value)}
                  rows={8}
                  className="font-mono text-sm bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white"
                />
                <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {urls.split("\n").filter((url) => url.trim()).length} URLs entered
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 bg-transparent"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Import CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 bg-transparent"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Load from File
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results Section */}
          {results.length > 0 && (
            <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-gray-900 dark:text-white">Results</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-400">
                      {results.filter((r) => r.status === "success").length} successful,{" "}
                      {results.filter((r) => r.status === "error").length} errors
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={exportResults}
                    className="border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 bg-transparent"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {processing && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Processing URLs...</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                <ScrollArea className="h-[400px]">
                  <div className="space-y-2">
                    {results.map((result) => (
                      <div
                        key={result.id}
                        className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <Badge variant={result.status === "success" ? "default" : "destructive"}>
                              {result.status}
                            </Badge>
                            <span className="text-xs text-gray-500 dark:text-gray-400">{result.method}</span>
                          </div>
                          <div className="mt-1">
                            <div className="text-sm text-gray-600 dark:text-gray-400 truncate">
                              {result.originalUrl}
                            </div>
                            {result.status === "success" ? (
                              <div className="text-sm font-medium text-blue-600 dark:text-blue-400">
                                {result.shortUrl}
                              </div>
                            ) : (
                              <div className="text-sm text-red-600 dark:text-red-400">{result.error}</div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {result.status === "success" && (
                            <>
                              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(result.shortUrl)}>
                                <Copy className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" asChild>
                                <a href={result.originalUrl} target="_blank" rel="noopener noreferrer">
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Settings Section */}
        <div className="space-y-6">
          <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center text-gray-900 dark:text-white">
                <Settings className="mr-2 h-5 w-5" />
                Shortening Options
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="method" className="text-gray-900 dark:text-white">
                  Shortening Method
                </Label>
                <Select value={shorteningMethod} onValueChange={setShorteningMethod}>
                  <SelectTrigger className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700">
                    {shorteningMethods.map((method) => (
                      <SelectItem key={method.id} value={method.id} className="text-gray-900 dark:text-white">
                        <div className="flex items-center space-x-2">
                          <method.icon className="h-4 w-4" />
                          <span>{method.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedMethod && (
                  <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">{selectedMethod.description}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-500">Example: {selectedMethod.example}</div>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="domain" className="text-gray-900 dark:text-white">
                  Custom Domain
                </Label>
                <Select value={customDomain} onValueChange={setCustomDomain}>
                  <SelectTrigger className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700">
                    <SelectItem value="lmp.co" className="text-gray-900 dark:text-white">
                      lmp.co
                    </SelectItem>
                    <SelectItem value="short.ly" className="text-gray-900 dark:text-white">
                      short.ly
                    </SelectItem>
                    <SelectItem value="yourdomain.com" className="text-gray-900 dark:text-white">
                      yourdomain.com
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="tracking" className="text-gray-900 dark:text-white">
                    Click Tracking
                  </Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Track clicks and analytics</p>
                </div>
                <Switch id="tracking" checked={enableTracking} onCheckedChange={setEnableTracking} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="expiration" className="text-gray-900 dark:text-white">
                    Link Expiration
                  </Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Auto-expire links after time</p>
                </div>
                <Switch id="expiration" checked={enableExpiration} onCheckedChange={setEnableExpiration} />
              </div>

              {enableExpiration && (
                <div>
                  <Label htmlFor="expiration-days" className="text-gray-900 dark:text-white">
                    Expiration (days)
                  </Label>
                  <Input
                    id="expiration-days"
                    type="number"
                    value={expirationDays}
                    onChange={(e) => setExpirationDays(e.target.value)}
                    min="1"
                    max="365"
                    className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
              )}

              <Button onClick={processUrls} disabled={processing || !urls.trim()} className="w-full">
                <Zap className="h-4 w-4 mr-2" />
                {processing ? "Processing..." : "Shorten URLs"}
              </Button>
            </CardContent>
          </Card>

          {/* Method Details */}
          <Card className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <CardHeader>
              <CardTitle className="text-gray-900 dark:text-white">Method Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-gray-100 dark:bg-gray-800">
                  <TabsTrigger
                    value="overview"
                    className="text-gray-700 dark:text-gray-300 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700 data-[state=active]:text-gray-900 dark:data-[state=active]:text-white"
                  >
                    Overview
                  </TabsTrigger>
                  <TabsTrigger
                    value="comparison"
                    className="text-gray-700 dark:text-gray-300 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-700 data-[state=active]:text-gray-900 dark:data-[state=active]:text-white"
                  >
                    Compare
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="overview" className="space-y-3">
                  {selectedMethod && (
                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <selectedMethod.icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        <h3 className="font-medium text-gray-900 dark:text-white">{selectedMethod.name}</h3>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{selectedMethod.description}</p>
                      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                        <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">Example output:</div>
                        <code className="text-sm font-mono text-gray-900 dark:text-white">
                          {selectedMethod.example}
                        </code>
                      </div>
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="comparison" className="space-y-2">
                  <div className="text-xs space-y-2 text-gray-700 dark:text-gray-300">
                    <div className="flex justify-between">
                      <span>Security:</span>
                      <span className="font-medium">
                        {shorteningMethod === "salted"
                          ? "High"
                          : shorteningMethod === "random"
                            ? "High"
                            : shorteningMethod === "hash"
                              ? "Medium"
                              : "Low"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Length:</span>
                      <span className="font-medium">
                        {shorteningMethod === "incremental"
                          ? "Short"
                          : shorteningMethod === "base62"
                            ? "Short"
                            : shorteningMethod === "custom"
                              ? "Variable"
                              : "Medium"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Predictable:</span>
                      <span className="font-medium">
                        {shorteningMethod === "incremental" ? "Yes" : shorteningMethod === "hash" ? "Yes" : "No"}
                      </span>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
