import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  // Mock activity data
  const activities = [
    {
      id: 1,
      type: "link_created",
      description: "Created short link for product page",
      url: "https://example.com/product/123",
      shortUrl: "lmp.co/abc123",
      timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      status: "success",
      integration: "WordPress",
      clicks: 45,
    },
    {
      id: 2,
      type: "link_updated",
      description: "Updated affiliate link destination",
      url: "https://affiliate.com/product/456",
      shortUrl: "lmp.co/def456",
      timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      status: "success",
      integration: "Shopify",
      clicks: 23,
    },
    {
      id: 3,
      type: "dead_link_detected",
      description: "Dead link detected and replaced",
      url: "https://oldsite.com/broken",
      shortUrl: "lmp.co/ghi789",
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      status: "warning",
      integration: "Manual",
      clicks: 0,
    },
    {
      id: 4,
      type: "bulk_operation",
      description: "Bulk shortened 150 links",
      url: null,
      shortUrl: null,
      timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      status: "success",
      integration: "API",
      clicks: 0,
    },
    {
      id: 5,
      type: "automation_triggered",
      description: "Auto-linked 12 keywords on blog post",
      url: "https://blog.example.com/post/123",
      shortUrl: null,
      timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
      status: "success",
      integration: "WordPress",
      clicks: 89,
    },
  ]

  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedActivities = activities.slice(startIndex, endIndex)

  return NextResponse.json({
    activities: paginatedActivities,
    pagination: {
      page,
      limit,
      total: activities.length,
      totalPages: Math.ceil(activities.length / limit),
    },
  })
}

export async function POST(request: Request) {
  const body = await request.json()

  // Mock creating new activity
  const newActivity = {
    id: Date.now(),
    type: body.type,
    description: body.description,
    url: body.url,
    shortUrl: body.shortUrl,
    timestamp: new Date().toISOString(),
    status: "success",
    integration: body.integration || "Manual",
    clicks: 0,
  }

  return NextResponse.json(newActivity, { status: 201 })
}
