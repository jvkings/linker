import { NextResponse } from "next/server"

// Mock affiliate network APIs
const affiliateNetworks = {
  shareasale: {
    name: "ShareASale",
    apiEndpoint: "https://api.shareasale.com/w.cfm",
    supportedTypes: ["text", "image", "html", "javascript"],
    categories: ["Electronics", "Fashion", "Health", "Travel"],
  },
  cj: {
    name: "Commission Junction",
    apiEndpoint: "https://api.cj.com/v3/advertiser-lookup",
    supportedTypes: ["text", "image", "html"],
    categories: ["Technology", "Finance", "Retail", "Services"],
  },
  rakuten: {
    name: "Rakuten Advertising",
    apiEndpoint: "https://api.rakutenadvertising.com/v1/links",
    supportedTypes: ["text", "image", "html", "javascript"],
    categories: ["Shopping", "Travel", "Finance", "Technology"],
  },
}

// Mock affiliate links data
const mockAffiliateLinks = {
  text: [
    {
      id: "txt_001",
      network: "ShareASale",
      advertiser: "TechGear Pro",
      linkUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
      linkText: "Best Wireless Headphones - 50% Off",
      category: "Electronics",
      commission: "8%",
      keywords: ["headphones", "wireless", "audio", "electronics"],
    },
    {
      id: "txt_002",
      network: "Commission Junction",
      advertiser: "FashionHub",
      linkUrl: "https://cj.com/click-123456-789",
      linkText: "Designer Clothing Sale - Up to 70% Off",
      category: "Fashion",
      commission: "12%",
      keywords: ["fashion", "clothing", "designer", "sale"],
    },
  ],
  image: [
    {
      id: "img_001",
      network: "ShareASale",
      advertiser: "TechGear Pro",
      linkUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
      imageUrl: "/placeholder.svg?height=250&width=300",
      altText: "Wireless Headphones Banner",
      dimensions: "300x250",
      category: "Electronics",
      commission: "8%",
      keywords: ["headphones", "banner", "electronics"],
    },
    {
      id: "img_002",
      network: "Rakuten",
      advertiser: "Travel Deals",
      linkUrl: "https://rakuten.com/r.cfm?b=789012&u=456&m=67890",
      imageUrl: "/placeholder.svg?height=600&width=728",
      altText: "Travel Deals Leaderboard",
      dimensions: "728x90",
      category: "Travel",
      commission: "15%",
      keywords: ["travel", "vacation", "deals", "leaderboard"],
    },
  ],
  html: [
    {
      id: "html_001",
      network: "ShareASale",
      advertiser: "HealthSupplements",
      linkUrl: "https://shareasale.com/r.cfm?b=345678&u=123&m=45678",
      htmlCode: `<div style="border:1px solid #ccc; padding:10px; text-align:center;">
        <h3>Premium Health Supplements</h3>
        <p>Get 25% off your first order!</p>
        <a href="https://shareasale.com/r.cfm?b=345678&u=123&m=45678" style="background:#007cba; color:white; padding:10px 20px; text-decoration:none;">Shop Now</a>
      </div>`,
      category: "Health",
      commission: "20%",
      keywords: ["health", "supplements", "wellness", "nutrition"],
    },
  ],
  javascript: [
    {
      id: "js_001",
      network: "Commission Junction",
      advertiser: "BookStore Plus",
      linkUrl: "https://cj.com/click-789012-345",
      jsCode: `<script type="text/javascript">
        (function() {
          var script = document.createElement('script');
          script.src = 'https://cj.com/widgets/bookstore-widget.js';
          script.async = true;
          document.head.appendChild(script);
        })();
      </script>`,
      category: "Education",
      commission: "10%",
      keywords: ["books", "education", "reading", "widget"],
    },
  ],
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const network = searchParams.get("network")
  const type = searchParams.get("type") || "all"

  if (type === "all") {
    return NextResponse.json({
      networks: affiliateNetworks,
      links: mockAffiliateLinks,
    })
  }

  return NextResponse.json({
    links: mockAffiliateLinks[type as keyof typeof mockAffiliateLinks] || [],
  })
}

export async function POST(request: Request) {
  const body = await request.json()
  const { network, apiKey, action } = body

  // Simulate API connection test
  if (action === "test") {
    return NextResponse.json({
      success: true,
      message: `Successfully connected to ${network}`,
      linksFound: Math.floor(Math.random() * 1000) + 100,
    })
  }

  // Simulate pulling links from network
  if (action === "pull") {
    return NextResponse.json({
      success: true,
      linksPulled: mockAffiliateLinks,
      totalCount: Object.values(mockAffiliateLinks).flat().length,
    })
  }

  return NextResponse.json({ success: false, message: "Invalid action" })
}
