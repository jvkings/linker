import { NextResponse } from "next/server"

const mockAnalytics = {
  overview: {
    totalClicks: 15420,
    totalConversions: 234,
    totalRevenue: 4567.89,
    conversionRate: 1.52,
    averageEPC: 19.52,
  },
  chartData: [
    { date: "2024-01-01", clicks: 120, conversions: 3, revenue: 45.67 },
    { date: "2024-01-02", clicks: 145, conversions: 5, revenue: 78.9 },
    { date: "2024-01-03", clicks: 167, conversions: 4, revenue: 67.34 },
    { date: "2024-01-04", clicks: 189, conversions: 7, revenue: 123.45 },
    { date: "2024-01-05", clicks: 203, conversions: 6, revenue: 98.76 },
    { date: "2024-01-06", clicks: 178, conversions: 8, revenue: 156.78 },
    { date: "2024-01-07", clicks: 234, conversions: 9, revenue: 189.23 },
  ],
  topCountries: [
    { country: "United States", clicks: 5678, percentage: 36.8 },
    { country: "United Kingdom", clicks: 2341, percentage: 15.2 },
    { country: "Canada", clicks: 1876, percentage: 12.2 },
    { country: "Australia", clicks: 1234, percentage: 8.0 },
    { country: "Germany", clicks: 987, percentage: 6.4 },
  ],
  topDevices: [
    { device: "Mobile", clicks: 8765, percentage: 56.8 },
    { device: "Desktop", clicks: 4321, percentage: 28.0 },
    { device: "Tablet", clicks: 2334, percentage: 15.2 },
  ],
}

export async function GET() {
  return NextResponse.json(mockAnalytics)
}
