import { NextResponse } from "next/server"

export async function GET() {
  // Mock integrations data
  const integrationsData = {
    summary: {
      totalIntegrations: 8,
      activeIntegrations: 6,
      pendingIntegrations: 1,
      failedIntegrations: 1,
    },
    integrations: [
      {
        id: 1,
        name: "WordPress Blog",
        type: "wordpress",
        status: "connected",
        url: "https://blog.example.com",
        linksManaged: 456,
        lastSync: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        features: ["Auto-linking", "Dead link detection", "Bulk operations"],
      },
      {
        id: 2,
        name: "Shopify Store",
        type: "shopify",
        status: "connected",
        url: "https://shop.example.com",
        linksManaged: 234,
        lastSync: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        features: ["Product links", "Affiliate tracking"],
      },
      {
        id: 3,
        name: "Instagram",
        type: "instagram",
        status: "connected",
        url: "@example_account",
        linksManaged: 12,
        lastSync: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
        features: ["Link in bio", "Story links"],
      },
      {
        id: 4,
        name: "YouTube Channel",
        type: "youtube",
        status: "pending",
        url: "Example Channel",
        linksManaged: 0,
        lastSync: null,
        features: ["Description links", "Video annotations"],
      },
      {
        id: 5,
        name: "Custom Website",
        type: "custom",
        status: "error",
        url: "https://custom.example.com",
        linksManaged: 89,
        lastSync: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        features: ["JavaScript SDK", "API integration"],
        error: "Authentication failed",
      },
    ],
  }

  return NextResponse.json(integrationsData)
}
