import { NextResponse } from "next/server"

// Mock website integrations
const connectedWebsites = [
  {
    id: "site_001",
    domain: "myblog.com",
    platform: "WordPress",
    status: "active",
    autoLinkingEnabled: true,
    keywordMatches: 156,
    linksInjected: 89,
    lastSync: "2024-01-15T10:30:00Z",
  },
  {
    id: "site_002",
    domain: "mystore.shopify.com",
    platform: "Shopify",
    status: "active",
    autoLinkingEnabled: true,
    keywordMatches: 234,
    linksInjected: 167,
    lastSync: "2024-01-15T09:45:00Z",
  },
]

// Mock keyword-to-link mappings
const keywordMappings = [
  {
    keyword: "youtube",
    matchedLinks: [
      {
        id: "link_001",
        title: "YouTube Premium Subscription",
        shortUrl: "https://mylinks.io/yt1",
        destination: "YouTube",
        priority: 1,
      },
    ],
  },
  {
    keyword: "claude",
    matchedLinks: [
      {
        id: "link_002",
        title: "Claude AI Assistant",
        shortUrl: "https://mylinks.io/claude1",
        destination: "Claude AI",
        priority: 1,
      },
    ],
  },
  {
    keyword: "headphones",
    matchedLinks: [
      {
        id: "link_003",
        title: "Wireless Headphones Deal",
        shortUrl: "https://mylinks.io/hp1",
        destination: "Amazon",
        priority: 1,
      },
    ],
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const action = searchParams.get("action")

  if (action === "websites") {
    return NextResponse.json({ websites: connectedWebsites })
  }

  if (action === "keywords") {
    return NextResponse.json({ mappings: keywordMappings })
  }

  return NextResponse.json({
    websites: connectedWebsites,
    mappings: keywordMappings,
  })
}

export async function POST(request: Request) {
  const body = await request.json()
  const { action, websiteId, content, keywords } = body

  if (action === "scan") {
    // Simulate content scanning for keywords
    const foundKeywords = keywords.filter((keyword: string) => content.toLowerCase().includes(keyword.toLowerCase()))

    return NextResponse.json({
      success: true,
      foundKeywords,
      suggestedInjections: foundKeywords.map((keyword: string) => ({
        keyword,
        position: content.toLowerCase().indexOf(keyword.toLowerCase()),
        context: content.substring(
          Math.max(0, content.toLowerCase().indexOf(keyword.toLowerCase()) - 50),
          content.toLowerCase().indexOf(keyword.toLowerCase()) + keyword.length + 50,
        ),
      })),
    })
  }

  if (action === "inject") {
    // Simulate link injection
    return NextResponse.json({
      success: true,
      injected: keywords.length,
      modifiedContent: content, // In reality, this would have links injected
    })
  }

  return NextResponse.json({ success: false, message: "Invalid action" })
}
