import { NextResponse } from "next/server"

export async function POST(request: Request) {
  const body = await request.json()
  const { urls, actions } = body // actions: ['shorten', 'prettify', 'tag']

  // Simulate bulk processing
  const processedLinks = urls.map((url: string, index: number) => {
    const destinationInfo = detectBulkDestination(url)

    return {
      id: `bulk_${Date.now()}_${index}`,
      originalUrl: url,
      shortUrl: actions.includes("shorten") ? `https://mylinks.io/${Math.random().toString(36).substr(2, 6)}` : null,
      prettyUrl: actions.includes("prettify")
        ? `https://shop.mylinks.io/${destinationInfo.keywords[0]}-${Math.random().toString(36).substr(2, 4)}`
        : null,
      destination: destinationInfo.destination,
      keywords: actions.includes("tag") ? destinationInfo.keywords : [],
      status: "processed",
      processedAt: new Date().toISOString(),
    }
  })

  return NextResponse.json({
    success: true,
    processed: processedLinks.length,
    links: processedLinks,
  })
}

function detectBulkDestination(url: string) {
  try {
    const urlObj = new URL(url)
    const domain = urlObj.hostname.toLowerCase()

    if (domain.includes("youtube.com")) {
      return { destination: "YouTube", keywords: ["youtube", "video", "entertainment"] }
    }
    if (domain.includes("amazon.com")) {
      return { destination: "Amazon", keywords: ["amazon", "shopping", "ecommerce"] }
    }
    if (domain.includes("claude.ai")) {
      return { destination: "Claude AI", keywords: ["claude", "ai", "chatbot"] }
    }

    return { destination: domain, keywords: [domain.replace(".com", ""), "website"] }
  } catch {
    return { destination: "Unknown", keywords: ["unknown"] }
  }
}
