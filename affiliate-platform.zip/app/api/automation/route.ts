import { NextResponse } from "next/server"

export async function GET() {
  // Mock automation data
  const automationData = {
    summary: {
      totalRules: 12,
      activeRules: 8,
      pausedRules: 4,
      totalActions: 1456,
      actionsToday: 23,
    },
    rules: [
      {
        id: 1,
        name: "Auto-link Product Keywords",
        type: "keyword_linking",
        status: "active",
        website: "blog.example.com",
        keywords: ["iPhone", "MacBook", "iPad"],
        actionsToday: 12,
        totalActions: 456,
        lastTriggered: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      },
      {
        id: 2,
        name: "Replace Dead Affiliate Links",
        type: "dead_link_replacement",
        status: "active",
        website: "shop.example.com",
        actionsToday: 3,
        totalActions: 89,
        lastTriggered: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      },
      {
        id: 3,
        name: "Social Media Link Sync",
        type: "social_sync",
        status: "paused",
        website: "All Platforms",
        actionsToday: 0,
        totalActions: 234,
        lastTriggered: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      },
      {
        id: 4,
        name: "Bulk Link Prettification",
        type: "link_prettification",
        status: "active",
        website: "content.example.com",
        actionsToday: 8,
        totalActions: 677,
        lastTriggered: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      },
    ],
  }

  return NextResponse.json(automationData)
}

export async function POST(request: Request) {
  const body = await request.json()

  if (body.action === "toggle-rule") {
    return NextResponse.json({
      message: `Rule ${body.ruleId} ${body.status === "active" ? "paused" : "activated"}`,
      status: "success",
      ruleId: body.ruleId,
      newStatus: body.status === "active" ? "paused" : "active",
    })
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 })
}
