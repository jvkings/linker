import { type NextRequest, NextResponse } from "next/server"

// Mock data for demonstration
const mockLinks = [
  {
    id: "1",
    originalUrl: "https://amazon.com/dp/B08N5WRWNW?tag=affiliate123",
    shortUrl: "https://mylinks.io/amz1",
    prettyUrl: "https://shop.mylinks.io/wireless-earbuds",
    title: "Apple AirPods Pro",
    destination: "Amazon",
    clicks: 1247,
    conversions: 23,
    revenue: 345.67,
    tags: ["electronics", "audio", "apple"],
    createdAt: "2024-01-15T10:30:00Z",
    status: "active",
  },
  {
    id: "2",
    originalUrl: "https://shareasale.com/r.cfm?b=123456&u=789&m=12345",
    shortUrl: "https://mylinks.io/sas1",
    prettyUrl: "https://deals.mylinks.io/fitness-tracker",
    title: "Fitness Tracker Pro",
    destination: "ShareASale",
    clicks: 892,
    conversions: 15,
    revenue: 234.5,
    tags: ["fitness", "health", "wearables"],
    createdAt: "2024-01-14T15:45:00Z",
    status: "active",
  },
]

export async function GET() {
  return NextResponse.json({ links: mockLinks })
}

// Update the POST function to include advanced destination detection and keyword assignment

export async function POST(request: NextRequest) {
  const body = await request.json()

  // Simulate advanced link processing with destination detection
  const destinationInfo = await detectAdvancedDestination(body.url)

  const newLink = {
    id: Date.now().toString(),
    originalUrl: body.url,
    shortUrl: `https://mylinks.io/${Math.random().toString(36).substr(2, 6)}`,
    prettyUrl: body.prettyUrl || generatePrettyUrl(destinationInfo),
    title: body.title || destinationInfo.title || "Untitled Link",
    destination: destinationInfo.destination,
    destinationKeywords: destinationInfo.keywords,
    linkType: destinationInfo.linkType,
    clicks: 0,
    conversions: 0,
    revenue: 0,
    tags: [...(body.tags || []), ...destinationInfo.keywords],
    createdAt: new Date().toISOString(),
    status: "active",
    metadata: destinationInfo.metadata,
  }

  return NextResponse.json({ link: newLink })
}

// Enhanced destination detection function
async function detectAdvancedDestination(url: string) {
  // Simulate advanced URL analysis
  const urlObj = new URL(url)
  const domain = urlObj.hostname.toLowerCase()

  // Advanced destination mapping
  const destinationMap = {
    "claude.ai": {
      destination: "Claude AI",
      keywords: ["ai", "claude", "anthropic", "chatbot", "artificial-intelligence"],
      linkType: "service",
      category: "AI Tools",
    },
    "lovable.app": {
      destination: "Lovable",
      keywords: ["lovable", "app-generator", "no-code", "development"],
      linkType: "service",
      category: "Development Tools",
    },
    "youtube.com": {
      destination: "YouTube",
      keywords: ["youtube", "video", "streaming", "entertainment", "google"],
      linkType: "media",
      category: "Video Platform",
    },
    "amazon.com": {
      destination: "Amazon",
      keywords: ["amazon", "shopping", "ecommerce", "retail", "aws"],
      linkType: "ecommerce",
      category: "E-commerce",
    },
    "shareasale.com": {
      destination: "ShareASale",
      keywords: ["shareasale", "affiliate", "marketing", "commission"],
      linkType: "affiliate-network",
      category: "Affiliate Networks",
    },
  }

  // Find matching destination
  const matchedDestination = Object.entries(destinationMap).find(([key]) => domain.includes(key))

  if (matchedDestination) {
    const [, info] = matchedDestination
    return {
      destination: info.destination,
      keywords: info.keywords,
      linkType: info.linkType,
      title: `${info.destination} Link`,
      metadata: {
        category: info.category,
        domain: domain,
        detectedAt: new Date().toISOString(),
      },
    }
  }

  // Default fallback
  return {
    destination: domain,
    keywords: [domain.replace(".com", ""), "website"],
    linkType: "website",
    title: `${domain} Link`,
    metadata: {
      category: "General",
      domain: domain,
      detectedAt: new Date().toISOString(),
    },
  }
}

// Generate pretty URL based on destination
function generatePrettyUrl(destinationInfo: any): string {
  const baseUrl = "https://shop.mylinks.io"
  const slug = destinationInfo.keywords[0] || "deal"
  return `${baseUrl}/${slug}-${Math.random().toString(36).substr(2, 4)}`
}
