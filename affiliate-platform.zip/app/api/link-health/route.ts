import { NextResponse } from "next/server"

export async function GET() {
  // Mock link health data
  const healthData = {
    summary: {
      totalLinks: 1247,
      healthyLinks: 1198,
      brokenLinks: 23,
      warningLinks: 26,
      healthScore: 96.1,
      lastChecked: new Date().toISOString(),
    },
    issues: [
      {
        id: 1,
        url: "https://oldsite.com/product/123",
        shortUrl: "lmp.co/abc123",
        status: "broken",
        statusCode: 404,
        lastChecked: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        clicks: 45,
        suggestedFix: "https://newsite.com/product/123",
      },
      {
        id: 2,
        url: "https://slowsite.com/page",
        shortUrl: "lmp.co/def456",
        status: "warning",
        statusCode: 200,
        responseTime: 5200,
        lastChecked: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        clicks: 12,
        suggestedFix: null,
      },
      {
        id: 3,
        url: "https://redirected.com/old-page",
        shortUrl: "lmp.co/ghi789",
        status: "warning",
        statusCode: 301,
        redirectUrl: "https://redirected.com/new-page",
        lastChecked: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
        clicks: 78,
        suggestedFix: "https://redirected.com/new-page",
      },
    ],
  }

  return NextResponse.json(healthData)
}

export async function POST(request: Request) {
  const body = await request.json()

  if (body.action === "refresh") {
    // Mock refresh action
    return NextResponse.json({
      message: "Health check initiated",
      status: "success",
      timestamp: new Date().toISOString(),
    })
  }

  if (body.action === "fix-broken-links") {
    // Mock fix broken links action
    return NextResponse.json({
      message: "Fixed 23 broken links",
      status: "success",
      fixedCount: 23,
      timestamp: new Date().toISOString(),
    })
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 })
}
