import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "LinkMaster Pro - Intelligent Affiliate Link Management Platform",
  description:
    "Transform your affiliate marketing with AI-powered optimization, advanced analytics, and seamless automation. Increase conversions by up to 40%.",
}

export default function LandingLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
