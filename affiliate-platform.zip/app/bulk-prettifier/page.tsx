"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Wand2, Upload, Download, Copy, ExternalLink, Settings, Sparkles, FileText, Tag, Type } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PrettifiedLink {
  id: string
  originalUrl: string
  prettyUrl: string
  category: string
  keywords: string[]
  style: string
  seoScore: number
  status: "success" | "error"
  error?: string
}

export default function BulkPrettifierPage() {
  const [urls, setUrls] = useState("")
  const [prettifyStyle, setPrettifyStyle] = useState("descriptive")
  const [customDomain, setCustomDomain] = useState("pretty.ly")
  const [enableSEO, setEnableSEO] = useState(true)
  const [enableKeywords, setEnableKeywords] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<PrettifiedLink[]>([])
  const { toast } = useToast()

  const prettifyStyles = [
    {
      id: "descriptive",
      name: "Descriptive",
      description: "Human-readable, descriptive URLs",
      example: "pretty.ly/best-wireless-headphones-2024",
    },
    {
      id: "branded",
      name: "Branded",
      description: "Include brand names and product info",
      example: "pretty.ly/apple-iphone-15-pro-review",
    },
    {
      id: "keyword-rich",
      name: "Keyword Rich",
      description: "SEO-optimized with target keywords",
      example: "pretty.ly/buy-cheap-laptops-online-deals",
    },
    {
      id: "minimal",
      name: "Minimal",
      description: "Clean, short, and simple",
      example: "pretty.ly/headphones-review",
    },
    {
      id: "creative",
      name: "Creative",
      description: "Catchy and memorable phrases",
      example: "pretty.ly/sound-perfection-awaits",
    },
  ]

  const analyzeUrl = (url: string) => {
    // Extract domain and path
    try {
      const urlObj = new URL(url)
      const domain = urlObj.hostname.replace("www.", "")
      const path = urlObj.pathname
      const params = urlObj.searchParams

      // Determine category based on domain and path
      let category = "general"
      if (domain.includes("amazon") || domain.includes("shop")) category = "ecommerce"
      else if (domain.includes("blog") || path.includes("blog")) category = "blog"
      else if (domain.includes("youtube") || domain.includes("video")) category = "video"
      else if (path.includes("product")) category = "product"
      else if (path.includes("article") || path.includes("news")) category = "article"

      // Extract keywords from path and params
      const keywords = [
        ...path.split("/").filter((p) => p && p.length > 2),
        ...Array.from(params.values()).filter((v) => v.length > 2),
      ]
        .map((k) =>
          k
            .replace(/[^a-zA-Z0-9]/g, " ")
            .trim()
            .toLowerCase(),
        )
        .filter((k) => k.length > 2)
        .slice(0, 5)

      return { category, keywords, domain }
    } catch {
      return { category: "general", keywords: [], domain: "unknown" }
    }
  }

  const generatePrettyUrl = (url: string, style: string): PrettifiedLink => {
    const analysis = analyzeUrl(url)
    let prettySlug = ""
    let seoScore = 0

    switch (style) {
      case "descriptive":
        prettySlug = analysis.keywords.slice(0, 3).join("-") || "useful-resource"
        seoScore = 85
        break
      case "branded":
        prettySlug = `${analysis.domain.split(".")[0]}-${analysis.keywords.slice(0, 2).join("-")}`
        seoScore = 90
        break
      case "keyword-rich":
        prettySlug = analysis.keywords.slice(0, 4).join("-") + "-guide"
        seoScore = 95
        break
      case "minimal":
        prettySlug = analysis.keywords[0] || "resource"
        seoScore = 70
        break
      case "creative":
        const creative = ["discover-amazing", "ultimate-guide-to", "best-ever", "must-see", "incredible"]
        prettySlug = `${creative[Math.floor(Math.random() * creative.length)]}-${analysis.keywords[0] || "content"}`
        seoScore = 80
        break
      default:
        prettySlug = analysis.keywords.slice(0, 2).join("-") || "link"
        seoScore = 75
    }

    // Clean up the slug
    prettySlug = prettySlug
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .substring(0, 50)

    return {
      id: Math.random().toString(36).substring(2),
      originalUrl: url,
      prettyUrl: `${customDomain}/${prettySlug}`,
      category: analysis.category,
      keywords: analysis.keywords,
      style,
      seoScore,
      status: "success",
    }
  }

  const processUrls = async () => {
    const urlList = urls.split("\n").filter((url) => url.trim())

    if (urlList.length === 0) {
      toast({
        title: "No URLs provided",
        description: "Please enter at least one URL to prettify.",
        variant: "destructive",
      })
      return
    }

    setProcessing(true)
    setProgress(0)
    setResults([])

    const newResults: PrettifiedLink[] = []

    for (let i = 0; i < urlList.length; i++) {
      const url = urlList[i].trim()

      // Simulate processing delay
      await new Promise((resolve) => setTimeout(resolve, 150))

      try {
        // Validate URL
        new URL(url)
        const prettified = generatePrettyUrl(url, prettifyStyle)
        newResults.push(prettified)
      } catch (error) {
        newResults.push({
          id: Math.random().toString(36).substring(2),
          originalUrl: url,
          prettyUrl: "",
          category: "error",
          keywords: [],
          style: prettifyStyle,
          seoScore: 0,
          status: "error",
          error: "Invalid URL format",
        })
      }

      setProgress(((i + 1) / urlList.length) * 100)
      setResults([...newResults])
    }

    setProcessing(false)

    const successCount = newResults.filter((r) => r.status === "success").length
    const errorCount = newResults.filter((r) => r.status === "error").length
    const avgSeoScore =
      newResults.filter((r) => r.status === "success").reduce((sum, r) => sum + r.seoScore, 0) / successCount || 0

    toast({
      title: "Bulk prettification completed",
      description: `Successfully prettified ${successCount} URLs. Average SEO score: ${Math.round(avgSeoScore)}%`,
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Pretty URL has been copied to your clipboard.",
    })
  }

  const exportResults = () => {
    const csv = [
      "Original URL,Pretty URL,Category,Keywords,Style,SEO Score,Status",
      ...results.map(
        (r) =>
          `"${r.originalUrl}","${r.prettyUrl}","${r.category}","${r.keywords.join(", ")}","${r.style}","${r.seoScore}","${r.status}"`,
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "prettified-links.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const getCategoryColor = (category: string) => {
    const colors = {
      ecommerce: "bg-green-100 text-green-800",
      blog: "bg-blue-100 text-blue-800",
      video: "bg-red-100 text-red-800",
      product: "bg-purple-100 text-purple-800",
      article: "bg-yellow-100 text-yellow-800",
      general: "bg-gray-100 text-gray-800",
      error: "bg-red-100 text-red-800",
    }
    return colors[category as keyof typeof colors] || colors.general
  }

  const getSeoScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-blue-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  const selectedStyle = prettifyStyles.find((s) => s.id === prettifyStyle)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Bulk Link Prettifier</h1>
        <p className="text-gray-600">Transform ugly URLs into beautiful, SEO-friendly links</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Section */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Wand2 className="mr-2 h-5 w-5" />
                URLs to Prettify
              </CardTitle>
              <CardDescription>Enter URLs to transform into beautiful, readable links</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="urls">URLs (one per line)</Label>
                <Textarea
                  id="urls"
                  placeholder="https://amazon.com/dp/B08N5WRWNW/ref=sr_1_1?keywords=headphones&#10;https://blog.example.com/how-to-choose-best-laptop-2024&#10;https://youtube.com/watch?v=dQw4w9WgXcQ"
                  value={urls}
                  onChange={(e) => setUrls(e.target.value)}
                  rows={8}
                  className="font-mono text-sm"
                />
                <div className="text-xs text-gray-500 mt-1">
                  {urls.split("\n").filter((url) => url.trim()).length} URLs entered
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Upload className="h-4 w-4 mr-2" />
                  Import CSV
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Load from File
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results Section */}
          {results.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Prettified Results</CardTitle>
                    <CardDescription>
                      {results.filter((r) => r.status === "success").length} successful • Avg SEO Score:{" "}
                      {Math.round(
                        results.filter((r) => r.status === "success").reduce((sum, r) => sum + r.seoScore, 0) /
                          results.filter((r) => r.status === "success").length || 0,
                      )}
                      %
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={exportResults}>
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {processing && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600">Prettifying URLs...</span>
                      <span className="text-sm text-gray-600">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                <ScrollArea className="h-[400px]">
                  <div className="space-y-3">
                    {results.map((result) => (
                      <div key={result.id} className="p-4 border rounded-lg space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Badge variant={result.status === "success" ? "default" : "destructive"}>
                              {result.status}
                            </Badge>
                            <Badge className={getCategoryColor(result.category)}>{result.category}</Badge>
                            {result.status === "success" && (
                              <span className={`text-sm font-medium ${getSeoScoreColor(result.seoScore)}`}>
                                SEO: {result.seoScore}%
                              </span>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            {result.status === "success" && (
                              <>
                                <Button variant="ghost" size="sm" onClick={() => copyToClipboard(result.prettyUrl)}>
                                  <Copy className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" asChild>
                                  <a href={result.originalUrl} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4" />
                                  </a>
                                </Button>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div>
                            <div className="text-xs text-gray-500 mb-1">Original URL:</div>
                            <div className="text-sm text-gray-600 truncate font-mono bg-gray-50 p-2 rounded">
                              {result.originalUrl}
                            </div>
                          </div>

                          {result.status === "success" ? (
                            <>
                              <div>
                                <div className="text-xs text-gray-500 mb-1">Pretty URL:</div>
                                <div className="text-sm font-medium text-blue-600 font-mono bg-blue-50 p-2 rounded">
                                  {result.prettyUrl}
                                </div>
                              </div>

                              {result.keywords.length > 0 && (
                                <div>
                                  <div className="text-xs text-gray-500 mb-1">Extracted Keywords:</div>
                                  <div className="flex flex-wrap gap-1">
                                    {result.keywords.map((keyword, index) => (
                                      <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                                        {keyword}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="text-sm text-red-600 bg-red-50 p-2 rounded">Error: {result.error}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Settings Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2 h-5 w-5" />
                Prettification Options
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="style">Prettification Style</Label>
                <Select value={prettifyStyle} onValueChange={setPrettifyStyle}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {prettifyStyles.map((style) => (
                      <SelectItem key={style.id} value={style.id}>
                        <div className="flex items-center space-x-2">
                          <Sparkles className="h-4 w-4" />
                          <span>{style.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedStyle && (
                  <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">{selectedStyle.description}</div>
                    <div className="text-xs text-gray-500">Example: {selectedStyle.example}</div>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="domain">Custom Domain</Label>
                <Select value={customDomain} onValueChange={setCustomDomain}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pretty.ly">pretty.ly</SelectItem>
                    <SelectItem value="clean.link">clean.link</SelectItem>
                    <SelectItem value="yourdomain.com">yourdomain.com</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="seo">SEO Optimization</Label>
                  <p className="text-xs text-gray-500">Optimize for search engines</p>
                </div>
                <Switch id="seo" checked={enableSEO} onCheckedChange={setEnableSEO} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="keywords">Keyword Extraction</Label>
                  <p className="text-xs text-gray-500">Auto-extract relevant keywords</p>
                </div>
                <Switch id="keywords" checked={enableKeywords} onCheckedChange={setEnableKeywords} />
              </div>

              <Button onClick={processUrls} disabled={processing || !urls.trim()} className="w-full">
                <Sparkles className="h-4 w-4 mr-2" />
                {processing ? "Prettifying..." : "Prettify URLs"}
              </Button>
            </CardContent>
          </Card>

          {/* Style Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Type className="mr-2 h-5 w-5" />
                Style Preview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="text-xs text-gray-500 mb-1">Sample Input:</div>
                  <div className="text-xs font-mono bg-gray-100 p-2 rounded">
                    https://amazon.com/dp/B08N5WRWNW/ref=sr_1_1?keywords=wireless+headphones
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Pretty Output:</div>
                  <div className="text-xs font-mono bg-blue-50 p-2 rounded text-blue-600">{selectedStyle?.example}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          {results.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Tag className="mr-2 h-5 w-5" />
                  Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Total URLs:</span>
                    <span className="font-medium">{results.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Successful:</span>
                    <span className="font-medium text-green-600">
                      {results.filter((r) => r.status === "success").length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average SEO Score:</span>
                    <span className="font-medium">
                      {Math.round(
                        results.filter((r) => r.status === "success").reduce((sum, r) => sum + r.seoScore, 0) /
                          results.filter((r) => r.status === "success").length || 0,
                      )}
                      %
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Top Category:</span>
                    <span className="font-medium">
                      {results.reduce(
                        (acc, r) => {
                          acc[r.category] = (acc[r.category] || 0) + 1
                          return acc
                        },
                        {} as Record<string, number>,
                      )}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
